﻿========================================================================
    BIBLIOTECA ESTÁTICA: zlib Informaci&oacute;n general del 
    proyecto
========================================================================

AppWizard ha creado este proyecto de biblioteca zlib.

Este archivo contiene un resumen de lo que encontrará en todos los 
archivos que componen la zlib aplicaci&oacute;n.


zlib.vcproj
    Éste es el archivo de proyecto principal para los proyectos de VC++ 
    generados mediante un Asistente para aplicaciones.
    Contiene informaci&oacute;n acerca de la versi&oacute;n de Visual C++ que gener&oacute; 
    el archivo e informaci&oacute;n acerca de las plataformas, configuraciones 
    y características del proyecto seleccionadas con el Asistente para 
    aplicaciones.


/////////////////////////////////////////////////////////////////////////////

StdAfx.h, StdAfx.cpp
    Estos archivos se utilizan para generar un archivo de encabezado 
    precompilado (PCH) denominado zlib.pch y un archivo de 
    tipos precompilados denominado StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Otras notas:

AppWizard usa comentarios "TODO:" para indicar las partes del c&oacute;digo fuente 
que debería agregar o personalizar.

/////////////////////////////////////////////////////////////////////////////
