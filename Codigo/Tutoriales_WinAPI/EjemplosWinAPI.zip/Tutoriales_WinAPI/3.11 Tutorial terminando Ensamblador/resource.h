//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Tutorial terminando Ensamblador.rc
//
#define MANIFEST_RESOURCE_ID            1
#define IDD_ENSAMBLADOR                 101
#define IDD_NUEVO_PROYECTO              102
#define IDC_TREE1                       1001
#define IDC_ARBOL                       1001
#define IDC_LIST1                       1002
#define IDC_LISTA                       1002
#define IDC_COMBO1                      1003
#define IDC_COMBO_PATH                  1003
#define IDC_BUTTON1                     1004
#define IDC_CARGAR                      1004
#define IDC_BUTTON2                     1005
#define IDC_GUARDAR                     1005
#define IDC_BUTTON3                     1006
#define IDC_AGREGAR_ARCHIVO             1006
#define IDC_BUTTON4                     1007
#define IDC_AGREGAR_DIRECTORIO          1007
#define IDC_BUTTON5                     1008
#define IDC_BORRAR                      1008
#define IDC_EDIT1                       1009
#define IDC_RUTA_INSTALAR               1009
#define IDC_NOMBRE_PROYECTO             1009
#define IDC_BUTTON6                     1010
#define IDC_BUSCAR                      1010
#define IDC_BUTTON7                     1011
#define IDC_CREAR                       1011
#define IDC_PROGRESS1                   1012
#define IDC_TOTAL                       1012
#define IDC_EDIT2                       1013
#define IDC_EDIT_PATH                   1013
#define IDC_BUTTON8                     1014
#define IDC_EDITAR                      1014
#define IDC_NUEVO                       1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
