// UTF8aWindows1252.cpp: define el punto de entrada de la aplicaci�n de consola.
//

#include "stdafx.h"
#include <string>

#define UTF8_A_WINDOWS_1252  0
#define WINDOWS_1252_A_UTF8  1


//#define CONVERSION  UTF8_A_WINDOWS_1252
#define CONVERSION  WINDOWS_1252_A_UTF8

void Convertir_Archivo_A_Windows1252(const TCHAR *Path) {
	// Abrimos y leemos todo el archivo en memoria
	HANDLE Archivo = CreateFile(Path, FILE_READ_DATA, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	if (Archivo == INVALID_HANDLE_VALUE) {
		printf("Error abriendo el archivo\n");
		return;
	}
	DWORD TamArchivo = GetFileSize(Archivo, NULL);
	DWORD CaracteresUsados = 0;
	char *Buffer = new char[TamArchivo];
	BOOL Ret = ReadFile(Archivo, reinterpret_cast<LPVOID>(Buffer), TamArchivo * sizeof(char), &CaracteresUsados, NULL);
	if (Ret == 0) {
		// error leyendo el archivo
		printf("Error leyendo el archivo\n");
		delete [] Buffer;
		CloseHandle(Archivo);
		return;
	}
	CloseHandle(Archivo);

	// Comprobamos que tenga firma UTF8
	if (Buffer[0] != -17 || Buffer[1] != -69 || Buffer[2] != -65) {
		printf("El archivo no esta firmado como UTF8, se omitira\n");
		delete [] Buffer;
		return;
	}

	TCHAR  LineaTCHAR[4096 * 8];
	char   LineaChar[4096 * 8];
	size_t UltimaLinea = 0;
	size_t Contador    = 0;
	// Renombramos el path a�adiendole un .OLD
	wcscpy_s(LineaTCHAR, 4096 * 8, Path);
	wcscat_s(LineaTCHAR, 4096 * 8, TEXT(".OLD"));
	DeleteFile(LineaTCHAR);
	MoveFile(Path, LineaTCHAR);

	// Abrimos el nuevo archivo para escritura
	Archivo = CreateFile(Path, FILE_WRITE_DATA, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	if (Archivo == INVALID_HANDLE_VALUE) {
		printf("Error abriendo el archivo para escritura\n");
		delete [] Buffer;
		return;
	}

//	ZeroMemory(LineaChar, sizeof(char) * (4096 * 8));
//	ZeroMemory(LineaTCHAR, sizeof(char) * (4096 * 8));
	// Escaneamos el archivo por lineas y omitimos los 3 primeros caracteres de la firma UTF8
	for (size_t i = 3; i < TamArchivo; i++) {
		LineaChar[Contador ++] = Buffer[i];
		if (Buffer[i] == '\n' || i == TamArchivo - 1) {
			LineaChar[Contador] = '\0';
			ZeroMemory(LineaTCHAR, sizeof(char) * (4096 * 8));
			MultiByteToWideChar(CP_UTF8, 0, LineaChar, -1, LineaTCHAR, 4096 * 8);
			ZeroMemory(LineaChar, sizeof(char) * (4096 * 8));
			WideCharToMultiByte(CP_ACP, 0, LineaTCHAR, -1, LineaChar, 4096 * 8, NULL, NULL);
			WriteFile(Archivo, reinterpret_cast<LPCVOID>(LineaChar), strlen(LineaChar), &CaracteresUsados, NULL);
			Contador = 0;
		}
	}

	delete [] Buffer;
	CloseHandle(Archivo);
}


void Convertir_Archivo_A_UTF8(const TCHAR *Path) {
	// Abrimos y leemos todo el archivo en memoria
	HANDLE Archivo = CreateFile(Path, FILE_READ_DATA, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	if (Archivo == INVALID_HANDLE_VALUE) {
		printf("Error abriendo el archivo\n");
		return;
	}
	DWORD TamArchivo = GetFileSize(Archivo, NULL);
	DWORD CaracteresUsados = 0;
	char *Buffer = new char[TamArchivo];
	BOOL Ret = ReadFile(Archivo, reinterpret_cast<LPVOID>(Buffer), TamArchivo * sizeof(char), &CaracteresUsados, NULL);
	if (Ret == 0) {
		// error leyendo el archivo
		printf("Error leyendo el archivo\n");
		delete [] Buffer;
		CloseHandle(Archivo);
		return;
	}
	CloseHandle(Archivo);

	// Comprobamos que no tenga firma UTF8
	if (Buffer[0] == -17 && Buffer[1] == -69 && Buffer[2] == -65) {
		printf("El archivo ya esta firmado como UTF8, se omitira\n");
		delete [] Buffer;
		return;
	}

	TCHAR  LineaTCHAR[4096 * 8];
	char   LineaChar[4096 * 8];
	size_t UltimaLinea = 0;
	size_t Contador    = 0;
	// Renombramos el path a�adiendole un .OLD
	wcscpy_s(LineaTCHAR, 4096 * 8, Path);
	wcscat_s(LineaTCHAR, 4096 * 8, TEXT(".OLD"));
	DeleteFile(LineaTCHAR);
	MoveFile(Path, LineaTCHAR);

	// Abrimos el nuevo archivo para escritura
	Archivo = CreateFile(Path, FILE_WRITE_DATA, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	if (Archivo == INVALID_HANDLE_VALUE) {
		printf("Error abriendo el archivo para escritura\n");
		delete [] Buffer;
		return;
	}
	// Pongo la marca del UTF8 al principio
	LineaChar[0] = -17;
	LineaChar[1] = -69;
	LineaChar[2] = -65;
	WriteFile(Archivo, reinterpret_cast<LPCVOID>(LineaChar), 3, &CaracteresUsados, NULL);
	ZeroMemory(LineaTCHAR, sizeof(char) * (4096 * 8));

	// Escaneamos el archivo por lineas
	for (size_t i = 0; i < TamArchivo; i++) {
		LineaChar[Contador ++] = Buffer[i];
		if (Buffer[i] == '\n' || i == TamArchivo - 1) {
			LineaChar[Contador] = '\0';
			ZeroMemory(LineaTCHAR, sizeof(char) * (4096 * 8));
			MultiByteToWideChar(CP_ACP, 0, LineaChar, -1, LineaTCHAR, 4096 * 8);
			ZeroMemory(LineaChar, sizeof(char) * (4096 * 8));
			WideCharToMultiByte(CP_UTF8, 0, LineaTCHAR, -1, LineaChar, 4096 * 8, NULL, NULL);
			WriteFile(Archivo, reinterpret_cast<LPCVOID>(LineaChar), strlen(LineaChar), &CaracteresUsados, NULL);
			Contador = 0;
		}
	}

	delete [] Buffer;
	CloseHandle(Archivo);
}


const bool ExtensionValida(const TCHAR *Path) {
	size_t TamPath = wcslen(Path);
	TCHAR  Extension[MAX_PATH];
	ZeroMemory(Extension, sizeof(TCHAR) * MAX_PATH);
	for (size_t i = TamPath; i > 0; i--) {
		if (Path[i - 1] == TEXT('.') && i != TamPath) {
			wcscpy_s(Extension, MAX_PATH, &Path[i - 1]);
			if (_wcsicmp(Extension, TEXT(".C")) == 0)	return true;
			if (_wcsicmp(Extension, TEXT(".CPP")) == 0)	return true;
			if (_wcsicmp(Extension, TEXT(".H")) == 0)	return true;
			return false;
		}
	}
	return false;
}


void BusquedaRecursiva(const TCHAR *Path) {
	WIN32_FIND_DATA		FindInfoPoint;
	HANDLE				hFind = NULL;
	TCHAR PathFinal[MAX_PATH];
	wcscpy_s(PathFinal, MAX_PATH, Path);
	wcscat_s(PathFinal, MAX_PATH, TEXT("\\*.*"));
	hFind = FindFirstFile(PathFinal, &FindInfoPoint);
	do {
		if (FindInfoPoint.cFileName[0] != TEXT('.')) {
			wcscpy_s(PathFinal, MAX_PATH, Path);
			wcscat_s(PathFinal, MAX_PATH, TEXT("\\"));
			wcscat_s(PathFinal, MAX_PATH, FindInfoPoint.cFileName);
			if (FindInfoPoint.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) { // directorio
				BusquedaRecursiva(PathFinal);
			}
			else { // archivo
				if (ExtensionValida(FindInfoPoint.cFileName) == true) {
					// TIPO DE CONVERSION
					#if CONVERSION == UTF8_A_WINDOWS_1252
						Convertir_Archivo_A_Windows1252(PathFinal);
					#else if CONVERSION == WINDOWS_1252_A_UTF8;
						Convertir_Archivo_A_UTF8(PathFinal);
					#endif
				}
			}
		}
	} while (FindNextFile(hFind, &FindInfoPoint) != 0);
	FindClose(hFind);
}





int _tmain(int argc, _TCHAR* argv[]) {
	TCHAR               Path[MAX_PATH];
	wcscpy_s(Path, MAX_PATH, argv[0]);
	UINT TamPath = wcslen(Path);
	for (UINT i = TamPath; i > 0; i--) {
		if (Path[i - 1] == TEXT('\\')) {
			Path[i - 1] = 0;
			break;
		}
	}
	BusquedaRecursiva(Path);
	

//	Convertir_Archivo_A_UTF8(TEXT("D:\\Programacio\\DWL.h"));
	return 0;
}

