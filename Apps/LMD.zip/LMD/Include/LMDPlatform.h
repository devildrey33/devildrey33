/*! \file    LMDPlatform.h
	\brief   Platform specifics
    \details This file contains definitions for windows / linux, wide char / multibyte configurations.
*/
#ifndef LMD_PLATFORM_H
    #define LMD_PLATFORM_H
    
    #include "LMDInstance.h"

    // Operative system WINDOWS
    #if defined WIN32 || WIN64
    #   define LMD_SO_WINDOWS 1
    #   define _WIN32_WINNT 0x0510
    #   include <windows.h>
    #   include <limits.h>
        /*! ID for a window asigned by SO.                                      \n
            On windows so LMDIDW is a HWND, on X11 linux so LMDIDW is a Window. \n
            This ID is for a internal use and you only need it to refer a window to a special function that handles it.
        */
        typedef HWND    LMDIDW;
    #endif

    // Operative system LINUX
//    #if defined(linux)
    #if defined linux
    #   define LMD_SO_X11 1
    #endif


    // Char type
    #if defined _UNICODE || UNICODE // Unicode de 16 bits
    #   define LMD_UNICODE
    #endif

    #if defined LMD_UNICODE          // Unicode de 16 bits
        typedef wchar_t LMD_STR;     // wchar_t
        typedef wchar_t* LMD_PSTR;   // wchar_t *
        #define String(Txt) L##Txt   // Macro para String estilo VC
    #else ///////////////////////////// ANSI
        /*! LMD_STR on UNICODE configuration is wchar_t.   \n
            LMD_STR on MULTYBITE configuration is a char.  */
        typedef char LMD_STR;        // char
        /*! LMD_PSTR on UNICODE configuration is a pointer to wchar_t. \n
            LMD_PSTR on MULTYBITE configuration is a pointer to char.  */
        typedef char* LMD_PSTR;      // char *
        #define String(Txt) Txt      // Macro para String estilo VC
    #endif

    #ifndef BOOL
        //! Boolean value
        typedef int BOOL;
    #endif
    #ifndef FALSE
        //! BOOL FALSE
    #   define FALSE 0
    #endif
    #ifndef TRUE
        //! BOOL TRUE
    #   define TRUE 1
    #endif


    #ifndef UINT
        //! Unsigned integer
        typedef unsigned int UINT;
    #endif

    #ifndef ULONG
        //! Unsigned long
        typedef unsigned long ULONG;
    #endif

    #ifndef USHORT
        //! Unsigned long
        typedef unsigned short USHORT;
    #endif


    #ifndef BYTE
        //! Byte definition
        typedef unsigned char BYTE;
    #endif

//    #ifdef LMD_SO_LINUX
//    #   include "Linux/LMDLinuxBase.h"
//    #endif

    //! Name space LMD
    namespace LMD {
        //! Class to get information about Operative System
        class LMDPlatform {
          public :
                            LMDPlatform(void) { };
                           ~LMDPlatform(void) { };
            unsigned int    VersionMayor(void);
            unsigned int    VersionMenor(void);
            unsigned int    VersionRevision(void);
            LMD_PSTR        VersionString(void);
            LMD_PSTR        Nombre(void);
        };
    };



#endif
