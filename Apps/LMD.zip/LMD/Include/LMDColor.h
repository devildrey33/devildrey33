/*! \file  LMDColor.h
	\brief Object for RGB colors (windows / X11)
*/
#ifndef LMD_COLOR_H
    #define LMD_COLOR_H
    
    #include "LMDPlatform.h"

    #ifdef LMD_SO_X11

        #define LMD_RGB(r,g,b)          ((ULONG)(((BYTE)(b) | ((USHORT)((BYTE)(g)) << 8)) | (((ULONG)(BYTE)(r)) << 16)))
  //      #define LMD_RGB_GET_R(v)        (USHORT)((v & 0xFF0000) / 0x100)
//        #define LMD_RGB_GET_G(v)        (USHORT)(v & 0xFF00)
    //    #define LMD_RGB_GET_B(v)        (USHORT)((v & 0xFF) * 0x100)

        #define LOBYTE(w)           ((BYTE)(((ULONG)(w)) & 0xff))
        #define LMD_RGB_GET_B(rgb)      (LOBYTE(rgb))
        #define LMD_RGB_GET_G(rgb)      (LOBYTE(((USHORT)(rgb)) >> 8))
        #define LMD_RGB_GET_R(rgb)      (LOBYTE((rgb)>>16))
    #endif

    #ifdef LMD_SO_WINDOWS
        #define LMD_RGB(r,g,b)          ((ULONG)(((BYTE)(r) | ((USHORT)((BYTE)(g)) << 8)) | (((ULONG)(BYTE)(b)) << 16)))
        #define LMD_RGB_GET_R(v)        (USHORT)((v & 0xFF) * 0x100)
        #define LMD_RGB_GET_G(v)        (USHORT)(v & 0xFF00)
        #define LMD_RGB_GET_B(v)        (USHORT)((v & 0xFF0000) / 0x100)

//        #define LOBYTE(w)           ((BYTE)(((ULONG)(w)) & 0xff))
 //       #define GetRValue(rgb)      (LOBYTE(rgb))
 //       #define GetGValue(rgb)      (LOBYTE(((WORD)(rgb)) >> 8))
 //       #define GetBValue(rgb)      (LOBYTE((rgb)>>16))

    #endif

    //! Name space LMD
    namespace LMD {
        //! Object for RGB colors (windows / X11)
        class LMDColor {
          public : ///////////  Public members
              
                            //! Constructors
                            LMDColor(void)             : _Color(0)        {                                                                         };
                            LMDColor(ULONG nColor)     : _Color(nColor)   {                                                                         };
                            LMDColor(LMDColor &nColor) : _Color(nColor()) {                                                                         };
                            LMDColor(BYTE nRed, BYTE nGeen, BYTE nBlue)   { _Color = LMD_RGB(nRed, nGeen, nBlue);                                   };
            inline ULONG    operator = (ULONG nColor)                     { _Color = nColor;                                                        };
            inline ULONG    operator = (LMDColor &nColor)                 { _Color = nColor();                                                      };
            inline bool     operator == (ULONG nColor)                    { return (nColor == _Color);                                              };
            inline bool     operator == (LMDColor &nColor)                { return (nColor() == _Color);                                            };
            inline bool     operator != (ULONG nColor)                    { return (nColor != _Color);                                              };
            inline bool     operator != (LMDColor &nColor)                { return (nColor() != _Color);                                            };
            inline ULONG    operator() (void)                             { return _Color;                                                          };
            inline BYTE     Red(void)   const                             { return LMD_RGB_GET_R(_Color);                                           };
            inline void     Red(const BYTE nRed)                          { _Color = LMD_RGB(nRed, LMD_RGB_GET_G(_Color), LMD_RGB_GET_B(_Color));   };
            inline BYTE     Green(void) const                             { return LMD_RGB_GET_G(_Color);                                           };
            inline void     Green(const BYTE nGreen)                      { _Color = LMD_RGB(LMD_RGB_GET_R(_Color), nGreen, LMD_RGB_GET_B(_Color)); };
            inline BYTE     Blue(void)  const                             { return LMD_RGB_GET_B(_Color);                                           };
            inline void     Blue(const BYTE nBlue)                        { _Color = LMD_RGB(LMD_RGB_GET_R(_Color), LMD_RGB_GET_G(_Color), nBlue);  };
          private :
            ULONG          _Color;
        };                  //
        ////////////////////// END LMDColor
    

    }; // namespace LMD
    
    


#endif
