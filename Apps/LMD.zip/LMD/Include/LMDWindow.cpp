/*! \file    LMDWindow.cpp
	\brief   Root Window declarations (windows/X11).
*/
#include "LMDPlatform.h"
#include "LMDWindow.h"
#include "LMDString.h"

//! Namespace LMD
namespace LMD {

    #ifdef LMD_SO_WINDOWS
        LMDIDW LMDWindow::Create(const UINT nIDC, LMDBaseWnd *nParent, const LMD_PSTR nName, const LMD_PSTR nTitle, const int cX, const int cY, const int cWidth, const int cHeight, const bool nVisible) {
            if (_IDW != 0) Destroy();
            _RegisterClass(nName, 0, _StaticMessageHandler);
            _Width = cWidth;
            _Height = cHeight;
            _X = cX;
            _Y = cY;
            _Parent = nParent;
            HWND hParent = 0
            if (nParent != 0) hParent = nParent->IDW();
            _IDW = CreateWindowEx(0, nName, nTitle, WS_OVERLAPPEDWINDOW | WS_VISIBLE, cX, cY, cWidth, cHeight, hParent, 0, GetModuleHandle(0), this);
            Event_Create();
            return _IDW;
        }


        LRESULT CALLBACK LMDWindow::_StaticMessageHandler(HWND WndHandle, UINT uMsg, WPARAM wParam, LPARAM lParam) {
            switch (uMsg) {
                case WM_CREATE : {
                    LMDWindow *PreWindow = reinterpret_cast<LMDWindow *>(((CREATESTRUCT *)lParam)->lpCreateParams);
                    if (PreWindow == 0) return FALSE;
                    PreWindow->_IDW = WndHandle;
                    SetWindowLongPtr(WndHandle, GWLP_USERDATA, PtrToLong(PreWindow));
                    PreWindow->_MessageHandler(uMsg, wParam, lParam);
                    return TRUE;
                }

                default : {
                    LMDWindow *Window = reinterpret_cast<LMDWindow *>(LongToPtr(::GetWindowLongPtr(WndHandle, GWL_USERDATA)));
                    if (Window != 0) {
                        LRESULT Ret = Window->_MessageHandler(uMsg, wParam, lParam);
                        if (Ret == LMD_USE_DEFAULT_HANDLER) Ret = DefWindowProc(WndHandle, uMsg, wParam, lParam);
                        return Ret;
                    }
                    return DefWindowProc(WndHandle, uMsg, wParam, lParam);
                }
            }
        }
    #endif

    #ifdef LMD_SO_X11
//            #include "LMDDebug.h"

        LMDIDW LMDWindow::Create(const UINT nIDC, LMDBaseWnd *nParent, const LMD_PSTR nName, const LMD_PSTR nTitle, const int cX, const int cY, const int cWidth, const int cHeight, const bool nVisible) {
            Visual              *visual = 0;
            int                  depth = 0;
            XSetWindowAttributes attributes;
            LMDInstance<LMDBaseX11> X11Base;
            Display *Dis = X11Base()->DISPLAY();
            int Screen = X11Base()->Screen();
            visual = DefaultVisual(Dis, Screen);
            depth  = DefaultDepth(Dis, Screen);
            attributes.background_pixel      = Color_BackGround(); //XWhitePixel(Dis, Screen);
            attributes.border_pixel          = None; //BlackPixel(Dis, Screen);
            attributes.override_redirect     = 0;
            

            _Width = cWidth;
            _Height = cHeight;
            _X = cX;
            _Y = cY;
            _Parent = nParent;
            LMDIDW fParent = 0;
            if (nParent == 0) fParent = XRootWindow(Dis, Screen);
            else              fParent = nParent->IDW();

            LMDStringMB TxtTitle(nTitle); // TaskBar
            LMDStringMB TxtName(nName); // TitleBar



            _IDW = XCreateWindow(Dis, fParent, cX, cY, cWidth, cHeight, 0, depth, InputOutput, visual, CWBackPixel | CWBorderPixel | CWOverrideRedirect, &attributes);

/*            XClassHint  NombreClase;
            XGetClassHint(Dis, _IDW, &NombreClase);

            NombreClase.res_name  = TxtName();
            NombreClase.res_class = TxtName();

            XSetClassHint(Dis, _IDW, &NombreClase);*/

//                LMDDebug.printf("Window -> Title : '%s' IDW : '%x'\n", TxtTitle(), _IDW);

            XSetStandardProperties(Dis, _IDW, TxtName(), TxtTitle(), None, 0, 0, 0);
            //StructureNotifyMask
            XSelectInput(Dis, _IDW, ExposureMask | ButtonPressMask | ButtonReleaseMask | KeyPressMask | KeyReleaseMask | FocusChangeMask | PointerMotionMask | EnterWindowMask | LeaveWindowMask | StructureNotifyMask);
            XSetWMProtocols(Dis, _IDW, X11Base()->Protocols(), X11Base()->ProtocolsCount());

//            XSetWMProtocols(Dis, _IDW, X11Base()->WM_TAKE_FOCUS(), 1);

/*            XFontStringuct *fontinfo = XLoadQueryFont(Dis, "6x10");
            XGCValues gr_values;
            gr_values.font = fontinfo->fid;
            gr_values.function = GXcopy;
            gr_values.plane_mask = AllPlanes;
            gr_values.foreground = BlackPixel(Dis, Screen);
            gr_values.background = WhitePixel(Dis, Screen);
            gc = XCreateGC(Dis, _IDW, GCFont | GCFunction | GCPlaneMask | GCForeground | GCBackground, &gr_values);*/
//            gc = XCreateGC(Dis, _IDW, 0,0);
//            XClearWindow(Dis, _IDW);
            
            XMapWindow(Dis, _IDW);

            XMoveWindow(Dis, _IDW, cX, cY);

            X11Base()->AddBaseWnd(this);
            Event_Create();
//            LMDScene Scene;
            Scene.CreateScene(this, cWidth, cHeight);
            Repaint();
//            Scene.Free();

            return _IDW;
        }
    #endif

};







