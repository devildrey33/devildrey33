/*! \file    LMDString.h
	\brief   Strings (windows/linux).
*/
#ifndef LMD_STRING_H
#define LMD_STRING_H

#include "LMDPlatform.h"


#define LMD_STR_MAX static_cast<unsigned int>(-1)

//! Name space LMD
namespace LMD {

    // Falta por agregar :
    // - operadores y conStringuctores para valores enteros y decimales
    // - funcion estilo sprintf


    //! Base class for all string types
    class LMDStringBase {
      public : /////// Public members

                    LMDStringBase(void) : _Size(0) { };
        inline UINT Size(void) const { return _Size; };

      protected : //// Protected members
        int        _Cmp(const char *s1, const char *s2) const;
        int        _Cmp(const wchar_t *s1, const wchar_t *s2) const;
        int        _CmpI(const char *s1, const char *s2) const;
        int        _CmpI(const wchar_t *s1, const wchar_t *s2) const;
        UINT       _Size;
    };

    //! Class for MultyBite strings
    class LMDStringMB;

    //! Class for WideChar strings
    class LMDStringWC : public LMDStringBase {
      public : /////////////// Public members

                            LMDStringWC(void)                   : LMDStringBase(), _String(0) {                        };
                            LMDStringWC(const char *nString)    : LMDStringBase(), _String(0) { CopyString(nString);   };
                            LMDStringWC(const wchar_t *nString) : LMDStringBase(), _String(0) { CopyString(nString);   };
                            LMDStringWC(LMDStringWC &nString)   : LMDStringBase(), _String(0) { CopyString(nString()); };
                            LMDStringWC(LMDStringMB &nString);
                           ~LMDStringWC(void)                                                 { Delete();          };

        void                Delete(void);

        UINT                CopyString(const wchar_t *nString, const UINT nSize = LMD_STR_MAX);
        UINT                CopyString(const char *nString, const UINT nSize = LMD_STR_MAX);
        UINT                AddString(const wchar_t *nString, const UINT nSize = LMD_STR_MAX);
        UINT                AddString(const char *nString, const UINT nSize = LMD_STR_MAX);

        inline wchar_t     *Str(void) { return _String; };
        LMDStringWC         SubStr(const UINT nStartPos, const UINT nSize);

        bool                Compare(const wchar_t *nString, bool Binary = true) const;
        bool                Compare(const char *nString, bool Binary = true) const;

        LMDStringWC        &operator = (LMDStringMB &cString);
        inline LMDStringWC &operator = (LMDStringWC &cString)   { CopyString(cString(), cString.Size()); return *this; };
        inline LMDStringWC &operator = (const wchar_t *cString) { CopyString(cString);                   return *this; };
        inline LMDStringWC &operator = (const char *cString)    { CopyString(cString);                   return *this; };

        bool                operator == (LMDStringMB &cString)   const;
        inline bool         operator == (LMDStringWC &cString)   const { return Compare(cString());  };
        inline bool         operator == (const wchar_t *cString) const { return Compare(cString);    };
        inline bool         operator == (const char *cString)    const { return Compare(cString);    };
        bool                operator != (LMDStringMB &cString)   const;
        inline bool         operator != (LMDStringWC &cString)   const { return !Compare(cString()); };
        inline bool         operator != (const wchar_t *cString) const { return !Compare(cString);   };
        inline bool         operator != (const char *cString)    const { return !Compare(cString);   };

        LMDStringWC        &operator += (LMDStringMB &nString);
        inline LMDStringWC &operator += (LMDStringWC &nString)    { AddString(nString()); return *this; };
        inline LMDStringWC &operator += (const wchar_t *nString)  { AddString(nString);   return *this; };
        inline LMDStringWC &operator += (const char *nString)     { AddString(nString);   return *this; };

        inline wchar_t     *operator () (void) const      { return _String;       };
        inline wchar_t     &operator [] (const UINT nPos) { return _String[nPos]; };

      private : //////////// Private members

        wchar_t           *_String;
    };



    //! Class for MultyBite strings
    class LMDStringMB : public LMDStringBase {
      public : /////////////// Public members

                            LMDStringMB(void)                   : LMDStringBase(), _String(0) {                        };
                            LMDStringMB(const char *nString)    : LMDStringBase(), _String(0) { CopyString(nString);   };
                            LMDStringMB(const wchar_t *nString) : LMDStringBase(), _String(0) { CopyString(nString);   };
                            LMDStringMB(LMDStringMB &nString)   : LMDStringBase(), _String(0) { CopyString(nString()); };
                            LMDStringMB(LMDStringWC &nString)   : LMDStringBase(), _String(0) { CopyString(nString()); };
                           ~LMDStringMB(void)                                                 { Delete();              };

        void                Delete(void);

        UINT                CopyString(const char *nString, const UINT nSize = LMD_STR_MAX);
        UINT                CopyString(const wchar_t *nString, const UINT nSize = LMD_STR_MAX);
        UINT                AddString(const char *nString, const UINT nSize = LMD_STR_MAX);
        UINT                AddString(const wchar_t *nString, const UINT nSize = LMD_STR_MAX);

        inline char        *Str(void) { return _String; };
        LMDStringMB         SubStr(const UINT nPosInicio, const UINT nSize);

        bool                Compare(const char *nString, bool Binary = true) const;
        bool                Compare(const wchar_t *nString, bool Binary = true) const;

        inline LMDStringMB &operator = (LMDStringMB &cString)   { this->CopyString(cString(), cString.Size()); return *this; };
        inline LMDStringMB &operator = (LMDStringWC &cString)   { this->CopyString(cString(), cString.Size()); return *this; };
        inline LMDStringMB &operator = (const wchar_t *cString) { this->CopyString(cString);                   return *this; };
        inline LMDStringMB &operator = (const char *cString)    { this->CopyString(cString);                   return *this; };

        inline bool         operator == (LMDStringMB &cString)   const { return Compare(cString());  };
        inline bool         operator == (LMDStringWC &cString)   const { return Compare(cString());  };
        inline bool         operator == (const char *cString)    const { return Compare(cString);    };
        inline bool         operator == (const wchar_t *cString) const { return Compare(cString);    };
        inline bool         operator != (LMDStringMB &cString)   const { return !Compare(cString()); };
        inline bool         operator != (LMDStringWC &cString)   const { return !Compare(cString()); };
        inline bool         operator != (const char *cString)    const { return !Compare(cString);   };
        inline bool         operator != (const wchar_t *cString) const { return !Compare(cString);   };

        inline LMDStringMB &operator += (LMDStringMB &nString)    { AddString(nString()); return *this; };
        inline LMDStringMB &operator += (LMDStringWC &nString)    { AddString(nString()); return *this; };
        inline LMDStringMB &operator += (const char *nString)     { AddString(nString);   return *this; };
        inline LMDStringMB &operator += (const wchar_t *nString)  { AddString(nString);   return *this; };

        inline char        *operator () (void) const      { return _String;       };
        inline char        &operator [] (const UINT nPos) { return _String[nPos]; };

      private : //////////// Private members

        char              *_String;
    };
};


#ifdef LMD_UNICODE
    #define LMDString LMDStringWC
#else
    #define LMDString LMDStringMB
#endif

#endif
