/*! \file  LMDFont.h
	\brief Basic font for all platforms
*/
#ifndef LMD_FONT_H
    #define LMD_FONT_H

    #include "LMDPlatform.h"

    #ifdef LMD_SO_X11
        #include "Linux/LMDBaseX11.h"
        typedef XFontSet   LMDFontType;
    #endif

    #ifdef LMD_SO_WINDOWS
        typedef HFONT      LMDFontType;
    #endif


    //! Name space LMD
    namespace LMD {
        //! Basic Font
        class LMDFont {
          public : ///////////////////////////  Public members
              
                                            //! Constructor
                                            LMDFont(void);
                           
                                            //! Destructor
                                           ~LMDFont(void);

            void                            Create(void);

            void                            Destroy(void);

            inline int                      LineHeight(void)  { return _LineHeight; };

            inline LMDFontType              operator() (void) { return _Font;       };
          private:

            LMDFontType                    _Font;

            int                            _LineHeight;
        };                                  //
        ////////////////////////////////////// END LMDFont
    
    }; // namespace LMD
    
    
    


#endif
