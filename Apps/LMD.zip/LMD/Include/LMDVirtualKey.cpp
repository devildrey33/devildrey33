/*! \file LMDVirtualKey.cpp
	\brief VirtualKeys declarations for LMD
*/
#ifndef LMD_VIRTUALKEY_CPP
    #define LMD_VIRTUALKEY_CPP

    #include "LMDVirtualKey.h"
    #include <ctype.h>
    #ifdef LMD_SO_X11
        #include </usr/include/X11/X.h>
    #endif

    namespace LMD {

        #ifdef LMD_SO_WINDOWS
            #define KEY_MASK 0x8000

            LMDVirtualKey::LMDVirtualKey(void) : _VirtualCode(0) , _Mask(0) {
                for (UINT i = 0; i < 256; i++) _KeyBoard[i] = 0;
            };

            LMDVirtualKey::LMDVirtualKey(UINT nVirtualCode, UINT nMask) : _VirtualCode(nVirtualCode), _Mask(nMask) {
                GetKeyboardState(_KeyBoard);
            };

            void LMDVirtualKey::Set(UINT nVirtualCode, UINT nMask)  {
                _VirtualCode = nVirtualCode;
                _Mask = nMask;
                BOOL R = GetKeyboardState(_KeyBoard);
            };

            bool LMDVirtualKey::Control(void) const {
                if (_KeyBoard[VK_CONTROL] & KEY_MASK) return true;
                return false;
            }

            bool LMDVirtualKey::Shift(void) const {
                if (_KeyBoard[VK_SHIFT] & KEY_MASK) return true;
                return false;
            }

/*            bool LMDVirtualKey::Alt(void) const {
                if (_KeyBoard[VK_MENU] & KEY_MASK) return true;
                return false;
            }*/

            bool LMDVirtualKey::NumLock(void) const {
                return (_KeyBoard[VK_NUMLOCK]);
            }

            bool LMDVirtualKey::CapsLock(void) const {
                return (_KeyBoard[VK_CAPITAL]);
            }

/*            bool LMDVirtualKey::ScrollLock(void) const {
                return (_KeyBoard[VK_SCROLL]);
            }*/

/*            bool LMDVirtualKey::Win(void) const {
                if (_Mask & 24) {
                    if (_KeyBoard[VK_LWIN] == true) return true;
                    if (_KeyBoard[VK_RWIN] == true) return true;
                }
                return false;
            }*/

            const LMD_STR LMDVirtualKey::Char(void) {
                LMD_STR Ret = _VirtualCode;
                BYTE CL = CapsLock();//CapsLock();
                BYTE SH = Shift();//Shift();
                if (CL == 0 && SH == 0)
                    Ret = tolower(Ret);
                if (CL != 0 && SH != 0)
                    Ret = tolower(Ret);
                return Ret;
            }
        #endif


        #ifdef LMD_SO_X11
            LMDVirtualKey::LMDVirtualKey(void) : _VirtualCode(0) , _Mask(0) {
            };

            LMDVirtualKey::LMDVirtualKey(UINT nVirtualCode, UINT nMask) : _VirtualCode(nVirtualCode), _Mask(nMask) {
            };

            void LMDVirtualKey::Set(UINT nVirtualCode, UINT nMask)  {
                _VirtualCode = nVirtualCode;
                _Mask = nMask;
            };

            bool LMDVirtualKey::Control(void) const {
                return (_Mask & ControlMask);
            }

            bool LMDVirtualKey::Shift(void) const {
                return (_Mask & ShiftMask);
            }

            bool LMDVirtualKey::NumLock(void) const {
                return (_Mask & Mod2Mask);
            }

            bool LMDVirtualKey::CapsLock(void) const {
                return (_Mask & LockMask);
            }

            const LMD_STR LMDVirtualKey::Char(void) {
                LMD_STR Ret = _VirtualCode;
                BYTE CL = CapsLock();//CapsLock();
                BYTE SH = Shift();//Shift();
                if (CL == 0 && SH == 0)
                    Ret = tolower(Ret);
                if (CL != 0 && SH != 0)
                    Ret = tolower(Ret);
                return Ret;
            }
        #endif
    };

#endif