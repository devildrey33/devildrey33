/*! \file    LMDBaseWnd.cpp
	\brief   Basic window declarations
*/
#include "LMDPlatform.h"
#include "LMDBaseWnd.h"

#include "stdio.h"

//! Macro para obtener la coordenada X de un LPARAM
#ifndef GET_X_LPARAM
	#define GET_X_LPARAM(lp)			((int)(short)LOWORD(lp))
#endif
//! Macro para obtener la coordenada Y de un LPARAM
#ifndef GET_Y_LPARAM
	#define GET_Y_LPARAM(lp)			((int)(short)HIWORD(lp))
#endif

#define LMD_BASEWND_DEBUG(func...)  LMD_ONLY_DEBUG(LMD_PRINT_DEBUG(func))


namespace LMD {

    #ifdef LMD_SO_WINDOWS
        LMDBaseWnd::LMDBaseWnd(void) : _IDW(0), _IDC(0), _MouseInner(false), _DoubleClickTime(0), _Parent(0), _X(0), _Y(0), _Width(0), _Height(0), _Rgn(0) {
            Color_BackGround = LMD_RGB(255, 255, 255);
        };

        void LMDBaseWnd::SetRegion(LMDRegion *nRegion) {
            SetWindowRgn(_IDW, nRegion->operator()());
        }

        BOOL LMDBaseWnd::Destroy(void) {
            if (_IDW == 0) return FALSE;
            LMD_BASEWND_DEBUG("LMDBaseWnd::Destroy(IDV -> %d)\n", _IDW);
            if (Event_Destroy() == TRUE) {
                DestroyWindow(_IDW);
                _IDW = 0;
                return TRUE;
            }
            return false;
        };


        void LMDBaseWnd::Visible(const bool nShow) {
        };


        void LMDBaseWnd::SetFocus(void) {
            ::SetFocus(_IDW);
        };

        bool LMDBaseWnd::HasFocus(void) const {
            HWND WndFocus = GetFocus(_IDW);
            if (WndFocus == _IDW) return true;
            return false;
        };

        void LMDBaseWnd::Move(const int cX, const int cY) {
            RECT RC;
            GetClientRect(_IDW, &RC);
            MoveWindow(_IDW, cX, cY, RC.right, RC.bottom, FALSE);
        };

        void LMDBaseWnd::Repaint(void) {
            HDC hDC = GetDC(_IDW);
            Event_Paint();
            Scene.PaintScene(0, 0, _Width, _Height);
            ReleaseDC(_IDW, hDC);
        }

        ATOM LMDBaseWnd::_RegisterClass(const LMD_PSTR nNombre, const int nIconoRecursos, WNDPROC WindowProcedureInicial) {
            WNDCLASSEX WndClass;
            WndClass.cbSize        = sizeof(WNDCLASSEX);
            WndClass.style         = 0;
            WndClass.lpfnWndProc   = (WNDPROC)WindowProcedureInicial;
            WndClass.cbClsExtra    = 0;
            WndClass.cbWndExtra    = 0;
            WndClass.hInstance     = GetModuleHandle(NULL);
            if (nIconoRecursos != 0) {
                WndClass.hIcon     = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(nIconoRecursos));
                WndClass.hIconSm   = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(nIconoRecursos));
            }
            else {
                WndClass.hIcon     = LoadIcon(GetModuleHandle(NULL), IDI_APPLICATION);
                WndClass.hIconSm   = LoadIcon(GetModuleHandle(NULL), IDI_APPLICATION);
            }
            WndClass.hCursor       = LoadCursor (0, IDC_ARROW);
            WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
            WndClass.lpszMenuName  = 0;
            WndClass.lpszClassName = nNombre;
            return RegisterClassEx(&WndClass);
        }



        UINT LMDBaseWnd::_Win_Event_Mouse_ButtonRelease(const UINT Button, LPARAM lParam) {
            DWORD CT  = 0;
            UINT  Ret = 0;
            CT = GetTickCount();
            Ret = Event_Mouse_ButtonRelease(Button, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
            if (CT < _DoubleClickTime + GetDoubleClickTime()) {
                Ret = Event_Mouse_DoubleClick(Button, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
                _DoubleClickTime = 0;
            }
            else {
                _DoubleClickTime = CT;
            }
            return Ret;
        };

        UINT LMDBaseWnd::_Win_Event_Mouse_ButtonPress(const UINT Button, LPARAM lParam) {
            return Event_Mouse_ButtonPress(Button, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
        };

        UINT LMDBaseWnd::_Win_Event_Mouse_Move(LPARAM lParam) {
            if (_MouseInner == false) {
                TRACKMOUSEEVENT Trk;
                Trk.cbSize = sizeof(TRACKMOUSEEVENT);
                Trk.dwFlags = TME_LEAVE;
                Trk.hwndTrack = _IDW;
                TrackMouseEvent(&Trk);
                _MouseInner = true;
                Event_Mouse_Enter();
            }
            return Event_Mouse_Move(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
        };

        UINT LMDBaseWnd::_Win_Event_Mouse_Wheel(WPARAM wParam) {
            if (static_cast<short>(HIWORD(wParam)) == 120)  return Event_Mouse_Wheel(1);
            if (static_cast<short>(HIWORD(wParam)) == -120) return Event_Mouse_Wheel(-1);
            return 0;
        };

        UINT LMDBaseWnd::_Win_Event_Mouse_Leave(void) {
            _MouseInner = false;
            return Event_Mouse_Leave();
        };

        UINT LMDBaseWnd::_Win_Event_KeyPress(WPARAM wParam, LPARAM lParam) {
            LMDVirtualKey VK(static_cast<UINT>(wParam), static_cast<UINT>(lParam));
            return Event_KeyPress(VK);
        };

        UINT LMDBaseWnd::_Win_Event_KeyRelease(WPARAM wParam, LPARAM lParam) {
            LMDVirtualKey VK(static_cast<UINT>(wParam), static_cast<UINT>(lParam));
            return Event_KeyRelease(VK);
        };


        UINT LMDBaseWnd::_Win_Event_Resize(LPARAM lParam) {
            RECT *pWinRect = reinterpret_cast<RECT *>(lParam);
            UINT nWidth = pWinRect->right - pWinRect->left;
            UINT nHeight = pWinRect->bottom - pWinRect->top;
            UINT Ret = Event_Resize(nWidth, nHeight);
            _X = pWinRect->left;
            _Y = pWinRect->top;
            _Width = nWidth;
            _Height = nHeight;
            Scene.ResizeScene(nWidth, nHeight);
            return Ret;
        };

        UINT LMDBaseWnd::_Win_Event_Move(LPARAM lParam) {
            _X = LOWORD(lParam);
            _Y = HIWORD(lParam);
            return Event_Move(_X, _Y)
        }

        UINT LMDBaseWnd::_MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam) {
            switch (uMsg) {
                case WM_CLOSE :                     Destroy();                                                          break;
                case WM_KEYDOWN :                   return _Win_Event_KeyPress(wParam, lParam);
                case WM_KEYUP :                     return _Win_Event_KeyPress(wParam, lParam);
                case WM_LBUTTONDOWN :               return _Win_Event_Mouse_ButtonPress(1, lParam);
                case WM_RBUTTONDOWN :               return _Win_Event_Mouse_ButtonPress(3, lParam);
                case WM_MBUTTONDOWN :               return _Win_Event_Mouse_ButtonPress(2, lParam);
                case WM_XBUTTONDOWN :               return _Win_Event_Mouse_ButtonPress(HIWORD(wParam) + 3, lParam);
                case WM_LBUTTONUP :                 return _Win_Event_Mouse_ButtonRelease(1, lParam);
                case WM_RBUTTONUP :                 return _Win_Event_Mouse_ButtonRelease(3, lParam);
                case WM_MBUTTONUP :                 return _Win_Event_Mouse_ButtonRelease(2, lParam);
                case WM_XBUTTONUP :                 return _Win_Event_Mouse_ButtonRelease(HIWORD(wParam) + 3, lParam);
                case WM_MOUSEMOVE :                 return _Win_Event_Mouse_Move(lParam);
                case WM_MOUSELEAVE :                return _Win_Event_Mouse_Leave();
                case WM_MOUSEWHEEL :                return _Win_Event_Mouse_Wheel(wParam);
                case WM_SIZING :                    return _Win_Event_Resize(lParam);
                case WM_MOVE :                      return _Win_Event_Move(lParam);
                case WM_SETFOCUS :                  return Event_GetFocus();
                case WM_KILLFOCUS :                 return Event_LostFocus();

//                case WM_PAINT : return 0;

            }
            return LMD_USE_DEFAULT_HANDLER;
        }
    #endif



    #ifdef LMD_SO_X11
        LMDBaseWnd::LMDBaseWnd(void) : _IDW(0), _IDC(0), _DoubleClickTime(0), _Parent(0), _X(0), _Y(0), _Width(0), _Height(0), _Rgn(0), _MouseInner(false) {
            Color_BackGround = LMD_RGB(255, 255, 255);
        };

        void LMDBaseWnd::SetRegion(LMDRegion *nRegion) {
            LMDInstance<LMDBaseX11> X11Base;
            Display *Dis = X11Base()->DISPLAY();
            if (nRegion == 0) {
                LMDRegion R;
                R.CreateRect(0, 0, _Width, _Height);
                XSetRegion(Dis, Scene._PaintContext, R());
                _Rgn = 0;
                return;
            }
            _Rgn = nRegion;
            XSetRegion(Dis, Scene._PaintContext, _Rgn->operator ()());
        }


        BOOL LMDBaseWnd::Destroy(void) {
            if (_IDW == 0) return FALSE;
            LMD_BASEWND_DEBUG("LMDBaseWnd::Destroy(IDV -> %d)\n", _IDW);
            if (Event_Destroy() == TRUE) {
                SetRegion(0);
                LMDInstance<LMDBaseX11> X11Base;
                X11Base()->DeleteBaseWnd(_IDW);
                _IDW = 0;
                return TRUE;
            }
            return FALSE;
        };


        void LMDBaseWnd::Visible(const bool nShow) {
            LMDInstance<LMDBaseX11> X11Base;

            if (nShow == true) XMapWindow(X11Base()->DISPLAY(), _IDW);
            else {
//                XLowerWindow(X11Base()->DISPLAY(), _IDW);
  //              XUnmapSubwindows(X11Base()->DISPLAY(), _IDW);
                XUnmapWindow(X11Base()->DISPLAY(), _IDW);
            }
            XFlush(X11Base()->DISPLAY());
        };


        bool LMDBaseWnd::HasFocus(void) const {
            LMDInstance<LMDBaseX11> X11Base;
            Window WndFocus = 0;
            int    Revert   = 0;
            XGetInputFocus(X11Base()->DISPLAY(), &WndFocus, &Revert);
            if (WndFocus == _IDW) return true;
            return false;
        }

        void LMDBaseWnd::SetFocus(void) {
            LMDInstance<LMDBaseX11> X11Base;
            Display *dis = X11Base()->DISPLAY();
//                    printf("Asignar foco -> IDW : '%x', DISPLAY : '%x'\n", _IDW, X11Base()->DISPLAY());
            XSetInputFocus(dis, _IDW, RevertToNone, CurrentTime);
            XRaiseWindow(dis, _IDW);
        };


        void LMDBaseWnd::Move(const int cX, const int cY) {
            // usar WM_MOVE en windows falta ver tema de repintados
            LMDInstance<LMDBaseX11> X11Base;
            XMoveWindow(X11Base()->DISPLAY(), _IDW, cX, cY);
            _X = cX;
            _Y = cY;
        };


        void LMDBaseWnd::Repaint(void) {
            /*if (Rgn.IsEmpty() == false && _Parent != 0) {


                LMDInstance<LMDBaseX11> X11Base;
                Display *Dis = X11Base()->DISPLAY();
  //              LMDRegion R;
//                              Region RetR = XCreateRegion();
//                R.CreateRect(0, 0, Width(), Height());
//                                XXorRegion(R(), Rgn(), RetR);
//                XSetRegion(Dis, _Parent->Scene._PaintContext, R());
                XCopyArea(Dis, _Parent->Scene._PixMap, Scene._PixMap, _Parent->Scene._PaintContext, _Parent->X(), _Parent->Y(), _Parent->Width(), _Parent->Height(), _Parent->X(), _Parent->Y());
//                R.CreateRect(0, 0, _Parent->Width(), _Parent->Height());
  //              XSetRegion(Dis, _Parent->Scene._PaintContext, R());
//                                XDestroyRegion(RetR);

                XSetRegion(Dis, Scene._PaintContext, Rgn());

            }*/

            Event_Paint();
            Scene.PaintScene(0, 0, _Width, _Height);

        }


        UINT LMDBaseWnd::_X11_Event_KeyPress(XKeyEvent &Event) {
            LMDVirtualKey VK;
            char      String[32];
            KeySym    Tecla;
            XLookupString(&Event, String, 32, &Tecla, 0);
            VK.Set(String[0], Event.state);
            return Event_KeyPress(VK);
        }


        UINT LMDBaseWnd::_X11_Event_KeyRelease(XKeyEvent &Event) {
            LMDVirtualKey VK;
            char      String[32];
            KeySym    Tecla;
            XLookupString(&Event, String, 32, &Tecla, 0);
            VK.Set(String[0], Event.state);
            return Event_KeyRelease(VK);
        }


        UINT LMDBaseWnd::_X11_Event_Mouse_ButtonPress(XButtonEvent &Event) {
            if (_Rgn != 0 && _Parent != 0) {
                if (_Rgn->PointInRegion(Event.x, Event.y) == false) {
                    return _Parent->_X11_Event_Mouse_ButtonPress(Event);
                }
            }
            UINT nButton = 0;
            if      (Event.button == 4) return Event_Mouse_Wheel(1);
            else if (Event.button == 5) return Event_Mouse_Wheel(-1);
            else {
                nButton = Event.button;
                if (nButton == 8) nButton = 4;
                if (nButton == 9) nButton = 5;
                return Event_Mouse_ButtonPress(nButton, Event.x, Event.y);
            }
            return 0;
        }


        UINT LMDBaseWnd::_X11_Event_Mouse_ButtonRelease(XButtonEvent &Event) {
            if (_Rgn != 0 && _Parent != 0) {
                if (_Rgn->PointInRegion(Event.x, Event.y) == false) {
                    return _Parent->_X11_Event_Mouse_ButtonRelease(Event);
                }
            }
            UINT nButton = 0;
            UINT Ret     = 0;
            if (Event.button != 4 && Event.button != 5) {
                nButton = Event.button;
                if (nButton == 8) nButton = 4;
                if (nButton == 9) nButton = 5;
                Ret = Event_Mouse_ButtonRelease(nButton, Event.x, Event.y);
                // Doubleclick simulation
                if (Event.time < _DoubleClickTime + 1000) {
                    Ret = Event_Mouse_DoubleClick(nButton, Event.x, Event.y);
                    _DoubleClickTime = 0;
                }
                else {
                    _DoubleClickTime = Event.time;
                }
                return Ret;
            }
            return 0;
        }


        UINT LMDBaseWnd::_X11_Event_ClientMessage(XClientMessageEvent &Event) {
            LMDInstance<LMDBaseX11> X11Base;
            Atom *nProtocols = X11Base()->Protocols();
            if (Event.data.l[0] == nProtocols[0]) { // WM_WINDOW_DESTROY -> Protocols[0]
                Destroy();
            }
        }

        
        UINT LMDBaseWnd::_X11_Event_ConfigureNotify(XConfigureEvent &Event) {
//            LMD_BASEWND_DEBUG("CN : %d\n", Event.value_mask);
            UINT Ret = 0;
            if (Event.x != _X || Event.y != _Y) {
                _X = Event.x;
                _Y = Event.y;
                Ret = Event_Move(_X, _Y);
            }

            if (Event.width != _Width || Event.height != _Height) {
                _Width = Event.width;
                _Height = Event.height;
                Event_Resize(Event.width, Event.height);
                Scene.ResizeScene(Event.width, Event.height);
//                LMD_BASEWND_DEBUG("Resize : %d %d\n", Event.width, Event.height);
            }
            return Ret;
        }


/*        UINT LMDBaseWnd::_X11_Event_Mouse_Enter(XCrossingEvent &Event) {
            if (_Rgn != 0 && _Parent != 0) {
                if (_Rgn->PointInRegion(Event.x, Event.y) == false) {
                    return _Parent->_X11_Event_Mouse_Enter(Event);
                }
            }
            return Event_Mouse_Enter();
        }
        */

        UINT LMDBaseWnd::_X11_Event_Mouse_Leave(XCrossingEvent &Event) {
            if (_MouseInner == true) {
                _MouseInner = false;
                return Event_Mouse_Leave();
            }
            return 0;
        }


        UINT LMDBaseWnd::_X11_Event_Mouse_Move(XMotionEvent &Event) {
            if (_Rgn != 0 && _Parent != 0) {
                if (_Rgn->PointInRegion(Event.x, Event.y) == false) {
                    if (_MouseInner == true) {
                        _MouseInner = false;
                        Event_Mouse_Leave();
                    }
                    return _Parent->_X11_Event_Mouse_Move(Event);
                }
            }
            if (_MouseInner == false) {
                _MouseInner = true;
                Event_Mouse_Enter();
            }
            return Event_Mouse_Move(Event.x, Event.y);
        }

       /* UINT LMDBaseWnd::_X11_Event_Resize(XResizeRequestEvent &Event) {
            UINT Ret = Event_Resize(Event.width, Event.height);
            LMD_BASEWND_DEBUG("Resize : %d %d\n", Event.width, Event.height);
            _Width = Event.width;
            _Height = Event.height;
//            XResizeWindow(Event.display, _IDW, _Width, _Height);
            Scene.ResizeScene(Event.width, Event.height);
  //          XMapRaised(Event.display, _IDW);
            XClearArea(Event.display, _IDW, 0, 0, 0, 0, false);
            XFlush(Event.display);
//            Repaint();
            return Ret;
        }*/


        UINT LMDBaseWnd::_MessageHandler(XEvent &Event) {

            switch (Event.type) {
                case KeyPress :                     return _X11_Event_KeyPress(Event.xkey);
                case KeyRelease :                   return _X11_Event_KeyRelease(Event.xkey);

                case ButtonPress :                  return _X11_Event_Mouse_ButtonPress(Event.xbutton);
                case ButtonRelease :                return _X11_Event_Mouse_ButtonRelease(Event.xbutton);

                case FocusIn :                      return Event_GetFocus();
                case FocusOut :                     return Event_LostFocus();

                case MotionNotify :                 return _X11_Event_Mouse_Move(Event.xmotion);

//                case EnterNotify :                  return _X11_Event_Mouse_Enter(Event.xcrossing);
                case LeaveNotify :                  return _X11_Event_Mouse_Leave(Event.xcrossing);

//                case ResizeRequest :                return _X11_Event_Resize(Event.xresizerequest);
                                                    // Get when window is destroyed
                case ClientMessage :                return _X11_Event_ClientMessage(Event.xclient);

                case ConfigureNotify :              return _X11_Event_ConfigureNotify(Event.xconfigure);



////////////////// TEST ZONE //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                case GraphicsExpose :
  //                  LMD_BASEWND_DEBUG("GE\n");
/*                    Scene.CreateScene(_IDW, Event.xgraphicsexpose.x, Event.xgraphicsexpose.y, Event.xgraphicsexpose.width, Event.xgraphicsexpose.height);
                    Event_Paint(Scene);
                    Scene.PaintScene(Event.xgraphicsexpose.x, Event.xgraphicsexpose.y);
                    Scene.Free();*/
          //          return 0;
    //            case NoExpose :
      //              LMD_BASEWND_DEBUG("NE\n");
        //            return 0;
                case Expose :
//                    if (Event.xexpose.count == 0) {
/*                        LMDPaint WndPaint;
                        WndPaint.GetWndPaintContext(Event.xexpose.window);
                        LMDPaint Buffer;
                        Buffer.CreateCompatiblePaintContext(Event.xexpose.window, Event.xexpose.width, Event.xexpose.height);
                        Event_Paint(Buffer);
//                        Event_Paint(WndPaint);
                        // falta pintar el buffer en la ventana
//                        XClearWindow(Event.xexpose.display, _IDW);
                        WndPaint.Copy(0, 0, Event.xexpose.window, 0, 0, Event.xexpose.width, Event.xexpose.height);
//                        Buffer.Copy(0, 0, Event.xexpose.window, 0, 0, Event.xexpose.width, Event.xexpose.height);
                        Buffer.Free();
                        WndPaint.Free();*/
//                        LMD_BASEWND_DEBUG("Paint : %d, %d, %d, %d\n", Event.xexpose.x, Event.xexpose.y, Event.xexpose.width, Event.xexpose.height);
  //                      Scene.CreateScene(Event.xexpose.window, Event.xexpose.x, Event.xexpose.y, Event.xexpose.width, Event.xexpose.height);
//                        XClearWindow(Event.xexpose.display, Event.xexpose.window);
                        
                        if (Scene._NeedRepaint == true) {

                           /* if (Rgn.IsEmpty() == false && _Parent != 0) {
                                LMDRegion R;
  //                              Region RetR = XCreateRegion();
                                R.CreateRect(0, 0, Width(), Height());
//                                XXorRegion(R(), Rgn(), RetR);
                                XSetRegion(Event.xexpose.display, _Parent->Scene._PaintContext, R());
                                XCopyArea(Event.xexpose.display, _Parent->Scene._PixMap, Scene._PixMap, _Parent->Scene._PaintContext, _Parent->X(), _Parent->Y(), _Parent->Width(), _Parent->Height(), _Parent->X(), _Parent->Y());
                                R.CreateRect(0, 0, _Parent->Width(), _Parent->Height());
                                XSetRegion(Event.xexpose.display, _Parent->Scene._PaintContext, R());
//                                XDestroyRegion(RetR);

                                XSetRegion(Event.xexpose.display, Scene._PaintContext, Rgn());
                            }*/
                            Event_Paint();
                            Scene._NeedRepaint = false;
                        }
                        Scene.PaintScene(Event.xexpose.x, Event.xexpose.y, Event.xexpose.width, Event.xexpose.height);
//                        Scene.Free();
  //                  }
                    return 0;

            }
            return 0;
        }

    #endif


};







