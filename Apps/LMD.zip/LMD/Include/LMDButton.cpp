/*! \file  LMDButton.cpp
	\brief Declarations for LMDButton class
*/
#include "LMDButton.h"


namespace LMD {

    #ifdef LMD_SO_X11

        void LMDButton::CreateButton(LMDBaseWnd *cParent, const UINT cIDC, LMD_PSTR cText, const int cX, const int cY, const UINT cWidth, const UINT cHeight) {
            Visual              *visual = NULL;
            int                  depth = 0;
            XSetWindowAttributes attributes;
            LMDInstance<LMDBaseX11> X11Base;
            Display *Dis = X11Base()->DISPLAY();
            int Screen = X11Base()->Screen();
            visual = DefaultVisual(Dis, Screen);
            depth  = DefaultDepth(Dis, Screen);
            attributes.background_pixel      = cParent->Color_BackGround(); //XWhitePixel(Dis, Screen); //ParentRelative
            attributes.border_pixel          = None; //BlackPixel(Dis, Screen);
            attributes.override_redirect     = 0;
//            attributes.
            if (_Rgn != 0) delete _Rgn;
            _Rgn = new LMDRegion;
            _Rgn->CreateRoundRect(0, 0, cWidth, cHeight, 16, 16);

            _Width = cWidth;
            _Height = cHeight;
            _X = cX;
            _Y = cY;
            _Parent = cParent;
            LMDIDW fParent;
            if (cParent == 0) fParent = XRootWindow(Dis, Screen);
            else              fParent = cParent->IDW();

            _IDW = XCreateWindow(Dis, fParent, cX, cY, cWidth, cHeight, 0, depth, InputOutput, visual, CWBackPixel | CWBorderPixel | CWOverrideRedirect, &attributes);


//            XSetStandardProperties(Dis, _IDW, TxtText(), TxtText(), None, NULL, 0, NULL);
            //StructureNotifyMask
            XSelectInput(Dis, _IDW, ExposureMask | ButtonPressMask | ButtonReleaseMask | KeyPressMask | KeyReleaseMask | FocusChangeMask | PointerMotionMask | EnterWindowMask | LeaveWindowMask | StructureNotifyMask);
            XSetWMProtocols(Dis, _IDW, X11Base()->Protocols(), X11Base()->ProtocolsCount());

            /*XFontStringuct *fontinfo = XLoadQueryFont(Dis, "6x10");
            XGCValues gr_values;
            gr_values.font = fontinfo->fid;
            gr_values.function = GXcopy;
            gr_values.plane_mask = AllPlanes;
            gr_values.foreground = BlackPixel(Dis, Screen);
            gr_values.background = WhitePixel(Dis, Screen);
            gc = XCreateGC(Dis, _IDW, GCFont | GCFunction | GCPlaneMask | GCForeground | GCBackground, &gr_values);*/
//            gc = XCreateGC(Dis, _IDW, 0,0);
//            XClearWindow(Dis, _IDW);

            X11Base()->AddBaseWnd(this);

            Event_Create();

            Font.Create();
//            LMDScene Scene;
            Scene.CreateScene(this, cWidth, cHeight, true);
            
            SetRegion(_Rgn);

            Repaint();

            XMapRaised(Dis, _IDW);

            XMoveWindow(Dis, _IDW, cX, cY);
        }


        UINT LMDButton::Event_Paint(void) {
//            Scene.FillRectangle(0, 0, Scene.Width(), Scene.Height(), LMD_RGB(255, 255, 255));
            Scene.FillGradient(0, 0, Scene.Width(), Scene.Height(), LMD_RGB(128,128,128), LMD_RGB(64,64,64));
            int WidthText = Scene.GetTextWidth("AaBbCcDdQqPpíÍ\naaaa");

            Scene.DrawText("AaBbCcDdQqPpíÍ\naaaa", (Scene.Width() - WidthText) / 2, 0, LMD_RGB(0, 0, 255));
        }

    #endif



    #ifdef LMD_SO_WINDOWS
        void LMDButton::CreateButton(LMDBaseWnd *cParent, const UINT cIDC, LMD_PSTR cText, const int cX, const int cY, const UINT cWidth, const UINT cHeight) {

        }

        LRESULT CALLBACK LMDButton::_StaticMessageHandler(HWND WndHandle, UINT uMsg, WPARAM wParam, LPARAM lParam) {

        }
    #endif
};
