/*! \file    LMDString.cpp
	\brief   Strings declarations (windows/linux).
*/
#include "LMDString.h"

#include <stdio.h>
#include <cstdlib>
#include <cctype>
#include <wchar.h>
#include <string.h>

namespace LMD {


    /**
	 * C++ version 0.4 char* style "itoa":
	 * Written by Lukás Chmela
	 * Released under GPLv3.
	 */
    /*
	char* itoa(int value, char* result, int base) {
		// check that the base if valid
		if (base < 2 || base > 36) { *result = '\0'; return result; }
	
		char* ptr = result, *ptr1 = result, tmp_char;
		int tmp_value;

		do {
			tmp_value = value;
			value /= base;
			*ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz" [35 + (tmp_value - value * base)];
		} while ( value );

		// Apply negative sign
		if (tmp_value < 0) *ptr++ = '-';
		*ptr-- = '\0';
		while(ptr1 < ptr) {
			tmp_char = *ptr;
			*ptr--= *ptr1;
			*ptr1++ = tmp_char;
		}
		return result;
	}*/



    int LMDStringBase::_Cmp(const char *String1, const char *String2) const {
        for (; *String1 && *String2 && *String1 == *String2; ++String1, ++String2);
        return *String1 - *String2;
    }

    int LMDStringBase::_Cmp(const wchar_t *String1, const wchar_t *String2) const {
        for (; *String1 && *String2 && *String1 == *String2; ++String1, ++String2);
        return *String1 - *String2;
    }

    int LMDStringBase::_CmpI(const char *String1, const char *String2) const {
        for (; *String1 && *String2 && toupper(*String1) == toupper(*String2); ++String1, ++String2);
        return *String1 - *String2;
    }

    int LMDStringBase::_CmpI(const wchar_t *String1, const wchar_t *String2) const {
        for (; *String1 && *String2 && toupper(*String1) == toupper(*String2); ++String1, ++String2);
        return *String1 - *String2;
    }















    LMDStringWC::LMDStringWC(LMDStringMB &nString) : LMDStringBase(), _String(NULL) {
        CopyString(nString());
    };


    void LMDStringWC::Delete(void) {
        if (_String != 0) delete [] _String;
        _Size   = 0;
        _String = NULL;
    }

    UINT LMDStringWC::CopyString(const char *nString, const UINT nSize) {
		if (nString == 0) return 0;
        Delete();
        if (nSize == LMD_STR_MAX)  _Size = strlen(nString);
        else	        	       _Size = nSize;
        _String = new wchar_t [_Size + 1];
        wchar_t Destino[2048];
        mbstowcs(Destino, nString, 2048);
        for (UINT i = 0; i < _Size; i++)	_String[i] = Destino[i];
        _String[_Size] = 0;
        return _Size;
    }

    UINT LMDStringWC::CopyString(const wchar_t *nString, const UINT nSize) {
		if (nString == 0) return 0;
        Delete();
        if (nSize == LMD_STR_MAX)  _Size = wcslen(nString);
        else			           _Size = nSize;
        _String = new wchar_t [_Size + 1];
        for (UINT i = 0; i < _Size; i++)	_String[i] = nString[i];
        _String[_Size] = 0;
        return _Size;
    }

    UINT LMDStringWC::AddString(const char *nString, const UINT nSize) {
		if (nString == 0) return 0;
        UINT SizeFinal = _Size;
        if (nSize == LMD_STR_MAX)  SizeFinal += strlen(nString);
        else			           SizeFinal += nSize;
        wchar_t *StringFinal = new wchar_t [SizeFinal +1];
        UINT i = 0;
        for (i = 0; i < _Size; i++)				  StringFinal[i]			= _String[i];
        wchar_t Destino[2048];
        mbstowcs(Destino, nString, 2048);
        for (i = 0; i < (SizeFinal - _Size); i++) StringFinal[i + _Size]	= Destino[i];
        Delete();
        StringFinal[SizeFinal] = 0;
        _Size = SizeFinal;
        _String = StringFinal;
        return i;
    }

    UINT LMDStringWC::AddString(const wchar_t *nString, const UINT nSize) {
        if (nString == 0) return 0;
        UINT SizeFinal = _Size;
        if (nSize == LMD_STR_MAX)  SizeFinal += wcslen(nString);
        else			        SizeFinal += nSize;
        wchar_t *StringFinal = new wchar_t [SizeFinal +1];
        UINT i = 0;
        for (i = 0; i < _Size; i++)				  StringFinal[i]			= _String[i];
        for (i = 0; i < (SizeFinal - _Size); i++) StringFinal[i + _Size]	= nString[i];
        Delete();
        StringFinal[SizeFinal] = 0;
        _Size = SizeFinal;
        _String = StringFinal;
        return i;
    }


    bool LMDStringWC::Compare(const wchar_t *nString, bool Binary) const {
		int Comp;
        if (_String == 0) {
            if (nString == 0) return true;
            else                 return false;
        }
        if (Binary == false) Comp = _CmpI(nString, _String);
        else                 Comp = _Cmp(nString, _String);
		if (Comp == 0) return true;
		return false;
    }

    bool LMDStringWC::Compare(const char *nString, bool Binary) const {
		int Comp;
        if (_String == 0) {
            if (nString == 0) return true;
            else                return false;
        }
        LMDStringWC WC(nString);
        if (Binary == false) Comp = _CmpI(WC(), _String);
        else                 Comp = _Cmp(WC(), _String);
		if (Comp == 0) return true;
		return false;
    }


    LMDStringWC LMDStringWC::SubStr(const UINT nStartPos, const UINT nSize) {
        LMDStringWC Ret;
        Ret.CopyString(&_String[nStartPos], nSize);
        return Ret;
    }


    LMDStringWC &LMDStringWC::operator = (LMDStringMB &cString) {
        CopyString(cString(), cString.Size());
        return *this;
    };

    bool LMDStringWC::operator == (LMDStringMB &cString) const {
        return Compare(cString());
    }

    bool LMDStringWC::operator != (LMDStringMB &cString) const {
        return !Compare(cString());
    }

    LMDStringWC &LMDStringWC::operator += (LMDStringMB &nString) {
        AddString(nString());
        return *this;
    };














    void LMDStringMB::Delete(void) {
        if (_String != 0) delete [] _String;
        _Size   = 0;
        _String = 0;
    }

    UINT LMDStringMB::CopyString(const char *nString, const UINT nSize) {
		if (nString == 0) return 0;
        Delete();
        if (nSize == LMD_STR_MAX)  _Size = strlen(nString);
        else			           _Size = nSize;
        _String = new char [_Size + 1];
        for (unsigned int i = 0; i < _Size; i++)	_String[i] = nString[i];
        _String[_Size] = 0;
        return _Size;
    }

    UINT LMDStringMB::CopyString(const wchar_t *nString, const UINT nSize) {
		if (nString == 0) return 0;
        Delete();
        if (nSize == LMD_STR_MAX) _Size = wcslen(nString);
        else			          _Size = nSize;
        _String = new char [_Size + 1];
        char Destino[2048];
        wcstombs(Destino, nString, 2048);
        for (UINT i = 0; i < _Size; i++)	_String[i] = Destino[i];
        _String[_Size] = 0;
        return _Size;
    }

    UINT LMDStringMB::AddString(const char *nString, const UINT nSize) {
		if (nString == 0) return 0;
        UINT SizeFinal = _Size;
        if (nSize == LMD_STR_MAX)   SizeFinal += strlen(nString);
        else			            SizeFinal += nSize;
        char *StringFinal = new char [SizeFinal +1];
        UINT i = 0;
        for (i = 0; i < _Size; i++)               StringFinal[i]			= _String[i];
        for (i = 0; i < (SizeFinal - _Size); i++) StringFinal[i + _Size]	= nString[i];
        Delete();
        StringFinal[SizeFinal] = 0;
        _Size = SizeFinal;
        _String = StringFinal;
        return i;
    }

    UINT LMDStringMB::AddString(const wchar_t *nString, const UINT nSize) {
        if (nString == 0) return 0;
        UINT SizeFinal = _Size;
        if (nSize == LMD_STR_MAX)   SizeFinal += wcslen(nString);
        else			            SizeFinal += nSize;
        char *StringFinal = new char [SizeFinal +1];
        UINT i = 0;
        for (i = 0; i < _Size; i++)				  StringFinal[i]			= _String[i];
        char Destino[2048];
        wcstombs(Destino, nString, 2048);
        for (i = 0; i < (SizeFinal - _Size); i++) StringFinal[i + _Size]	= Destino[i];
        Delete();
        StringFinal[SizeFinal] = 0;
        _Size = SizeFinal;
        _String = StringFinal;
        return i;
    }


    bool LMDStringMB::Compare(const char *nString, bool Binary) const {
		int Comp;
        if (_String == 0) {
            if (nString == 0) return true;
            else              return false;
        }
        if (Binary == false) Comp = _CmpI(nString, _String);
        else                 Comp = _Cmp(nString, _String);
		if (Comp == 0) return true;
		return false;
    }

    bool LMDStringMB::Compare(const wchar_t *nString, bool Binary) const {
		int Comp;
        if (_String == 0) {
            if (nString == 0) return true;
            else              return false;
        }
        LMDStringMB MB(nString);
        if (Binary == false) Comp = _CmpI(MB(), _String);
        else                 Comp = _Cmp(MB(), _String);
		if (Comp == 0) return true;
		return false;
    }


    LMDStringMB LMDStringMB::SubStr(const UINT nStartPos, const UINT nSize) {
        LMDStringMB Ret;
        Ret.CopyString(&_String[nStartPos], nSize);
        return Ret;
    }


};
