/*! \file  LMDLinuxBase.cpp
	\brief Declarations for basic X11 operations
*/
#include "LMDBaseX11.h"

// Dont use the LMD_SO_X11 macro, this class will need be independent of LMDPlatform.h
#if defined(linux)

    #include "../LMDBaseWnd.h"
    #include <stdio.h>

    //! Name space LMD
    namespace LMD {

        //! Constructor
        LMDBaseX11::LMDBaseX11(void) {
            _DISPLAY = XOpenDisplay((char *)0);
            printf("$DISPLAY : %x \n", _DISPLAY);
            _Screen = DefaultScreen(_DISPLAY);
            printf("Screen : %i \n", _Screen);

            _Protocols[0] = XInternAtom(_DISPLAY, "WM_DELETE_WINDOW", False);
//            _Protocols[1] = XInternAtom(_DISPLAY, "WM_TAKE_FOCUS", False);
        };

        //! Destructor
        LMDBaseX11::~LMDBaseX11(void) {
            if (_DISPLAY != NULL) XCloseDisplay(_DISPLAY);
        };

        //! Reference to $DISPLAY envoriment variable
        Display *LMDBaseX11::DISPLAY(void) {
            return _DISPLAY;
        };

        //! Screen of X11 server
        int LMDBaseX11::Screen(void) {
            return _Screen;
        };

        //! Funcion used to add window to app internal list
        Display *LMDBaseX11::AddBaseWnd(LMDBaseWnd *Wnd) {
            _WindowList.push_back(Wnd);
            return _DISPLAY;
        };

        //! Function used to find a window form app internal list
        LMDBaseWnd *LMDBaseX11::FindBaseWnd(LMDIDW nIDW) {
            for (size_t i = _WindowList.size(); i > 0; i--) {
                if (_WindowList[i -1]->IDW() == nIDW) return _WindowList[i -1];
            }
            return NULL;
        };

        void LMDBaseX11::CloseDISPLAY(void)  {
            if (_DISPLAY != NULL) XCloseDisplay(_DISPLAY);
            _DISPLAY = NULL;
        };

        //! Funcion used to delete a window form app internal list
        void LMDBaseX11::DeleteBaseWnd(LMDIDW nIDW)  {
            for (size_t i = _WindowList.size(); i > 0; i--) {
                if (_WindowList[i -1]->IDW() == nIDW) {
                    XSelectInput(_DISPLAY, _WindowList[i -1]->IDW(), 0);
                    _WindowList.erase(_WindowList.begin() + (i - 1));
                    XDestroyWindow(_DISPLAY, nIDW);

                }
            }
        }

        //! Atoms for X11 protocols (custom events)
        Atom *LMDBaseX11::Protocols(void) {
            return _Protocols;
        };

        //! Total X11 Protocols used
        int LMDBaseX11::ProtocolsCount(void) {
            return 2;
        };


        /*void LMDLinuxBase::EndApp(void) {
            for (size_t i = _WindowList.size(); i > 0; i--) {
                XSelectInput(_DISPLAY, _WindowList[i -1]->IDW(), 0);
//                _WindowList.erase(_WindowList.begin() + (i - 1));
                XDestroyWindow(_DISPLAY, _WindowList[i -1]->IDW());
            }
            _WindowList.clear();
        };*/

     /*   void LMDLinuxBase::MessageHandler(XEvent &Event)  {
//                LMDInstance<LMDLinuxBase> LinuxBase;
            LMDVirtualKey VK;
            char      String[32];
            char     *desc;
            KeySym    Tecla;
            UINT      nButton = 0;
            LMDBaseWnd *Wnd = FindBaseWnd(Event.xany.window);
            switch (Event.type) {
                case Expose :
                    if (Event.xexpose.count == 0) {
                        // PINTAR
    //                    LinuxBase->operator ()()->FindBaseWnd(Evento.xexpose.window)->Evento_Pintar();
                    }
                    return;
                case KeyPress :
                    //if (Event.xkey.state & ControlMask) LMDDebug::printf("Control + ");
//                    if (Event.xkey.state & Mod1Mask)    LMDDebug::printf("Alt + ");
  //                  if (Event.xkey.state & Mod5Mask)    LMDDebug::printf("Alt GR + ");
    //                if (Event.xkey.state & ShiftMask)   LMDDebug::printf("Shift + ");

                    XLookupString(&Event.xkey, String, 32, &Tecla, 0);
                    VK.Set(String[0], Event.xkey.state);
                  //  if (XLookupString(&Evento.xkey, String, 32, &Tecla, 0) == 1) {
                    FindBaseWnd(Event.xkey.window)->Event_KeyPress(VK);
                    //}
                    return;
                case KeyRelease :
//                        if (Event.xkey.state & LockMask)    LMDDebug::printf("Mayus - ");
  //                  if (Event.xkey.state & ControlMask) LMDDebug::printf("Control - ");
    //                if (Event.xkey.state & Mod1Mask)    LMDDebug::printf("Alt - ");
      //              if (Event.xkey.state & Mod2Mask)    LMDDebug::printf("NumLock + ");
        //            if (Event.xkey.state & Mod3Mask)    LMDDebug::printf("3 + ");
          //          if (Event.xkey.state & Mod4Mask)    LMDDebug::printf("4 + ");
            //        if (Event.xkey.state & Mod5Mask)    LMDDebug::printf("Alt GR + ");
              //      if (Event.xkey.state & ShiftMask)   LMDDebug::printf("Shift - ");
                    XLookupString(&Event.xkey, String, 32, &Tecla, 0);
                    VK.Set(String[0], Event.xkey.state);
                    FindBaseWnd(Event.xkey.window)->Event_KeyRelease(VK);
  //                  Tecla = XLookupKeysym((XKeyEvent *) & Evento, 0);
//                    desc = XKeysymToString(Tecla);
                    //LMD_PRINT_DEBUG("C0[%d] C1[%d] ", desc[0], desc[1]);
    //                LinuxBase()->FindBaseWnd(Evento.xkey.window)->Event_KeyRelease(desc[0], 0, 0);
                    return;
                case ButtonPress :
                    if      (Event.xbutton.button == 4)  FindBaseWnd(Event.xbutton.window)->Event_Mouse_Wheel(1);
                    else if (Event.xbutton.button == 5)  FindBaseWnd(Event.xbutton.window)->Event_Mouse_Wheel(-1);
                    else {
                        nButton = Event.xbutton.button;
                        if (nButton == 8) nButton = 4;
                        if (nButton == 9) nButton = 5;
                        FindBaseWnd(Event.xbutton.window)->Event_Mouse_ButtonPress(nButton, Event.xbutton.x, Event.xbutton.y);
                    }
                    return;
                case ButtonRelease :
                    if (Event.xbutton.button != 4 && Event.xbutton.button != 5) {
                        nButton = Event.xbutton.button;
                        if (nButton == 8) nButton = 4;
                        if (nButton == 9) nButton = 5;
                        FindBaseWnd(Event.xbutton.window)->Event_Mouse_ButtonRelease(nButton, Event.xbutton.x, Event.xbutton.y);

                        if (Event.xbutton.time < _DobleClickTime + 1000) printf("[T:%d]\n", Event.xbutton.time);
                        _DobleClickTime = Event.xbutton.time;
                    }
                    return;

                case FocusIn :
                    FindBaseWnd(Event.xfocus.window)->Event_GetFocus();
                    return;
                case FocusOut :
                    FindBaseWnd(Event.xfocus.window)->Event_LostFocus();
                    return;

                case MotionNotify :
                    FindBaseWnd(Event.xfocus.window)->Event_Mouse_Move(Event.xmotion.x, Event.xmotion.y);
                    return;

                case EnterNotify :
                    FindBaseWnd(Event.xfocus.window)->Event_Mouse_Enter();
                    return;
                case LeaveNotify :
                    FindBaseWnd(Event.xfocus.window)->Event_Mouse_Leave();
                    return;

                case ClientMessage :
                    Atom *nProtocols = Protocols();
                    if (Event.xclient.data.l[0] == nProtocols[0]) { // WM_WINDOW_DESTROY -> Protocols[0]
                        FindBaseWnd(Event.xclient.window)->Destroy();
//                            if (LinuxBase()->FindBaseWnd(Event.xclient.window)->Event_Destroy() == TRUE) {
  //                          LinuxBase()->FindBaseWnd(Event.xclient.window)->Destroy();
    //                    }
                    }
 //                  if (Event.xclient.data.l[0] == Protocols[1]) { // WM_TAKE_FOCUS -> Protocols[1]
   //                     LinuxBase()->FindBaseWnd(Event.xclient.window)->Event_GetFocus();
     //                   LMDDebug::printf("%d)\n", Event.xclient.window);
       //             }
                    return;
            }
        };*/
    };



#endif



