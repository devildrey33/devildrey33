/*! \file  LMDBaseX11.h
	\brief Header for basic X11 operations
*/

#ifndef LMD_BASEX11_H
    #define LMD_BASEX11_H

    
    #if defined(linux)
        #include </usr/include/X11/Xlib.h>
        #include </usr/include/X11/Xutil.h>
        #include </usr/include/X11/Xos.h>
        #include <wchar.h>
        #include <vector>
        #include <limits.h>
        /*! ID for a window asigned by SO.                                      \n
            On windows so LMDIDW is a HWND, on X11 linux so LMDIDW is a Window. \n
            This ID is for a internal use and you only need it to refer a window to a special function that handles it.
        */
        typedef Window  LMDIDW;

        //! Name space LMD
        namespace LMD {

            class LMDBaseWnd;

            //! Base class for linux aplications
            class LMDBaseX11 {
              public : ///////////////////////////  Public members

                                                //! Constructor
                                                LMDBaseX11(void);

                                                //! Destructor
                                               ~LMDBaseX11(void);

                                                //! Reference to $DISPLAY envoriment variable
                Display                        *DISPLAY(void);

                                                //! Screen of X11 server
                int                             Screen(void);

                                                //! Function used to close linux DISPLAY
                void                            CloseDISPLAY(void);

                                                //! Funcion used to add window to app internal list
                Display                        *AddBaseWnd(LMDBaseWnd *Wnd);

                                                //! Function used to find a window form app internal list
                LMDBaseWnd                     *FindBaseWnd(LMDIDW nIDW);

                                                //! Funcion used to delete a window form app internal list
                void                            DeleteBaseWnd(LMDIDW nIDW);

                                                //! Atoms for X11 protocols (custom events)
                Atom                           *Protocols(void);

                                                //! Total X11 Protocols used
                int                             ProtocolsCount(void);

//                void                            MessageHandler(XEvent &Event);

//                void                            EndApp(void);

              protected : //////////////////////// Protected members

                                                //! List for this aplication windows
                std::vector<LMDBaseWnd *>      _WindowList;
                                                //!  Reference to $DISPLAY envoriment variable
                Display                       *_DISPLAY;
                                                //! Screen of X11 server
                int                            _Screen;
                                                //! Atoms for X11 protocols (custom events)
                Atom                           _Protocols[1];

                friend class                    LMDBaseWnd;

            };                                  //
            ////////////////////////////////////// END LMDLinuxBase

        };

    #endif

#endif
