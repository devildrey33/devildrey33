/*! \file  LMDRegion.cpp
	\brief Declarations for LMDRegion class
*/
#include "LMDRegion.h"
#include "stdlib.h"

namespace LMD {

    LMDRegion::LMDRegion(void) : _Region(0) {

    }

    LMDRegion::~LMDRegion(void) {
        Free();
    }

    #ifdef LMD_SO_X11

        void LMDRegion::Free(void) {
             if (_Region != 0) XDestroyRegion(_Region);
            _Region = 0;
        }

        void LMDRegion::CreateRect(const int cX, const int cY, const UINT cWidth, const UINT cHeight) {
            Free();
            _Region = XCreateRegion();
            XRectangle R = { cX, cY, cWidth, cHeight };
            XUnionRectWithRegion(&R, _Region, _Region);
        }

        // Based on this windows implementation :
		// http://www.filewatcher.com/p/ecos_2.0-0pre2.4_all.deb.13268406/usr/src/ecos/packages/services/gfx/mw/v2_0/src/mwin/winrgn.c.html
        void LMDRegion::CreateRoundRect(const int cX, const int cY, const UINT cWidth, const UINT cHeight, const UINT cElipse_Width, const UINT cElipse_Height) {
            int asq, bsq, d, xd, yd;
            int tmpY = cY, tmpHeight = cHeight, tmpEWidth = cElipse_Width, tmpEHeight = cElipse_Height;
            XRectangle R;

            if (cElipse_Width == 0 || cElipse_Height == 0) {
                CreateRect(cX, cY, cWidth, cHeight);
                return;
            }

            tmpEWidth  = abs(tmpEWidth);
            tmpEHeight = abs(tmpEHeight);

            Free();
            _Region = XCreateRegion();

            if (tmpEWidth  > cWidth)  tmpEWidth  = cWidth;
            if (tmpEHeight > cHeight) tmpEHeight = cHeight;

            asq = tmpEWidth  * tmpEWidth  / 4;
            bsq = tmpEHeight * tmpEHeight / 4;
            if (asq == 0) asq = 1;
            if (bsq == 0) bsq = 1;
            d = bsq - asq * tmpEHeight / 2 + asq / 4;
            xd = 0;
            yd = asq * tmpEHeight;

            R.x = cX + tmpEWidth  / 2;
            R.width = (cWidth - tmpEWidth / 2) - R.x;
            R.height = 1;

            while (xd < yd) {
                if (d > 0) {
                    R.y = tmpY++;
                    XUnionRectWithRegion(&R, _Region, _Region);
                    R.y = --tmpHeight;
                    XUnionRectWithRegion(&R, _Region, _Region);
                    yd -= 2 * asq;
                    d  -= yd;
                }
                R.x --;
                R.width +=2;
                xd += 2 * bsq;
                d += bsq + xd;
            }


            d += (3 * (asq - bsq) / 2 - (xd + yd)) / 2;
            while (yd >= 0) {
                R.y = tmpY++;
                XUnionRectWithRegion(&R, _Region, _Region);
                R.y = --tmpHeight;
                XUnionRectWithRegion(&R, _Region, _Region);
                if (d < 0) {
                    R.x --;
                    R.width += 2;
                    xd += 2 * bsq;
                    d  += xd;
                }

                yd -= 2 * asq;
                d  += asq - yd;
            }

            if (tmpY <= tmpHeight) {
                R.y = tmpY;
                R.height = tmpHeight - tmpY;
                XUnionRectWithRegion(&R, _Region, _Region);
            }

        }



        bool LMDRegion::PointInRegion(const int cX, const int cY) const {
            if (_Region == 0) return false;
            return XPointInRegion(_Region, cX, cY);
        }


        bool LMDRegion::RectInRegion(const int cX, const int cY, const UINT cWidth, const UINT cHeight) const {
            if (_Region == 0) return false;
            return XRectInRegion(_Region, cX, cY, cWidth, cHeight);
        }


        void LMDRegion::Move(const int cX, const int cY) {
            XOffsetRegion(_Region, cX, cY);
        }
    #endif



    #ifdef LMD_SO_WINDOWS
        void LMDRegion::Free(void) {
             if (_Region != 0) DeleteRgn(_Region);
            _Region = 0;

        }

        void LMDRegion::CreateRect(const int cX, const int cY, const UINT cWidth, const UINT cHeigh) {

        }


        void LMDRegion::CreateRoundRect(const int cX, const int cY, const UINT cWidth, const UINT cHeigh, const UINT cElipse_Width, const UINT cElipse_Height) {

        }

    #endif
};
