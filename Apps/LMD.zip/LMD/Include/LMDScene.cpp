/*! \file  LMDScene.cpp
	\brief Declarations for LMDScene class
*/
#include "LMDScene.h"
//#include <stdlib.h>
#include "LMDBaseWnd.h"
#include <wchar.h>
#include <string.h>

#include <stdio.h>

namespace LMD {

    #ifdef LMD_SO_WINDOWS
    
    #endif

    
    #ifdef LMD_SO_X11
        LMDScene::LMDScene(void) : _Dis(0), _PixMap(0), _AsociatedWnd(0), _PaintContext(0), _NeedRepaint(true), _ForeGround(ULONG_MAX), _BackGround(ULONG_MAX) {
        }

        LMDScene::~LMDScene(void) {
            Free();
        }

        void LMDScene::Free(void) {
            if (_Dis == 0) return;
            if (_PaintContext != 0) XFreeGC(_Dis, _PaintContext);
            _PaintContext = 0;
            if (_PixMap != 0) XFreePixmap(_Dis, _PixMap);
            _Dis = 0;
            _PixMap = 0;
            _AsociatedWnd = 0;
            _Width = 0;
            _Height = 0;
            _NeedRepaint = true;
        }


        void LMDScene::CreateScene(LMDBaseWnd *BaseWnd, const UINT nWidth, const UINT nHeight, const bool ParentBackGround) {
            LMDInstance<LMDBaseX11> X11Base;
            Free();
            _Dis = X11Base()->DISPLAY();
            int Scr = X11Base()->Screen();
            _ParentBackGround = ParentBackGround;
            _AsociatedWnd = BaseWnd;
            _Width = nWidth;
            _Height = nHeight;
            _PixMap = XCreatePixmap(_Dis, _AsociatedWnd->IDW(), _Width, _Height, DefaultDepth(_Dis, Scr));

//_AsociatedWnd->Color_BackGround = LMD_RGB(255, 0, 255);
            XGCValues XGCVal;
            XGCVal.function   = GXcopy;
            XGCVal.plane_mask = AllPlanes;
            XGCVal.clip_x_origin = 0;
            XGCVal.clip_y_origin = 0;
            XGCVal.subwindow_mode = IncludeInferiors; // ClipByChildren;
            XGCVal.foreground = None;
//            XGCVal.foreground = None;
//            XGCVal.background = XWhitePixel(_Dis, Scr);
            XGCVal.graphics_exposures = False;
            XGCVal.clip_mask = None;
            _PaintContext = XCreateGC(_Dis, _PixMap, GCFunction | GCPlaneMask | GCSubwindowMode | GCGraphicsExposures | GCClipXOrigin | GCClipYOrigin | GCClipMask | GCForeground | GCBackground, &XGCVal);
            BackGround(_AsociatedWnd->Color_BackGround());
            if (_ParentBackGround == false) {
                ForeGround(_AsociatedWnd->Color_BackGround());
                XFillRectangle(_Dis, _PixMap, _PaintContext, 0, 0, _Width, _Height);
            }
            else {
//                XFillRectangle(_Dis, _PixMap, _PaintContext, 0, 0, _Width, _Height);
                XCopyArea(_Dis, _AsociatedWnd->Parent()->Scene._PixMap, _PixMap, _PaintContext, _AsociatedWnd->X(), _AsociatedWnd->Y(), _Width, _Height, 0, 0);
            }
            ForeGround(_AsociatedWnd->Color_ForeGround());
//            XClearArea(_Dis, _PixMap, 0, 0, _Width, _Height, false);
//            XFlush(_Dis);
//            _PC = XCreateGC(_Dis, nIDW, GCFunction | GCPlaneMask | GCSubwindowMode | GCGraphicsExposures | GCClipXOrigin | GCClipYOrigin | GCClipMask | GCForeground | GCBackground, &XGCVal);
  //          XSetGraphicsExposures(_Dis, _PCBuffer, True);
        }

        void LMDScene::FillGradient(const int cX, const int cY, const UINT cWidth, const UINT cHeight, ULONG cColor1, ULONG cColor2, const bool Horizontal) {
            ULONG fColor;
            int   i = 0;
            float FactR = 0, FactG = 0, FactB = 0;
            if (Horizontal == false) {
                FactR = static_cast<float>(LMD_RGB_GET_R(cColor2) - LMD_RGB_GET_R(cColor1)) / static_cast<float>(cHeight);
                FactG = static_cast<float>(LMD_RGB_GET_G(cColor2) - LMD_RGB_GET_G(cColor1)) / static_cast<float>(cHeight);
                FactB = static_cast<float>(LMD_RGB_GET_B(cColor2) - LMD_RGB_GET_B(cColor1)) / static_cast<float>(cHeight);
                for (i = 0; i < cHeight; i++) {
                    fColor = LMD_RGB(LMD_RGB_GET_R(cColor1) + (FactR * i), LMD_RGB_GET_G(cColor1) + (FactG * i), LMD_RGB_GET_B(cColor1) + (FactB * i));
                    XSetForeground(_Dis, _PaintContext, fColor);
                    XDrawLine(_Dis, _PixMap, _PaintContext, cX, cY + i, cX + cWidth, cY + i);
                }
            }
            else {
                FactR = static_cast<float>(LMD_RGB_GET_R(cColor2) - LMD_RGB_GET_R(cColor1)) / static_cast<float>(cWidth);
                FactG = static_cast<float>(LMD_RGB_GET_G(cColor2) - LMD_RGB_GET_G(cColor1)) / static_cast<float>(cWidth);
                FactB = static_cast<float>(LMD_RGB_GET_B(cColor2) - LMD_RGB_GET_B(cColor1)) / static_cast<float>(cWidth);
                for (i = 0; i < cWidth; i++) {
                    fColor = LMD_RGB(LMD_RGB_GET_R(cColor1) + (FactR * i), LMD_RGB_GET_G(cColor1) + (FactG * i), LMD_RGB_GET_B(cColor1) + (FactB * i));
                    XSetForeground(_Dis, _PaintContext, fColor);
                    XDrawLine(_Dis, _PixMap, _PaintContext, cX + i, cY, cX + i, cY + cHeight);
                }

            }
            XSetForeground(_Dis, _PaintContext, _ForeGround);
        }

        
        void LMDScene::ResizeScene(const UINT nWidth, const UINT nHeight) {
            if (_Dis == 0) return;
            LMDInstance<LMDBaseX11> X11Base;
            int Scr = X11Base()->Screen();
            // Don't use Free() or you loose the AsociatedWnd.
            if (_PaintContext != 0) XFreeGC(_Dis, _PaintContext);
            _PaintContext = 0;
            if (_PixMap != 0) XFreePixmap(_Dis, _PixMap);
            _PixMap = 0;
            _NeedRepaint = true;
            _Width = nWidth;
            _Height = nHeight;

            _PixMap = XCreatePixmap(_Dis, _AsociatedWnd->IDW(), _Width, _Height, DefaultDepth(_Dis, Scr));
            XGCValues XGCVal;
            XGCVal.function   = GXcopy;
            XGCVal.plane_mask = AllPlanes;
            XGCVal.clip_x_origin = 0;
            XGCVal.clip_y_origin = 0;
            XGCVal.subwindow_mode = IncludeInferiors; // ClipByChildren;
            XGCVal.foreground = None;
            XGCVal.background = None;
            XGCVal.graphics_exposures = False;
            XGCVal.clip_mask = None;

            _PaintContext = XCreateGC(_Dis, _PixMap, GCFunction | GCPlaneMask | GCSubwindowMode | GCGraphicsExposures | GCClipXOrigin | GCClipYOrigin | GCClipMask | GCForeground | GCBackground, &XGCVal);
            _ForeGround = ULONG_MAX;
            _BackGround = ULONG_MAX;
            BackGround(_AsociatedWnd->Color_BackGround());
//            XClearArea(_Dis, _PixMap, 0, 0, _Width, _Height, false);
            if (_ParentBackGround == false) {
                ForeGround(_AsociatedWnd->Color_BackGround());
                XFillRectangle(_Dis, _PixMap, _PaintContext, 0, 0, _Width, _Height);
            }
            else {
//                XCopyArea(_Dis, _AsociatedWnd->Parent()->Scene._PixMap, _PixMap, _PaintContext, _AsociatedWnd->X(), _AsociatedWnd->Y(), _Width, _Height, 0, 0);
            }
            LMD_PRINT_DEBUG("ResizeScene : %d %d\n", _Width, _Height);
            ForeGround(_AsociatedWnd->Color_ForeGround());

        }



        void LMDScene::ForeGround(ULONG FG) {
            if (_ForeGround != FG) {
                _ForeGround = FG;
                XSetForeground(_Dis, _PaintContext, FG);
            }
        }

        void LMDScene::BackGround(ULONG BG) {
            if (_BackGround != BG) {
                _BackGround = BG;
                XSetBackground(_Dis, _PaintContext, BG);
            }
        }



        void LMDScene::PaintScene(const int nX, const int nY, const UINT nWidth, const UINT nHeight) {
//            XClearWindow(_Dis, _AsociatedWnd->IDW());
//            XFlush(_Dis);
  //          XFlush(_Dis);
//            XSetWindowBackgroundPixmap(_Dis, _AsociatedWnd->IDW(), _PixMap);
            XCopyArea(_Dis, _PixMap, _AsociatedWnd->IDW(), _PaintContext, nX, nY, nWidth, nHeight, nX, nY);
        }

        void LMDScene::DrawRectangle(const int cX, const int cY, const UINT cWidth, const UINT cHeight, ULONG cColor) {
            XSetForeground(_Dis, _PaintContext, cColor);
            XDrawRectangle(_Dis, _PixMap, _PaintContext, cX, cY, cWidth, cHeight);

        }

        void LMDScene::FillRectangle(const int cX, const int cY, const UINT cWidth, const UINT cHeight, ULONG cColor) {
            XSetForeground(_Dis, _PaintContext, cColor);
            XFillRectangle(_Dis, _PixMap, _PaintContext, cX, cY, cWidth, cHeight);
        }

        void LMDScene::DrawText(char *nText, const int cX, const int cY, ULONG cColor, LMDFont *nFont) {
            char **Missing_Charset_List = 0;
            int    Missing_Charset_Count = 0;
            char  *String_ret = 0;
            XSetForeground(_Dis, _PaintContext, cColor);
            if (nFont == NULL) nFont = &_AsociatedWnd->Font;

/*            XmbTextItem TI;
            TI.chars = nText;
            TI.delta = 1;
            TI.font_set = None;
            TI.nchars = strlen(nText);*/
//            XFontSet nF = XCreateFontSet(_Dis, "lucidasanstypewriter-bold-8", &Missing_Charset_List, &Missing_Charset_Count, &String_ret);
//            XmbDrawText(_Dis, _PixMap, _PaintContext, cX, cY, &TI, 1);
            XmbDrawString(_Dis, _PixMap,nFont->operator ()(), _PaintContext, cX, (cY + nFont->LineHeight()) + 1, nText, strlen(nText));
        }

        void LMDScene::DrawText(wchar_t *nText, const int cX, const int cY, ULONG cColor, LMDFont *nFont) {
            char    **Missing_Charset_List = 0;
            int       Missing_Charset_Count = 0;
            char     *String_ret = 0;
            if (nFont == NULL) nFont = &_AsociatedWnd->Font;
            XSetForeground(_Dis, _PaintContext, cColor);
//            Font nFont = XLoadFont(_Dis, "6x10");
//            XFontSet nF = XCreateFontSet(_Dis, "lucidasanstypewriter-bold-8", &Missing_Charset_List, &Missing_Charset_Count, &String_ret);
            XwcDrawString(_Dis, _PixMap, nFont->operator ()(), _PaintContext, cX, (cY + nFont->LineHeight()) + 1, nText, wcslen(nText));
//            XFreeFont(_Dis, nFont);
        }


        UINT LMDScene::GetTextWidth(char *nText, LMDFont *nFont) {
            if (nFont == NULL) nFont = &_AsociatedWnd->Font;
            XmbTextEscapement(nFont->operator ()(), nText, strlen(nText));
        }


        UINT LMDScene::GetTextWidth(wchar_t *nText, LMDFont *nFont) {
            if (nFont == NULL) nFont = &_AsociatedWnd->Font;
            XwcTextEscapement(nFont->operator ()(), nText, wcslen(nText));
        }

    #endif

};
