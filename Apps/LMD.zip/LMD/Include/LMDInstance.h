#ifndef LMD_INSTANCE
    #define LMD_INSTANCE

    //! Name space LMD
    namespace LMD {
        //! Template class for singletons of LMD
        template <class LMD_INSTANCE_TYPE> class LMDInstance {
          public: ////////////////////////  Public members
              
                                        //! Constructor
                                        /*! This constructor is empty
                                                \fn			LMDInstance(void);
                                                \return		Nothing.
                                        */
                                        LMDInstance(void) { };

                                        //! Operator ()
                                        /*! This operator returns the sigleton instance
                                                \fn			LMD_INSTANCE_TYPE *operator () (void);
                                                \return		Returns the singleton instance.
                                        */
            LMD_INSTANCE_TYPE          *operator () (void) {
                                            if (_Instance == 0) _Instance = new LMD_INSTANCE_TYPE;
                                            return _Instance;
                                        };

          private: ///////////////////////  Private members
              
                                        //! Singletton instance pointer
            static LMD_INSTANCE_TYPE  *_Instance;
        };
        ////////////////////////////////// End template <class LMD_INSTANCE_TYPE> class LMDInstance

        //! Definition for static member _Instance
        template <class LMD_INSTANCE_TYPE> LMD_INSTANCE_TYPE *LMDInstance<LMD_INSTANCE_TYPE>::_Instance = 0;
    };



#endif
/*! \file LMDInstance.h
	\brief LMD Singleton template
*/
