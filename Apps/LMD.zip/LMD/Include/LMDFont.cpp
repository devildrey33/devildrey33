/*! \file  LMDFont.cpp
	\brief Declarations for LMDFont class
*/
#include "LMDFont.h"


namespace LMD {

    LMDFont::LMDFont(void) : _Font(0), _LineHeight(0){

    }


    LMDFont::~LMDFont(void) {
        Destroy();
    }

    #ifdef LMD_SO_X11

        void LMDFont::Create(void) {
            LMDInstance<LMDBaseX11> X11Base;
            char        **Missing_Charset_List  = 0;
            XFontStruct **Font_Struct_List      = 0;
            char        **Font_Name_List        = 0;
            int           Missing_Charset_Count = 0;
            char         *String_Ret            = 0;
            _Font = XCreateFontSet(X11Base()->DISPLAY(), "lucidasanstypewriter-bold-8", &Missing_Charset_List, &Missing_Charset_Count, &String_Ret);
//            XFontStruct   FontInfo;
            int TotalFonts = XFontsOfFontSet(_Font, &Font_Struct_List, &Font_Name_List);
            _LineHeight = Font_Struct_List[0]->ascent - Font_Struct_List[0]->descent;
        }


        void LMDFont::Destroy(void) {
            if (_Font != 0) {
                LMDInstance<LMDBaseX11> X11Base;
                XFreeFontSet(X11Base()->DISPLAY(), _Font);
            }
            _Font = 0;
            _LineHeight = 0;
        }

    #endif



    #ifdef LMD_SO_WINDOWS


    #endif
};
