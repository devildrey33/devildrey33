/*! \file LMDVirtualKey.h
	\brief VirtualKeys for LMD
*/
#ifndef LMD_VIRTUALKEY_H
    #define LMD_VIRTUALKEY_H

    #include "LMDPlatform.h"

    //! Name space LMD
    namespace LMD {

        //! Class to handle VirtualKeys in all platforms
        class LMDVirtualKey {
          public:
                            LMDVirtualKey(void);
                            LMDVirtualKey(UINT nVirtualCode, UINT nMask);
            void            Set(UINT nVirtualCode, UINT nMask);
            inline UINT     VirtualCode(void) { return _VirtualCode; };
//            bool            ScrollLock(void) const;
            bool            CapsLock(void) const;
            bool            NumLock(void) const;
            bool            Control(void) const;
            bool            Shift(void) const;
//            bool            Alt(void) const;
//            bool            Win(void) const;
            const LMD_STR   Char(void);
          protected :
            UINT           _VirtualCode;
            UINT           _Mask;
            #ifdef LMD_SO_WINDOWS
                BYTE       _KeyBoard[256];
            #endif
        };
    };

#endif
