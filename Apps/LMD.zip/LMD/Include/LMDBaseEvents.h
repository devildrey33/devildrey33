#ifndef LMD_BASEEVENTS_H
#define LMD_BASEEVENTS_H

#include "LMDVirtualKey.h"
#include "LMDDebug.h"

//#include "LMDPlatform.h"


#define LMD_EVENTS_DEBUG(func...)  LMD_ONLY_DEBUG(LMD_PRINT_DEBUG(func))

//! Namespace LMD
namespace LMD {
    //! Class for basic window events.
    /*! This class holds all basic events for all type of windows.                           \n
        When you create a LMDWindow or LMDControl you can override any of the next events :
        - <b>LMD::Windows::Base::LMDBaseEvents::Event_Destroy</b>                            \n
          When window is about to be destroyed.                                              \n\n
        - <b>LMD::Windows::Base::LMDBaseEvents::Event_KeyPress</b>                           \n
          Keyboard key pressed.                                                              \n\n
        - <b>LMD::Windows::Base::LMDBaseEvents::Event_KeyRelease</b>                         \n
          Keyboard key released.                                                             \n\n
        - <b>LMD::Windows::Base::LMDBaseEvents::Event_Mouse_Enter</b>                        \n
          Mouse entering in this window.                                                     \n\n
        - <b>LMD::Windows::Base::LMDBaseEvents::Event_Mouse_Leave</b>                        \n
          Mouse leaving from this window.                                                    \n\n
        - <b>LMD::Windows::Base::LMDBaseEvents::Event_Mouse_Move</b>                         \n
          Mouse moved in this window.                                                        \n\n
        - <b>LMD::Windows::Base::LMDBaseEvents::Event_Mouse_ButtonPress</b>                  \n
          Mouse button pressed.                                                              \n\n
        - <b>LMD::Windows::Base::LMDBaseEvents::Event_Mouse_ButtonRelease</b>                \n
          Mouse button released.                                                             \n\n
        - <b>LMD::Windows::Base::LMDBaseEvents::Event_Mouse_DoubleClick</b>                  \n
          Mouse double click.                                                                \n\n
        - <b>LMD::Windows::Base::LMDBaseEvents::Event_Mouse_Wheel</b>                        \n
          Mouse wheel.                                                                       \n\n
        - <b>LMD::Windows::Base::LMDBaseEvents::Event_GetFocus</b>                           \n
          This window is getting keyboard focus.                                             \n\n
        - <b>LMD::Windows::Base::LMDBaseEvents::Event_LostFocus</b>                          \n
          This window is loosing keyboard focus.                                             \n\n
    */
    class LMDBaseEvents {
     public : //////////////////////////////// Public members

                                            //! Constructor
                                            /*! Constructor for basic events
                                                    \fn			LMDBaseEvents(void);
                                                    \return		Nothing.
                                            */
                                            LMDBaseEvents(void) { };


         inline virtual UINT                Event_Paint(void) {
                                                LMD_EVENTS_DEBUG("Event_Paint()\n");
                                                return 0;
                                            }

                                            //! Window event create
                                            /*! This event is called after this window is created.
                                                    \fn			inline virtual UINT Event_Create(void);
                                                    \return		If this function is replaced, you need return 0.
                                                    \sa         Event_Destroy(), LMDWindow::Create()
                                            */
         inline virtual UINT                Event_Create(void) {
                                                LMD_EVENTS_DEBUG("Event_Create()\n");
                                                return TRUE;
                                            };

                                            //! Window event destroy
                                            /*! This event is called before destroying the window.
                                                    \fn			inline virtual UINT Event_Destroy(void);
                                                    \return		Return TRUE to destroy window, FALSE to prevent window destruction.
                                                    \sa         Event_Create(), LMDBaseWnd::Destroy()
                                            */
         inline virtual UINT                Event_Destroy(void) {
                                                LMD_EVENTS_DEBUG("Event_Destroy()\n");
                                                return TRUE;
                                            };

                                            //! Window event mouse double click
                                            /*! This event is called when user push two times a button mouse indicating a double click.
                                                    \fn			inline virtual UINT Event_Mouse_DoubleClick(const UINT Button, const int cX, const int cY);
                                                    \param[in]  Button : Mouse button pressed
                                                    \param[in]  cX     : X coordinate relative to control
                                                    \param[in]  cY     : Y coordinate relative to control
                                                    \return		If this function is replaced, you need return 0.
                                                    \remarks    In windows the dobleclick time is obtained form GetDoubleClick API, but in linux is asigned to 1000 ms.
                                                    \sa         Event_Mouse_ButtonPress(), Event_Mouse_ButtonRelease(), Event_Mouse_Wheel(), Event_Mouse_Move(), Event_Mouse_Enter(), Event_Mouse_Leave()
                                            */
         inline virtual UINT                Event_Mouse_DoubleClick(const UINT Button, const int cX, const int cY) {
                                                LMD_EVENTS_DEBUG("Event_Mouse_DobleClick(Button = '%d')\n", Button);
                                                return 0;
                                            };

                                            //! Window event mouse button release
                                            /*! This event is called when user release mouse button on this window
                                                    \fn			inline virtual UINT Event_Mouse_ButtonRelease(const UINT Button, const int cX, const int cY);
                                                    \param[in]  Button : Mouse button pressed
                                                    \param[in]  cX     : X coordinate relative to control
                                                    \param[in]  cY     : Y coordinate relative to control
                                                    \return		If this function is replaced, you need return 0.
                                                    \remarks    This function only handles mouse buttons, not the wheel. Button can be : LeftBtn = 0, MiddleBtn = 1, RightBtn = 2, ExtraBtn 3+
                                                    \sa         Event_Mouse_ButtonPress(), Event_Mouse_DoubleClick(), Event_Mouse_Wheel(), Event_Mouse_Move(), Event_Mouse_Enter(), Event_Mouse_Leave()
                                            */
         inline virtual UINT                Event_Mouse_ButtonRelease(const UINT Button, const int cX, const int cY) {
                                                LMD_EVENTS_DEBUG("Event_Mouse_ButtonRelease(Button = '%d')\n", Button);
                                                return 0;
                                            };

                                            //! Window event mouse button press
                                            /*! This event is called when user press mouse button on this window
                                                    \fn			inline virtual UINT Event_Mouse_ButtonPress(const UINT Button, const int cX, const int cY);
                                                    \param[in]  Button : Mouse button pressed
                                                    \param[in]  cX     : X coordinate relative to control
                                                    \param[in]  cY     : Y coordinate relative to control
                                                    \return		If this function is replaced, you need return 0.
                                                    \remarks    This function only handles mouse buttons, not the wheel. Button can be : LeftBtn = 0, MiddleBtn = 1, RightBtn = 2, ExtraBtn 3+
                                                    \sa         Event_Mouse_ButtonRelease(), Event_Mouse_DoubleClick(), Event_Mouse_Wheel(), Event_Mouse_Move(), Event_Mouse_Enter(), Event_Mouse_Leave()
                                            */
         inline virtual UINT                Event_Mouse_ButtonPress(const UINT Button, const int cX, const int cY) {
                                                LMD_EVENTS_DEBUG("Event_Mouse_ButtonPress(Button = '%d')\n", Button);
                                                return 0;
                                            };

                                            //! Window event mouse movement
                                            /*! This event is called when user moves the mouse over this window.
                                                    \fn			inline virtual UINT Event_Mouse_Move(const int cX, const int cY);
                                                    \param[in]  cX     : X coordinate relative to control
                                                    \param[in]  cY     : Y coordinate relative to control
                                                    \return		If this function is replaced, you need return 0.
                                                    \remarks    Window doesnt need have focus to get this event
                                                    \sa         Event_Mouse_ButtonPress(), Event_Mouse_ButtonRelease(), Event_Mouse_DoubleClick(), Event_Mouse_Wheel(), Event_Mouse_Enter(), Event_Mouse_Leave()
                                            */
         inline virtual UINT                Event_Mouse_Move(const int cX, const int cY) {
                                                LMD_EVENTS_DEBUG("Event_Mouse_Move(X = '%d', Y = '%d')\n", cX, cY);
                                                return 0;
                                            };

                                            //! Window event mouse wheel
                                            /*! This event is called when user moves the mouse wheel.
                                                    \fn			inline virtual UINT Event_Mouse_Wheel(const int Direction);
                                                    \param[in]  Direction : 1 forward, -1 backward.
                                                    \return		If this function is replaced, you need return 0.
                                                    \remarks    On Linux the mouse wheel events are send to window that are in the mousepointer position. But in Windows, this event is send to window that has te keyboard focus.
                                                    \sa         Event_Mouse_ButtonPress(), Event_Mouse_ButtonRelease(), Event_Mouse_DoubleClick(), Event_Mouse_Move(), Event_Mouse_Enter(), Event_Mouse_Leave()
                                            */
         inline virtual UINT                Event_Mouse_Wheel(const int Direction) {
                                                LMD_EVENTS_DEBUG("Event_Mouse_Wheel(%d)\n", Direction);
                                                return 0;
                                            };

                                            //! Window event mouse enter
                                            /*! This event is called when mouse enter in the window area.
                                                    \fn			inline virtual UINT Event_Mouse_Enter(void);
                                                    \return		If this function is replaced, you need return 0.
                                                    \remarks    To get this event window dont need the keyboard focus.
                                                    \sa         Event_Mouse_ButtonPress(), Event_Mouse_ButtonRelease(), Event_Mouse_DoubleClick(), Event_Mouse_Move(), Event_Mouse_Wheel(), Event_Mouse_Leave()
                                            */
         inline virtual UINT        		Event_Mouse_Enter(void) {
                                                LMD_EVENTS_DEBUG("Event_Mouse_Enter()\n");
                                                return 0;
                                            };

                                            //! Window event mouse enter
                                            /*! This event is called when mouse enter in the window area.
                                                    \fn			inline virtual UINT Event_Mouse_Leave(void);
                                                    \return		If this function is replaced, you need return 0.
                                                    \remarks    To get this event window dont need the keyboard focus.
                                                    \sa         Event_Mouse_ButtonPress(), Event_Mouse_ButtonRelease(), Event_Mouse_DoubleClick(), Event_Mouse_Move(), Event_Mouse_Wheel(), Event_Mouse_Enter()
                                            */
         inline virtual UINT        		Event_Mouse_Leave(void) {
                                                LMD_EVENTS_DEBUG("Event_Mouse_Leave()\n");
                                                return 0;
                                            };

                                            //! Window event key pressed
                                            /*! This event is called when a key is pressed and this windows has keyboard focus.
                                                    \fn			inline virtual UINT Event_KeyPress(LMDVirtualKey &VirtualKey)
                                                    \param[in]  VirtualKey : Container class for key.
                                                    \return		You must return 0.
                                                    \remarks    LMD::LMDVirtualKey class has various members to determinate which key/s are pressed.
                                                    \sa         LMD::LMDVirtualKey, LMDBaseEvents.h
                                            */
         inline virtual UINT                Event_KeyPress(LMDVirtualKey &VirtualKey) {
                                                LMD_EVENTS_DEBUG("Event_KeyPress(VK=%d, ASC=%c, NL=%d, CL=%d, C=%d, S=%d)\n", VirtualKey.VirtualCode(), VirtualKey.Char(), VirtualKey.NumLock(), VirtualKey.CapsLock(), VirtualKey.Control(), VirtualKey.Shift());
                                                return 0;
                                            };

                                            //! Window event key released
                                            /*! This event is called when a key is released and this windows has keyboard focus.
                                                    \fn			inline virtual UINT Event_KeyRelease(LMDVirtualKey &VirtualKey);
                                                    \param[in]  VirtualKey : Container class for key.
                                                    \return		You must return 0.
                                                    \remarks    LMD::LMDVirtualKey class has various members to determinate which key/s are pressed.
                                                    \sa         LMD::LMDVirtualKey, LMDBaseEvents.h
                                            */
         inline virtual UINT                Event_KeyRelease(LMDVirtualKey &VirtualKey) {
                                                LMD_EVENTS_DEBUG("Event_KeyRelease(VK=%d, ASC=%c, NL=%d, CL=%d, C=%d, S=%d)\n", VirtualKey.VirtualCode(), VirtualKey.Char(), VirtualKey.NumLock(), VirtualKey.CapsLock(), VirtualKey.Control(), VirtualKey.Shift());
                                                return 0;
                                            };

                                            //! Window event get focus
                                            /*! This event is called when this window gets the keyboard focus.
                                                    \fn			inline virtual UINT Event_GetFocus(void);
                                                    \return		You must return 0.
                                                    \remarks    Only one window can have the keyboard focus.
                                                    \sa         Event_LostFocus()
                                            */
         inline virtual UINT                Event_GetFocus(void) {
                                                LMD_EVENTS_DEBUG("Event_GetFocus()\n");
                                                return 0;
                                            };

                                            //! Window event lost focus
                                            /*! This event is called when this window losts the keyboard focus.
                                                    \fn			inline virtual UINT Event_LostFocus(void);
                                                    \return		You must return 0.
                                                    \remarks    Only one window can have the keyboard focus.
                                                    \sa         Event_GetFocus()
                                            */
         inline virtual UINT                Event_LostFocus(void) {
                                                LMD_EVENTS_DEBUG("Event_LostFocus()\n");
                                                return 0;
                                            };


         inline virtual UINT                Event_Resize(const UINT nWidth, const UINT nHeight) {
                                                LMD_EVENTS_DEBUG("Event_Resize(%d, %d)\n",nWidth ,nHeight);
                                                return 0;
                                            }


         inline virtual UINT                Event_Move(const int cX, const int cY) {
                                                LMD_EVENTS_DEBUG("Event_Move(%d, %d)\n", cX, cY);
                                                return 0;
                                            }
    };

};

#endif

/*! \file    LMDBaseEvents.h
	\brief   Basic events for LMD windows.
    \details This file has only one virtual class.                                                                                               \n
             LMD::Windows::Base::LMDBaseEvents is a base class used on all windows of LMD.                                                       \n
             This class has multiple virtual functions linked to a variety of events, and you can overload any of these events to do your tasks. \n
             For example, if you need obtain when key is pressed on a window, you can replace Event_KeyPress.                                    \n
             Basic events are the same, under windows and linux.

             They are some event override examples, first replacing the Event_Destroy :
    \code
// Replacing Event_Destroy to prevent closing MyWindow
class MyWindow : public LMD::LMDWindow {
 public :
            MyWindow(void) { };
            // Returning FALSE to prevent user closing this window.
  UINT      Event_Destroy(void) { return FALSE; };
}
    \endcode

            Replacing Event_Mouse_ButtonPress :
    \code
// Getting when user pushing mouse button over this window
class MyWindow : public LMD::LMDWindow {
 public :
            MyWindow(void) { };
            // Printing on debug window mouse button pressed
  UINT      Event_Mouse_ButtonPress(const UINT Button, const int cX, const int cY) {
                LMD_PRINT_DEBUG("MouseButton %d down\n"), Button);
                return 0;
            };
}
    \endcode
*/
