/*! \file    LMDBaseWnd.h
	\brief   Basic window (windows / X11).
*/
#ifndef LMD_BASEWND_H
    #define LMD_BASEWND_H

    #include "LMDPlatform.h"
    #include "LMDBaseEvents.h"
    #include "LMDRegion.h"
    #include "LMDScene.h"

    #ifdef LMD_SO_X11
        #include "Linux/LMDBaseX11.h"
    #endif

    #ifdef LMD_SO_WINDOWS
        #define LMD_USE_DEFAULT_HANDLER WM_USER + 1
    #endif



    //! Espacio de nombres LMD
    namespace LMD {

        class LMDApp;

        //! Superbase class for all root windows and controls
        class LMDBaseWnd : public LMDBaseEvents {
          public : /////////////////// Public members

                                    //! Constructor.
                                    /*! Constructor.
                                        \fn			LMDBaseWnd(void);
                                        \return		Nothing.
                                    */
                                    LMDBaseWnd(void);

                                    //! Destructor.
                                    /*! Destructor.
                                        \fn		   ~LMDBaseWnd(void);
                                        \return		Nothing.
                                    */
            virtual		           ~LMDBaseWnd(void) {
                                        _IDW = 0;
                                    };

                                    //! Function to show / hide this window.
                                    /*! This function shows or hides this window.
                                        \fn			virtual void Visible(const bool nMoStringar);
                                        \param[in]	nShow : true show window, false hide window.
                                        \return		Nothing.
                                    */
            virtual void            Visible(const bool nShow);

            BOOL                    Visible(void) { return FALSE; };

            virtual void            Activate(const bool nActivar) { };

            virtual BOOL            Activated(void) { return FALSE; };

            virtual void            SetFocus(void);

            virtual bool            HasFocus(void) const;

            virtual void            Move(const int cX, const int cY);

            void                    CreateTimer(const UINT nID, const UINT nMiliSegundos) { };

            void                    DestroyTimer(const UINT nID) { };

            virtual BOOL            Destroy(void);

            void                    Opacity(const BYTE nNivel) { };

                                    //! Function to obtain constant identificator asigned to this window.
                                    /*!	This function obtains the constant identificator for this window.
                                        \fn         UINT IDC(void);
                                        \return		Returns the constant ID of this window.
                                        \remarks    This id is used to locate app windows / controls. \n
                                                    For example, if you create 2 buttons (cancel and accept), when you click in any of them you need to identify what button is pressed. \n
                                                    Dont mismatch IDC with IDW, because IDW is used for internal system operations, and IDC is a constant identificator of your windows. \n
                                     *              When you create any window or control, you need specify a constant ID for it.
                                        \sa         IDW()
                                    */
            UINT                    IDC(void) {
                                        return _IDC;
                                    };

                                    //! Function to obtain SO identificator asigned to this window.
                                    /*!	This function obtains the handle used for current SO to identify this window.
                                        \fn         LMDIDW IDW(void);
                                        \return		Returns the ID of this window.
                                        \remarks    LMDIDW on Windows is a HWND type, on X11 is a Window type. \n
                                                    Dont mismatch IDC with IDW, because IDW is used for system to realize some operations, and IDC is a constant ID specified by yours to distinguish our windows.\n
                                                    IDW has a diferent value every time you create the same window.
                                        \sa         IDC()
                                    */
            LMDIDW                  IDW(void) { return _IDW; };

            void                    Repaint(void);

            inline int              X(void) const { return _X; };

            inline int              Y(void) const { return _Y; };

            inline UINT             Width(void) const { return _Width; };

            inline UINT             Height(void) const { return _Height; };

            inline LMDBaseWnd      *Parent(void) { return _Parent; };

            void                    SetRegion(LMDRegion *nRegion);
                                    
                                    
            LMDScene                Scene;

            LMDColor                Color_BackGround;
            LMDColor                Color_ForeGround;

            LMDFont                 Font;



          protected : //////////////// protected members
            LMDRegion             *_Rgn;
            LMDBaseWnd            *_Parent;
            int                    _X;
            int                    _Y;
            UINT                   _Width;
            UINT                   _Height;

                                    //! ID used by SO
            LMDIDW		           _IDW;

                                    //! Constant ID
            UINT                   _IDC;

          private : ////////////////// Private members
            bool                   _MouseInner;

            #ifdef LMD_SO_X11
                                    //! Graphics context (ONLY FOR X11)
//                GC                  gc;
                                    //! Double click time for X11
                Time               _DoubleClickTime;
                                    //! Message handler for X11
                UINT               _MessageHandler(XEvent &Event);

                UINT               _X11_Event_KeyPress(XKeyEvent &Event);
                UINT               _X11_Event_KeyRelease(XKeyEvent &Event);
                UINT               _X11_Event_Mouse_ButtonPress(XButtonEvent &Event);
                UINT               _X11_Event_Mouse_ButtonRelease(XButtonEvent &Event);
                UINT               _X11_Event_ClientMessage(XClientMessageEvent &Event);
                UINT               _X11_Event_Mouse_Move(XMotionEvent &Event);
//                UINT               _X11_Event_Mouse_Enter(XCrossingEvent &Event);
                UINT               _X11_Event_Mouse_Leave(XCrossingEvent &Event);
//                UINT               _X11_Event_Resize(XResizeRequestEvent &Event);
                UINT               _X11_Event_ConfigureNotify(XConfigureEvent &Event);
            #endif

            #ifdef LMD_SO_WINDOWS
                                    //! Double click time for Windows
                DWORD              _DoubleClickTime;
                                    //! Message handler for Windows
                UINT               _MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam);
                                    //! Function to registrate a window class (ONLY FOR WINDOWS)
                ATOM               _RegisterClass(const LMD_PSTR nNombre, const int nIcono, WNDPROC WindowProcedureInicial);

                UINT               _Win_Event_Mouse_ButtonRelease(const UINT Button, LPARAM lParam);
                UINT               _Win_Event_Mouse_ButtonPress(const UINT Button, LPARAM lParam);
                UINT               _Win_Event_Mouse_Move(LPARAM lParam);
                UINT               _Win_Event_Mouse_Wheel(WPARAM wParam);
                UINT               _Win_Event_Mouse_Leave(void);
                UINT               _Win_Event_KeyPress(WPARAM wParam, LPARAM lParam);
                UINT               _Win_Event_KeyRelease(WPARAM wParam, LPARAM lParam);
                UINT               _Win_Event_Resize(LPARAM lParam);
                UINT               _Win_Event_Move(LPARAM lParam);
            #endif
                                    // Copy constructor disabled
                                    LMDBaseWnd(const LMDBaseWnd &) : _IDW(0), _IDC(0) { };
                                    // Copy operator disabled
            LMDBaseWnd             &operator=(const LMDBaseWnd &) { return *this; };

            friend class            LMDApp;

        };							//
        ////////////////////////////// END LMDBaseWnd



    };



#endif

