/*! \file  LMDButton.h
	\brief Basic button for all platforms
*/
#ifndef LMD_BUTTON_H
    #define LMD_BUTTON_H

    #include "LMDBaseWnd.h"
    #include "LMDString.h"
//    #include "LMDFont.h"

    //! Name space LMD
    namespace LMD {
        //! Basic Button
        class LMDButton : public LMDBaseWnd {
          public : ///////////////////////////  Public members
              
                                            //! Constructor
                                            LMDButton(void) { };
                           
                                            //! Destructor
                                           ~LMDButton(void) { 
                                                if (_Rgn != 0) {
                                                    delete _Rgn;
                                                }
                                            };

            void                            CreateButton(LMDBaseWnd *cParent, const UINT cIDC, LMD_PSTR cText, const int cX, const int cY, const UINT cWidth, const UINT cHeight);

            UINT                            Event_Paint(void);
            
            #ifdef LMD_SO_WINDOWS
              private: ///////////////////////  Private members

                                            //! Static message handler (ONLY FOR WINDOWS)
                static LRESULT CALLBACK    _StaticMessageHandler(HWND WndHandle, UINT uMsg, WPARAM wParam, LPARAM lParam);
            #endif

          protected : //////////////////////// Protected members

            LMDString                      _Text;
        };                                  //
        ////////////////////////////////////// END LMDButton
    
    }; // namespace LMD
    
    
    


#endif
