/*! \file LMDPlatform.cpp
	\brief Function definitions for class LMDPlatform
*/
#include "LMDPlatform.h"

/*// System Operativo WINDOWS
#if (LMD_SO == LMD_SO_WINDOWS)
    #include <windows.h>
#endif

// System Operativo LINUX
#if (LMD_SO == LMD_SO_LINUX)
#   include </usr/include/X11/Xlib.h>
#   include </usr/include/X11/Xutil.h>
#   include </usr/include/X11/Xos.h>
#endif
*/


namespace LMD {

    unsigned int LMDPlatform::VersionMayor(void) {
        #ifdef LMD_SO_WINDOWS
            return 0;
        #endif

        #ifdef LMD_SO_X11
            return 0;
        #endif
    };


    unsigned int LMDPlatform::VersionMenor(void) {
        #ifdef LMD_SO_WINDOWS
            return 0;
        #endif

        #ifdef LMD_SO_X11
            return 0;
        #endif
    };

    unsigned int LMDPlatform::VersionRevision(void) {
        #ifdef LMD_SO_WINDOWS
            return 0;
        #endif

        #ifdef LMD_SO_X11
            return 0;
        #endif
    };


    LMD_PSTR LMDPlatform::VersionString(void) {
        #ifdef LMD_SO_WINDOWS
            return NULL;
        #endif

        #ifdef LMD_SO_X11
            return 0;
        #endif
    };


    LMD_PSTR LMDPlatform::Nombre(void) {
        #ifdef LMD_SO_WINDOWS
            return NULL;
        #endif

        #ifdef LMD_SO_X11
            return 0;
        #endif
    };

};

