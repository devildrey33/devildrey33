/*! \file LMDDebug.h
	\brief Some debug tools for LMD
*/
#ifndef LMD_DEBUG_H
    #define LMD_DEBUG_H
    
//    #include "LMDPlatform.h"

    //! Name space LMD
    namespace LMD {
        //! Debug tools
        class LMDDebug {
          public : ///////////  Public members
              
                            //! Constructor
                            LMDDebug(void) { };
                           
                            //! Destructor
                           ~LMDDebug(void) { };
                          
                            //! Function used to print information in debug console
            static int      printf(const char *TXT, ...);
        };                  //
        ////////////////////// END LMDDebug
    
    }; // namespace LMD
    
    
    
    #if defined _DEBUG
        #define LMD_ONLY_DEBUG(od)             od
        #define LMD_PRINT_DEBUG(TXT...)        LMD::LMDDebug::printf(TXT)
    #else
        #define LMD_ONLY_DEBUG(sd)
        #define LMD_PRINT_DEBUG(TXT...)
    #endif


#endif
