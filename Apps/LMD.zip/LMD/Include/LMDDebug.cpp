/*! \file LMDDebug.cpp
	\brief Declarations for LMDDebug class
*/
#include "LMDDebug.h"

#include <stdio.h> // printf
#include <stdarg.h> // va_start

namespace LMD {

    int LMDDebug::printf(const char *TXT, ...) {
        va_list Marker;
        va_start (Marker, TXT);
        int R = vprintf(TXT, Marker);
        va_end(Marker);
        return R;
    }

};
