#ifndef LMD_WINDOW_H
#define LMD_WINDOW_H

#include "LMDBaseWnd.h"

/*#ifdef LMD_SO_WINDOWS
    #include "Windows/LMDWindowWin.h"
    #define LMDWindow LMDWindowWin
#endif

#ifdef LMD_SO_LINUX
    #include "Linux/LMDWindowLinux.h"
    #define LMDWindow LMDWindowLinux
#endif*/


    //! Name space LMD
    namespace LMD {
        //! Root titled window class for all platforms
        class LMDWindow : public LMDBaseWnd {
          public: ////////////////////////////  Public members

                                            //! Constructor
                                            LMDWindow(void) : LMDBaseWnd() { };

                                            //! Destructor
                                           ~LMDWindow(void) { Destroy(); };

                                            //! Function to create a root titled window
            LMDIDW                          Create(const UINT nIDC, LMDBaseWnd *nParent, const LMD_PSTR nName, const LMD_PSTR nTitle, const int cX, const int cY, const int CWidth, const int cHeight, const bool nVisible = true);
            #ifdef LMD_SO_WINDOWS
              private: ///////////////////////  Private members

                                            //! Static message handler (ONLY FOR WINDOWS)
                static LRESULT CALLBACK    _StaticMessageHandler(HWND WndHandle, UINT uMsg, WPARAM wParam, LPARAM lParam);
            #endif
        };                                  //
        ////////////////////////////////////// END LMDWindow



    };


#endif

/*! \file    LMDWindow.h
	\brief   Root Window (windows/linux).

    \code
// A window object
class MyWindow : public LMD::Windows::LMDWindow {
  public :
           MyWindow(void) { };
    void   Func(void) { };
};
    \endcode

            To get extended information about LMDWindow functions you can view any of these pages : LMD::Windows::LMDWindowWin or LMD::Windows::LMDWindowLinux
            These two classes have the same public functions and events.

*/
