/*! \file LMDApp.h
	\brief Main LMD header
*/
#ifndef LMD_APLICATION_H
    #define LMD_APLICATION_H

    #include "LMDPlatform.h"
    #include "LMDBaseApp.h"

    //! Name space LMD
    namespace LMD {
        //! Main template used to start aplication
        template <class LMD_APP_TYPE> class LMD_Start;

        //! Main template for System
        template <class LMD_APP_TYPE> class LMDSystem {
          public :
                            LMDSystem(void) : App() { };
                           ~LMDSystem(void) { };
            LMD_APP_TYPE    App;
        };

        //! Main template used to start aplication
        template <class LMD_APP_TYPE> class LMDStart {
          public :
                                                LMDStart(void) { };
                                               ~LMDStart(void) { };
            int                                 Execute(void) {
                                                    int Ret = 0;
                                                    #ifdef LMD_SO_X11
//                                                        Ventanas::Base::LMDLinuxBase::ObtenerDisplay():
                                                    #endif
                                                    if (System.App.Start() == TRUE) {
                                                        Ret = System.App.MessageBucle();
                                                        System.App.End();
                                                    }
                                                    return Ret;
                                                };
            static LMDSystem<LMD_APP_TYPE>      System;
        };

        //! Static system member
        template <class LMD_APP_TYPE> LMDSystem<LMD_APP_TYPE> LMDStart<LMD_APP_TYPE>::System;

        //! Macro used to link variable System to our files
        #define LMD_LINK_SYSTEM(LMD_APP_TYPE) static LMD::LMDSystem<LMD_APP_TYPE> &System = LMD::LMDStart<LMD_APP_TYPE>::System;



    }

#endif
