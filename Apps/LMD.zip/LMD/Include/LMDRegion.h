/*! \file  LMDRegion.h
	\brief Regions for all platforms
*/
#ifndef LMD_REGION_H
    #define LMD_REGION_H

    #include "LMDPlatform.h"

    #ifdef LMD_SO_X11
        #include "Linux/LMDBaseX11.h"
        typedef Region   LMDRegionType;
    #endif

    #ifdef LMD_SO_WINDOWS
        typedef HRGN     LMDRegionType;
    #endif


    //! Name space LMD
    namespace LMD {
        //! Basic Button
        class LMDRegion {
          public : ///////////////////////////  Public members
              
                                            //! Constructor
                                            LMDRegion(void);
                           
                                            //! Destructor
                                           ~LMDRegion(void);

            void                            Free(void);

            void                            CreateRect(const int cX, const int cY, const UINT cWidth, const UINT cHeight);

            void                            CreateRoundRect(const int cX, const int cY, const UINT cWidth, const UINT cHeight, const UINT cElipse_Width, const UINT cElipse_Height);

            inline bool                     IsEmpty(void) const { return (_Region == 0); };

            bool                            PointInRegion(const int cX, const int cY) const;

            bool                            RectInRegion(const int cX, const int cY, const UINT cWidth, const UINT cHeight) const;

            void                            Move(const int cX, const int cY);

            inline LMDRegionType            operator() (void) { return _Region; }

          private : ////////////////////////// Private members
            LMDRegionType                  _Region;
        };                                  //
        ////////////////////////////////////// END LMDRegion
    
    }; // namespace LMD
    
    
    


#endif
