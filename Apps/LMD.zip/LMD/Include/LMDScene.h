/*! \file  LMDScene.h
	\brief Graphics for windows / X11
*/
#ifndef LMD_PAINT_H
    #define LMD_PAINT_H
    
//    #include "LMDPlatform.h"
    #include "LMDColor.h"
    #include "LMDFont.h"

    #ifdef LMD_SO_X11
    //    #include "Linux/LMDBaseX11.h"
        typedef GC      LMDPC;
        typedef Pixmap  LMDPM;
    #endif
    #ifdef LMD_SO_WINDOWS
        typedef HDC     LMDPC;
        typedef HBITMAP LMDPM;
    #endif


    //! Name space LMD
    namespace LMD {

        class LMDBaseWnd;
        class LMDBaseControl;


        class LMDScene {
          public :
                            LMDScene(void);
                           ~LMDScene(void);
            void            CreateScene(LMDBaseWnd *BaseWnd, const UINT nWidth, const UINT nHeight, const bool ParentBackGround = false);
            void            ResizeScene(const UINT nWidth, const UINT nHeight);
            void            Free(void);
            void            PaintScene(const int nX, const int nY, const UINT nWidth, const UINT nHeight);
            void            DrawRectangle(const int cX, const int cY, const UINT cWidth, const UINT cHeight, ULONG cColor);
            void            FillRectangle(const int cX, const int cY, const UINT cWidth, const UINT cHeight, ULONG cColor);
            void            FillGradient(const int cX, const int cY, const UINT cWidth, const UINT cHeight, ULONG cColor1, ULONG cColor2, const bool Horizontal = false);
            void            DrawText(char *nText, const int cX, const int cY, ULONG cColor, LMDFont *nFont = NULL);
            void            DrawText(wchar_t *nText, const int cX, const int cY, ULONG cColor, LMDFont *nFont = NULL);
            UINT            GetTextWidth(char *nText, LMDFont *nFont = NULL);
            UINT            GetTextWidth(wchar_t *nText, LMDFont *nFont = NULL);
            void            CreateRegion();
            void            ForeGround(ULONG FG);
            void            BackGround(ULONG BG);
            inline UINT     Width(void)  { return _Width;  };
            inline UINT     Height(void) { return _Height; };
//            void            SetFont(LMDFont *nFont);
          private :
            bool           _ParentBackGround;
//            LMDFont       *_Font;
            LMDPC          _PaintContext;
            LMDPM          _PixMap;
            LMDBaseWnd    *_AsociatedWnd;
            UINT           _Width;
            UINT           _Height;
            bool           _NeedRepaint;
            ULONG          _ForeGround;
            ULONG          _BackGround;
            #ifdef LMD_SO_X11
              Display     *_Dis;
            #endif
            friend class    LMDBaseWnd;
            friend class    LMDBaseControl;
        };





    }; // namespace LMD
    
    


#endif
