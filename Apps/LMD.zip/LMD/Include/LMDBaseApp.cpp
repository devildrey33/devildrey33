/*! \file  LMDBaseApp.cpp
	\brief Definitions for class LMDApp (windows / X11)
*/
#ifndef LMD_BASEAPP_CPP
    #define LMD_BASEAPP_CPP

    #include "LMDBaseApp.h"
    #include "LMDVirtualKey.h"
    #include "LMDDebug.h"
    #include "Linux/LMDBaseX11.h"
    #include "LMDBaseWnd.h"

    namespace LMD {

        #ifdef LMD_SO_WINDOWS
            LMDApp::LMDApp(void) {
            }

            int LMDApp::MessageBucle(void) {
                MSG Msg;
                while (GetMessage(&Msg, NULL, 0, 0) > 0) {
                    TranslateMessage(&Msg);
                    DispatchMessage(&Msg);
                }
                return static_cast<int>(Msg.wParam);
            };

            void LMDApp::TerminateApp(void) {
                PostQuitMessage(0);
            };
        #endif



        #ifdef LMD_SO_X11
            
//            #include <stdio.h> // printf para imprimir el debug

            LMDApp::LMDApp(void) : _TerminateApp(false) {
            };

            int LMDApp::MessageBucle(void) {
                XEvent Event;
                LMDInstance<LMDBaseX11> X11Base;
                while(1) {
    //                XPeekEvent(X11Base()->DISPLAY(), &Event); // PeekEvent no me devuelve eventos para ventanas :/
                    if (_TerminateApp == true) return 0;
                    XNextEvent(X11Base()->DISPLAY(), &Event);
                    X11Base()->FindBaseWnd(Event.xany.window)->_MessageHandler(Event);
                }
                return 0;
            };



            void LMDApp::TerminateApp(void) {
                _TerminateApp = true;
            };

        #endif

    };

#endif
