/*! \file  LMDBaseApp.h
	\brief Basic aplication class
*/
#ifndef LMD_BASEAPP_H
    #define LMD_BASEAPP_H

    #include "LMDPlatform.h"

    #ifdef LMD_SO_X11
//        #include </usr/include/X11/Xlib.h>

    #endif

    //! Name space LMD
    namespace LMD {

//        class LMDBaseWnd;

        //! Base aplication class (windows/linux)
        class LMDApp {
          public: //////////////////////////////////////// Public members

                                                        //! Constructor.
                                                        /*! Constructor.
                                                                \fn			LMDApp(void);
                                                                \return		No devuelve nada.
                                                        */
                                                        LMDApp(void);

                                                        //! Destructor.
                                                        /*! Destructor .
                                                                \fn	       ~LMDApp(void);
                                                                \return		No devuelve nada.
                                                        */
//                                                       ~LMDApp(void) {  } ;

                                                        //! Función virtual que es llamada al iniciar la aplicacion.
                                                        /*! Esta función virtual es llamada al iniciar la aplicacion.
                                                                \fn		virtual const BOOL Inicio(void);
                                                                \return		Devuelve TRUE si quieres continuar con el BucleMensajes, FALSE para abortar la ejecuci�n.
                                                                \remarks	Esta funcion vendria a ser nueStringo WinMain, si no quieres que luego se usen las funciones
                                                                                BucleMensajes() y Fin() devuelve FALSE.
                                                        */
            virtual BOOL                                Start(void) { return TRUE; };

                                                        //! Función virtual que es llamada al terminar la aplicacion.
                                                        /*! Esta función virtual es llamada al terminar la aplicacion.
                                                                \fn		virtual void Fin(void);
                                                                \return		No devuelve nada.
                                                                \remarks	Esta funcion es llamada cuando se ha terminado el BucleMensajes.
                                                        */
            virtual int                                 MessageBucle(void);

            virtual void                                End(void) {	};

                                                        //! Función virtual que contiene un bucle de mensajes estandar.
                                                        /*! Esta función virtual contiene un bucle de mensajes estandar.
                                                                \fn		virtual int BucleMensajes(void);
                                                                \return		Devuelve el ultimo mensaje.
                                                        */
            void                                        TerminateApp(void);

            void                                        WaitEvent(void);

            void                                        LookEvent(void);
          protected:
            #ifdef LMD_SO_X11
                bool                                   _TerminateApp;
            #endif

//                friend class                 LMDBaseWnd;

        };									            //
        ////////////////////////////////////////////////// End LMDApp

    }

#endif
