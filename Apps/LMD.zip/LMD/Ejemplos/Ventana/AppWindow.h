// Ejemplo ventana
#include "../../Include/LMDApp.h"
#include "MyWindows.h"

class AppWindow : public LMD::LMDApp {
 public:
    BOOL        Start(void)        { 
                    V.Create(ID_MYWINDOW1);
                    V2.Create(ID_MYWINDOW2);
                    V2.Move(300,100);
                    V2.Visible(false);
//                    bool b = V2.HasFocus();
                    //V2.SetFocus();
                    return TRUE;
                };
                
    MyWindow1  V;
    MyWindow2  V2;

};
