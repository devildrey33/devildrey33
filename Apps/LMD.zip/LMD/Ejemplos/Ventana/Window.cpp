

#include "AppWindow.h"

// MAIN para windows
#ifdef LMD_SO_WINDOWS
    int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
        LMD::LMDStart<AppWindow> App;
        return App.Execute();
    }
#endif

// MAIN para linux
#ifdef LMD_SO_X11
    int main(void) {
        LMD::LMDStart<AppWindow> App;
        return App.Execute();
    }
#endif
