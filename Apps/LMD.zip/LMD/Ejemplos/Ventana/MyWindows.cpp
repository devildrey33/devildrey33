// Ejemplo ventana
#include "MyWindows.h"
#include "AppWindow.h"
#include "../../Include/LMDDebug.h"

#define ID_MYWINDOW1 100
#define ID_MYWINDOW2 101
#define ID_MYBUTTON  102

LMD_LINK_SYSTEM(AppWindow);


LMDIDW MyWindow1::Create(const UINT nID) {
    Color_BackGround = LMD_RGB(255, 0, 0);
    LMD::LMDWindow::Create(nID, NULL, String("MyWindow1"), String("My Window 1"), 100, 100, 300, 300, false);
    Button.CreateButton(this, ID_MYBUTTON, String("Button"), 10, 10, 100, 20);
    return _IDW;
};

UINT MyWindow1::Event_Destroy(void) {
    System.App.TerminateApp();
    LMD::LMDWindow::Event_Destroy();
    return TRUE;
};

UINT MyWindow1::Event_Paint(void) {
    Scene.FillGradient(0, 0, Scene.Width(), Scene.Height(), LMD_RGB(0, 255, 0), LMD_RGB(0,0,0), true);
    return 0;
}









LMDIDW MyWindow2::Create(const UINT nID){
    LMD::LMDWindow::Create(nID, NULL, String("MyWindow2"), String("My Window 2"), 200, 200, 300, 300, false);
    return _IDW;
};


UINT MyWindow2::Event_KeyPress(LMD::LMDVirtualKey &VirtualKey) {
    LMD_PRINT_DEBUG("MyWindow2::");
    return LMD::LMDWindow::Event_KeyPress(VirtualKey);
};

UINT MyWindow2::Event_Paint(void) {
    Scene.DrawRectangle(10, 10, Scene.Width() - 20, Scene.Height() - 20, LMD_RGB(0,0,0));
    Scene.FillGradient(20, 20, Scene.Width() - 40, Scene.Height() - 40, LMD_RGB(255, 255, 255), LMD_RGB(0,0,0), true);
    return 0;
}





