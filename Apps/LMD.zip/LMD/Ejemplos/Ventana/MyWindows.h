#ifndef MY_WINDOWS
#define MY_WINDOWS

#include "../../Include/LMDWindow.h"
#include "../../Include/LMDButton.h"

#define ID_MYWINDOW1 100
#define ID_MYWINDOW2 101


class MyWindow1 : public LMD::LMDWindow {
 public :
                    MyWindow1(void) { };

     LMDIDW         Create(const UINT nID);

     UINT           Event_Destroy(void);

     UINT           Event_Paint(void);

     LMD::LMDButton Button;
};

class MyWindow2 : public LMD::LMDWindow {
 public :
                MyWindow2(void) { };

     LMDIDW     Create(const UINT nID);

     UINT       Event_KeyPress(LMD::LMDVirtualKey &VirtualKey);
     
     UINT       Event_Paint(void);
};

#endif
