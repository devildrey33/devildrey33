<?php 
	include "devildrey33_PintarCodigo.php";
	$PintarCodigo = new devildrey33_PintarCodigo;
?>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    	<title>Ejemplo de devildrey33_PintarCodigo</title>
        <?php $PintarCodigo->CSS(); ?>
	</head>
    <body>
    	<p>Ejemplo de devildrey33_PintarCodigo :</p>
        <a href="ColorearCodigoPHP_devildrey33_PintarCodigo.php">Volver a devildrey33</a>.
        <?php $PintarCodigo->PintarArchivoPHP("IDEjemplo", "devildrey33_PintarCodigo.php", "devildrey33_PintarCodigo.php"); ?>
        <a href="ColorearCodigoPHP_devildrey33_PintarCodigo.php">Volver a devildrey33</a>.
	</body>
</html>