/* devildrey33_ComboBox.js
	
	Descripción :
		Este control viene a ser una copia del devildrey33_ComboBox creado para www.devildrey33.es que permite seleccionar una opcion de una lista.
		En www.devildrey33.es se utilizaba para elegir el filtro que queriamos para mostrar los artículos.
		La idea es que funcione al 100% con javascript sin jquery ni frameworks externos, sin necesidad de usar php.
		El control consiste en una caja con un texto, que al pasar el mouse por encima despliega una lista de opciones a elegir.
		El primer control era algo burdo y muy poco adaptable, por ello he querido enmendar la situación creando este nuevo control desde cero orientado a objetos, 
		y que ademas no requiera componentes externos.
		NOTA : Este control no esta diseñado para miles de opciones, si hay mas opciones de las que caben en pantalla no será muy agradable para el usuario.
	
	Creado 				: 21/12/2012
	Última modificación : 05/01/2013
	Versión 			: 2.0 BETA			
			
	Incluir animación de colores : [DESCARTADO POR EL MOMENTO]
		- Es bien sabido que todo el tema de colores debe llevarse desde CSS, pero si quiero que al desplegar el menu cambie su fondo de negro a blanco por ejemplo, 
		  Internet Explorer no podrá hacerlo si se utiliza el metodo de transition.
		- Se podrian crear 2 clases en CSS que tuvieran los colores para la animación, pero esto requeriria crear 2 objetos solo para obtener dichos colores, y personalmente es liar mucho la cosa.

	NOTAS IE8 E INFERIORES :
		- innerHTML y AppendChild no funcionan en etiquetas personalizadas, por ejemplo "<devildrey33_ComboBox>"
		- addEventListener no funciona hay que usar attachEvent, y el objeto this cambia...
		- Los eventos no saltan igual, y ya no he perdido mas el tiempo para ver de que forma saltan...
			
	Compatibilidad :
		Este control deberia funcionar en cualquier navegador compatible con CSS3 actual, y tambien con Internet explorer 9, con navegadores mas antiguos no creo que funcione.

	TODO 2.0 BETA :
		HECHO	- Añadir animación al mostrar / ocultar la lista. (sin jquery)
		HECHO	- Añadir imagen de una flecha hacia abajo/arriba.
		HECHO	- Añadir / Eliminar Items una vez creado el ComboBox.
		HECHO	- Modificar texto de un item una vez creado el ComboBox.
		HECHO   - Buscar solución para el OnLoad, (ahora mismo hay que crear el script despues de crear la etiqueta devildrey33_ComboBox)
		HECHO	 	Una posibilidad seria crear un temporizador que vaya mirando si existe la etiqueta devildrey33_ComboBox en cuestion.
		HECHO	- Añadir parametro Opciones 
		HECHO		Desplegar combo hacia arriba o hacia abajo.
		HECHO		Permitir que se muestre el item seleccionado en la lista.
		HECHO		Desactivar animaciones (mostrar / ocultar)
		HECHO		Orden del array.
		HECHO 	- Permitir un ComboBox sin items.

*/


// Variable global que contiene todos los ComboBox creados (es necesaria para funciones y eventos que cambian el scope a global)
var var_devildrey33_ComboBox = [];
// Variable global que guarda el temporizador de las animaciones
var var_devildrey33_ComboBox_TemporizadorAnimacion = 0;
// Variable que cuenta los intentos de utilizar la función _Crear con el temporizador
var _Intentos = 0;
// Variable que contiene el temporizador para iniciar el control
var _TemporizadorCrear = 0;


// Objeto para controlar un item
function devildrey33_ComboBox_Item(nTexto) {
	if (typeof nTexto !== 'undefined') 	this._Texto = nTexto;
	if (!this.Objeto) this.Objeto = "";
	
	/* Función para asignar o obtener el texto de este item
		NuevoValor [Opcional] 	: Si se especifica este parámetro la funcion modificara el texto, en caso contrario devolvera el texto actual.
		Retorno					: Si no se ha especificado el parámetro opcional devolvera el texto de este item.
	 */
	this.Texto = function(NuevoValor) {
		// Si no hay parámetro, devuelvo la variable texto
		if (typeof NuevoValor === 'undefined') return this._Texto;
		// Si hay parámetro lo asigno como nuevo valor para la variable _Texto
		this._Texto = NuevoValor;
		// Si el Objeto existe asignamos su html
		if (this.Objeto)	this.Objeto.innerHTML = this._Texto;
	}
	
	/* Función que determina si este item es visible
		Retorno : Devuelve true si el item es visible, false si no lo es.
		NOTA	: Puede haber un item invisible si la opcion "MostrarItemSeleccionadoEnLista" es false.
				  Este item será el seleccionado.
	 */
	this.Visible = function() {
		if (this.Objeto.style.display != "none") return true;
		return false;
	}
}


/* Objeto que contiene todos los datos y funciones de un devildrey33_ComboBox
	nID 			: ID única para el control.
	nItems 			: Array que contiene una lista de items para este control.
	FuncionOnChange : Función a la que se respondera cuando se seleccione un nuevo item.
	Opciones		: Array de opciones que puede contener uno o mas de los siguientes valores :
		Opciones["MostrarItemSeleccionadoEnLista"] 	= false		Si se asigna a true no se ocultara el item seleccionado dentro de la lista (Por defecto solo se muestra en la cabecera)
		Opciones["DesplegarListaHaciaArriba"] 		= false		Si se asigna a true la lista de items se desplegara hacia arriba. (Por defecto se despliega hacia abajo)
		Opciones["OrdenarItems"] 					= null		Puede ser : null (se dejará intacto), "OrdenAsc", "OrdenDesc", "?" (Aleatório)
		Opciones["Animacion"] 						= true		Utilizar animación al desplegar y ocultar la lista. (Por defecto se animara)
		Opciones["AnimacionTiempo"]					= 100		Tiempo de la animación en milisegundos (por defecto 100)
		Opciones["MostrarFlecha"]					= true		Muestra una flecha en la direccion que se despliega la lista en la parte lateral derecha (por defecto es true, si se especifica false no se mostrará)
		Opciones["ItemSeleccionado"]				= 0			Item que quedara seleccionado al crear el control. (Por defecto es 0, que será el primer item insertado)
 */
function devildrey33_ComboBox(nID, nItems, FuncionOnChange, Opciones) {
	/* -------------------------------------- */
	/* Obtencion de valores para el ComboBox */
	/* ------------------------------------ */
	this.Opciones = { 
		"MostrarItemSeleccionadoEnLista" 	: false,
		"DesplegarListaHaciaArriba"			: false,
		"OrdenarItems"						: null,
		"Animacion"							: true,
		"AnimacionTiempo"					: 100,
		"MostrarFlecha"						: true,
		"ItemSeleccionado"					: 0
	};
	// Si se ha definido la variable Opciones
	if (Opciones) {
		// Mostrar el Item seleccionado en la lista
		if (Opciones["MostrarItemSeleccionadoEnLista"]) this.Opciones["MostrarItemSeleccionadoEnLista"] = Opciones["MostrarItemSeleccionadoEnLista"];
		// Desplegar la lista hacia arriba
		if (Opciones["DesplegarListaHaciaArriba"]) 		this.Opciones["DesplegarListaHaciaArriba"] 		= Opciones["DesplegarListaHaciaArriba"];
		// Orden de los items
		if (Opciones["OrdenarItems"]) 					this.Opciones["OrdenarItems"] 					= Opciones["OrdenarItems"];
		// Realizar animación
		if (Opciones["Animacion"]) 						this.Opciones["Animacion"] 						= Opciones["Animacion"];
		// Tiempo de la animación
		if (Opciones["AnimacionTiempo"]) 				this.Opciones["AnimacionTiempo"] 				= Opciones["AnimacionTiempo"];
		// Flecha que indica hacia donde se despliega el control
		if (Opciones["MostrarFlecha"]) 					this.Opciones["MostrarFlecha"] 					= Opciones["MostrarFlecha"];
		// Texto que se mostrará
		if (Opciones["ItemSeleccionado"]) 				this.Opciones["ItemSeleccionado"] 				= Opciones["ItemSeleccionado"];
	}
	
	// Estado de la animación
	this._Animando = "";
	// Altura actual de la ComboBox en la animación
	this._AnimacionAltura = 0;
	// Margen actual de la lista del ComboBox en la animación (solo para animaciones hacia arriba)
	this._AnimacionMargen = 0;
	// Posición top actual de la lista del ComboBox en la animación (solo para animaciones hacia arriba)
	this._AnimacionTop = 0;
	// Array interno para guardar los items
	this._Items = [];
	// Función que se llamara al cambiar la selección
	this.FuncionOnChange = FuncionOnChange;
	// Guardamos la ID y establecemos el objeto que contiene las diapositivas
	this.ID = nID;
	// Asigno esta clase a la variable global necesaria para los eventos
	var_devildrey33_ComboBox[this.ID] = this;
	/* ------------------------------------------------ */
	/* Fin de la obtención de valores para el ComboBox */
	/* ---------------------------------------------- */


	/* Función que devuelve el total de items dentro de este ComboBox
			function TotalItems();
			Retorno : Esta función devuelve el total de items dentro del ComboBox.
	 */
	this.TotalItems = function() {
		return this._Items.length;
	}

	/* Función que devuelve item de la posicion especificada
			function Item(nPos);
			nPos	: Posición del item que queremos obtener, (0 hasta TotalItems())
			Retorno : Esta función devuelve el item de la posicion especificada en forma del objeto devildrey33_ComboBox_Item
	 */
	this.Item = function(nPos) {
		return this._Items[nPos];		
	}
	

	/* Función que borra todos los items del ComboBox
			function BorrarTodo();
			Retorno : Esta función no devuelve nada.
			NOTA    : Tambien se borrara el texto del objeto que contiene el item seleccionado.
	 */
	this.BorrarTodo = function() {
		delete this._Items;
		this._Items = [];
		this.ObjetoListaItems.innerHTML = "";
	}

	/*  Función para agregar un item en la posición especificada, se puede omitir la posición para agregar el item al final de la lista.
			function ArgegarItem(nTexto, nPos);
			nTexto			: Texto para el item
			nPos [Opcional]	: Posición para el item (debe ser un valor entre 0 y TotalItems(), tambien puede ser "Inicio", "Final", "OrdenAsc", "OrdenDesc", "?" (Aleatório))
			Retorno 		: Esta función no devuelve nada.
			NOTA   			: se puede usar dinamicamente una vez creado el ComboBox.
	 */
	this.AgregarItem = function(nTexto, nPos) {
		if (typeof nPos === 'undefined') nPos = null;
		switch (nPos) {
			case null :
			case "Final" :
				nPos = this._Items.length;
				this._Items.push(new devildrey33_ComboBox_Item(nTexto));												
				break;
			case "Inicio" : 
				nPos = 0;
				this._Items.splice(0, 0, new devildrey33_ComboBox_Item(nTexto));										
				break;
			case "OrdenAsc"  :
			case "OrdenDesc"  : 
			 	this._Items.push(new devildrey33_ComboBox_Item(nTexto));												
				break;
			case "?"  : 
				nPos = Math.floor(Math.random() * _Items.lenght);
				this._Items.splice(nPos, 0, devildrey33_ComboBox_Item(nTexto));	
				break;
			default :
				this._Items.splice(nPos, 0, new devildrey33_ComboBox_Item(nTexto));										
				break;
		}
		
		if (nPos == "OrdenAsc" || nPos == "OrdenDesc") 	this._Items.sort();
		if (nPos == "OrdenDesc") 						this._Items.reverse();

		// Añadimos un item dinamicamente
		if (this.ObjetoListaItems) {
			var NuevoLI = document.createElement("li");
			NuevoLI.className = "devildrey33_ComboBox_Item";
			NuevoLI.innerHTML = nTexto;
			var InsertarEn = this.ObjetoListaItems.childNodes[nPos];
			if (nPos > this.ObjetoListaItems.childNodes.length - 1) InsertarEn = null; // Internet explorer requiere que se le pase null para agregar al final.
			var NuevoObjeto = this.ObjetoListaItems.insertBefore(NuevoLI, InsertarEn);
			this._Items[nPos].Objeto = NuevoObjeto;
			this._EnlazarEvento(NuevoObjeto, "click", this._OnClick);

			// Ordenamos los items si es necesario
			if (nPos == "OrdenAsc" || nPos == "OrdenDesc") {
				for (var i = 0; i < this._Items.length; i++) this._Items[i].Objeto.innerHTML = this._Items[i]._Texto;
			}
		}
		
	}

	// Creo una lista de los items en memoria ordenados segun las opciones especificadas.
	for (var i = 0; i < nItems.length; i++) this.AgregarItem(nItems[i], this.Opciones["OrdenarItems"]);

	/*  Función para eliminar el item de la posición especificada
			function EliminarItem(nPos);
			nPos	: Posición válida del item que queremos elimiar (Puede ser desde 0 a TotalItems())
			Retorno : Esta función no devuelve nada.
			NOTA    : se puede usar dinamicamente una vez creado el ComboBox.
	 */
	this.EliminarItem = function(nPos) {
		if (this._Items[nPos].Objeto) {
			if (this._Seleccion == nPos) {
				this._Seleccion = 0;
				if (this._Items[this._Seleccion])	this.ObjetoItemSeleccionado.innerHTML = this._Items[this._Seleccion]._Texto;
				else								this.ObjetoItemSeleccionado.innerHTML = "";
			}
			this._Items[nPos].Objeto.parentNode.removeChild(this._Items[nPos].Objeto);
		}
		this._Items.splice(nPos, 1);
	}
	
	/* FIX para agregar nuevas tags con innerHTML de IE.... */
	this._AgregarObjeto = function(Padre, Tag, Clase, ID) {
		var NuevoTag = document.createElement(Tag);
		if (Clase != "") NuevoTag.className = Clase;
		if (ID != "") NuevoTag.id = ID;
		Padre.appendChild(NuevoTag);
	}
	
	/*  Función PRIVADA que crea los objetos que componen el ComboBox
			function _Crear();
			Retorno : Esta función no devuelve nada.
			NOTA    : Esta función debe ser llamada una vez se haya cargado en el documento el tag <devildrey33_ComboBox> no antes.
	 */
	this._Crear = function() {

		// Si no existe el objeto creamos un temporizador que va comprobando cada 100ms si se ha creado
		if (document.getElementById(this.ID)) 	
			clearInterval(this._TemporizadorCrear);
		else
			return - 1;
		
		// Obtenemos el tag <devildrey33_ComboBox>		
		this.TagComboBox = document.getElementById(this.ID);
		
		// Inserto el div que contiene el ComboBox dentro del tag <ComboBox>
		this._AgregarObjeto(this.TagComboBox, "div", "devildrey33_ComboBox_Interno", "devildrey33_ComboBox_" + this.ID);
		
		// Div que contiene el ComboBox
		this.ObjetoComboBox = document.getElementById("devildrey33_ComboBox_" + this.ID);
		// UL que contiene la lista de items
		this.ObjetoListaItems = "";
		// Span que contiene el texto del item seleccionado
		this.ObjetoItemSeleccionado = "";
	
		// Por defecto se selecciona el primer item
		this._Seleccion = this.Opciones["ItemSeleccionado"];

		var Codigo;
		if (this.Opciones["DesplegarListaHaciaArriba"] == false) {
			Codigo = "<span id='devildrey33_ComboBox_ItemSeleccionado_" + this.ID + "'>" + (this._Items[this._Seleccion]).Texto() + "</span>";
			// Añado la flecha 
			if (this.Opciones["MostrarFlecha"] == true) Codigo += "<div class='devildrey33_ComboBox_ImagenAbajoNormal' id='devildrey33_ComboBox_Flecha_" + this.ID + "'> </div>";
			Codigo += "<ul id='devildrey33_ComboBox_ListaItems_" + this.ID + "'>";
			for (var i = 0; i < this._Items.length; i++) {	
				if (this._Seleccion == i && this.Opciones["MostrarItemSeleccionadoEnLista"] == false)	
					Codigo += "<li class='devildrey33_ComboBox_Item' style='display:none'>" + this._Items[i].Texto() + "</li>";
				else
					Codigo += "<li class='devildrey33_ComboBox_Item'>" + this._Items[i].Texto() + "</li>";						
			}
			Codigo += "</ul>";
		}
		else {
			Codigo = "<ul id='devildrey33_ComboBox_ListaItems_" + this.ID + "'>";
			for (var i = 0; i < this._Items.length; i++) {	
				if (this._Seleccion == i && this.Opciones["MostrarItemSeleccionadoEnLista"] == false)	
					Codigo += "<li class='devildrey33_ComboBox_Item' style='display:none'>" + this._Items[i].Texto() + "</li>";
				else
					Codigo += "<li class='devildrey33_ComboBox_Item'>" + this._Items[i].Texto() + "</li>";						
			}
			Codigo += "</ul>";
			Codigo += "<span id='devildrey33_ComboBox_ItemSeleccionado_" + this.ID + "'>" + this._Items[this._Seleccion].Texto() + "</span>";
			// Añado la flecha 
			if (this.Opciones["MostrarFlecha"] == true) Codigo += "<div class='devildrey33_ComboBox_ImagenArribaNormal' id='devildrey33_ComboBox_Flecha_" + this.ID + "'> </div>";
		}
		this.ObjetoComboBox.innerHTML = Codigo;

		// UL que contiene la lista de items
		this.ObjetoListaItems = document.getElementById("devildrey33_ComboBox_ListaItems_" + this.ID);
		// Span que contiene el texto del item seleccionado
		this.ObjetoItemSeleccionado = document.getElementById("devildrey33_ComboBox_ItemSeleccionado_" + this.ID);
		
		// Enlazo todos los items con su objeto (Tag <li>)
		for (var i = 0; i < this._Items.length; i++) this._Items[i].Objeto = document.getElementById("devildrey33_ComboBox_ListaItems_" + this.ID).childNodes[i];

		// Enlazamos los eventos OnClick para cada item y obtenemos el item mas ancho
		var PrimerItemVisible = 0;
		for (PrimerItemVisible; this._Items[PrimerItemVisible].Visible() == false; PrimerItemVisible++) ;

		// Busco el item mas ancho para establecer el ancho del ComboBox, ademas enlazo todos los eventos click de cada item a su div correspondiente		
		var Margen = parseInt(this.ObjetoComboBox.offsetWidth) - parseInt(this._Items[PrimerItemVisible].Objeto.offsetWidth);
		var MasAncho = parseInt(this.ObjetoItemSeleccionado.offsetWidth) + Margen;
		for (var i = 0; i < this._Items.length; i++) {	
			var ItemActual = document.getElementById("devildrey33_ComboBox_ListaItems_" + this.ID).childNodes[i];
			this._EnlazarEvento(ItemActual, "click", this._OnClick);
			if (MasAncho < (parseInt(ItemActual.offsetWidth) + Margen)) MasAncho = parseInt(ItemActual.offsetWidth) + Margen;
		}
		// Si hay que mostrar la flecha, añadimos el ancho
		if (this.Opciones["MostrarFlecha"] == true) MasAncho += 20; // 2 + 16 + 2 [margen + imagen + margen]

		// Ajusto la altura de la clase devildrey33_ComboBox al tamaño del primer item del ComboBox
		this.ObjetoComboBox.style.height = parseInt(this.ObjetoItemSeleccionado.offsetHeight) + "px";
		if (this.Opciones["DesplegarListaHaciaArriba"] == true) this.ObjetoListaItems.style.marginTop = "-" + parseInt(this.ObjetoListaItems.offsetHeight) + "px";
		if (this.Opciones["MostrarFlecha"] == true)	document.getElementById("devildrey33_ComboBox_Flecha_" + this.ID).style.marginTop = ((parseInt(this.ObjetoComboBox.style.height) - 8) / 2) + "px";
		
		// Ajusto el ancho del ComboBox al ancho del item mas grande
		this.ObjetoComboBox.style.width = MasAncho + "px";
		// Ajusto la altura del tag ComboBox al tamaño del div "devildrey33_ComboBox_Interno"
		this.TagComboBox.style.height = parseInt(this.ObjetoComboBox.offsetHeight) + "px";
		this.TagComboBox.style.width = parseInt(this.ObjetoComboBox.offsetWidth) + "px";
		
		// Eventos del mouse (over/out)
		this._EnlazarEvento(this.ObjetoComboBox, "mouseover", this._OnMouseOver);
		this._EnlazarEvento(this.ObjetoComboBox, "mouseout", this._OnMouseOut);

		// Guardo la posición Y inicial una vez colocados todos los objetos.
		// Si se muestra la lista hacia arriba, la posicion del objeto ComboBox es absoluta por lo que el top tiene un valor que no es 0, y necesito guardarlo para mostrar la lista correctamente.
		if (this.Opciones["DesplegarListaHaciaArriba"] == true) {
			this._Top = parseInt(this.ObjetoComboBox.offsetTop);
			this.ObjetoComboBox.style.top = this._Top + "px";
		}
		
		// Devuelvo true para confirmar la creación del control
		return true;
	}
	

	/*  Función para asignar/obtener la posición del item seleccionado.
			function Seleccion(NuevaPos);
			NuevaPos [Opcional]	: Si se especifica este parametro se asignara la nueva posicion especificada. Debe ser un valor válido entre 0 y TotalItems()
			Retorno 			: Esta función no devuelve nada.
			NOTA    			: Si no se especifica el parametro NuevaPos, esta funcion devuelve la posición de la selección.
	 */
	this.Seleccion = function(NuevaPos) {
		if (typeof NuevaPos === 'undefined') return this._Seleccion;

		// Si se ha creado el ComboBox
		if (this.TagComboBox) {
			if (this.Opciones["MostrarItemSeleccionadoEnLista"] == false) {
				this._Items[this._Seleccion].Objeto.style.display = "block";
				this._Items[NuevaPos].Objeto.style.display = "none";
			}
			this.ObjetoItemSeleccionado.innerHTML = this._Items[NuevaPos].Texto();
		}
		
		// Asignamos la nueva posición a la selección
		this._Seleccion = NuevaPos;
	}


	/* 	Función PRIVADA para enlazar un tag con un evento
			function _EnlazarEvento(Objeto, Tipo, Funcion);
			Objeto 	: Tag que queremos enlazar
			Tipo 	: Tipo de evento que queremos enlazar (mousemove, mouseover, click, etc...)
			Funcion	: Función que se nelazara con el evento,
			Retorno : No devuelve nada.
			NOTA	: Función creada para mantener compatibilidad con el IE8.
	 */
	this._EnlazarEvento = function(Objeto, Tipo, Funcion) {
		if (typeof Objeto.addEventListener == "function") 	Objeto.addEventListener(Tipo, Funcion, false);	// Navegadores modernos
		else 												Objeto.attachEvent("on" + Tipo, Funcion);		// IE 8 e inferiores
	}
	
	/* Función para mostrar la lista desplegable
			function MostrarLista();
			Retorno : No devuelve nada.
	 */
	this.MostrarLista = function() {
		if (this.Opciones["DesplegarListaHaciaArriba"] == false) {
			if (this.Opciones["Animacion"] == false) {
				this.ObjetoComboBox.style.height = (parseInt(this.ObjetoListaItems.offsetHeight) + parseInt(this.ObjetoItemSeleccionado.offsetHeight)) + "px";
			}
			else {
				this._IniciarAnimacion("MostrarAbajo");
			}
			if (this.Opciones["MostrarFlecha"] == true) document.getElementById("devildrey33_ComboBox_Flecha_" + this.ID).className = "devildrey33_ComboBox_ImagenAbajoResaltada";
		}
		else {
			if (this.Opciones["Animacion"] == false) {
				this.ObjetoComboBox.style.top = (this._Top - parseInt(this.ObjetoListaItems.offsetHeight)) + "px";
				this.ObjetoListaItems.style.marginTop = "0px";
				this.ObjetoComboBox.style.height = (parseInt(this.ObjetoListaItems.offsetHeight) + parseInt(this.ObjetoItemSeleccionado.offsetHeight)) + "px";
			}
			else {
				this._IniciarAnimacion("MostrarArriba");
			}
			if (this.Opciones["MostrarFlecha"] == true) document.getElementById("devildrey33_ComboBox_Flecha_" + this.ID).className = "devildrey33_ComboBox_ImagenArribaResaltada";
		}
	}

	/* Función para ocultar la lista desplegable
			function OcultarLista();
			Retorno : No devuelve nada.
	 */
	this.OcultarLista = function() {
		if (this.Opciones["DesplegarListaHaciaArriba"] == false) {
			if (this.Opciones["Animacion"] == false) {
				this.ObjetoComboBox.style.height = parseInt(this.ObjetoItemSeleccionado.offsetHeight) + "px";
			}
			else {
				this._IniciarAnimacion("OcultarAbajo");
			}
			if (this.Opciones["MostrarFlecha"] == true) document.getElementById("devildrey33_ComboBox_Flecha_" + this.ID).className = "devildrey33_ComboBox_ImagenAbajoNormal";
		}
		else {
			if (this.Opciones["Animacion"] == false) {
				this.ObjetoListaItems.style.marginTop = "-" + parseInt(this.ObjetoListaItems.offsetHeight) + "px";
				this.ObjetoComboBox.style.height = parseInt(this.ObjetoItemSeleccionado.offsetHeight) + "px";
				this.ObjetoComboBox.style.top = this._Top + "px";
			}
			else {
				this._IniciarAnimacion("OcultarArriba");
			}
			if (this.Opciones["MostrarFlecha"] == true) document.getElementById("devildrey33_ComboBox_Flecha_" + this.ID).className = "devildrey33_ComboBox_ImagenArribaNormal";
		}
	}
	

	/* Función PRIVADA que inicia la animación para desplegar o ocultar la lista
			function _IniciarAnimacion(Tipo);
			Tipo 	: Puede ser MostrarAbajo y OcultarAbajo para desplegar el control hacia abajo, 
					  y MostrarArriba y OcultarArriba para desplegarlo hacia arriba.
			Retorno : No devuelve nada.
	*/
	this._IniciarAnimacion = function(Tipo) {
		this._Animando = Tipo;
		
		// (300ms / 200px) = 15ms (de cada tick del temporizador, si se hace cada 15 segundos son unos 66fps)
		this._AnimacionParte = (parseInt(this.ObjetoListaItems.offsetHeight) / this.Opciones["AnimacionTiempo"]) * 15;
		this._AnimacionAltura = parseInt(this.ObjetoComboBox.style.height);
		// Para las animaciones que se despliegan hacia arriba tambien necesito guardar el margen superior de la lista y la posición Y del control
		if (this._Animando == "MostrarArriba" ||this._Animando == "OcultarArriba") {
			this._AnimacionMargen = parseInt(this.ObjetoListaItems.style.marginTop);
			this._AnimacionTop = parseInt(this.ObjetoComboBox.offsetTop);
		}
				
		// Si no existe el temporizador lo creamos
		if (var_devildrey33_ComboBox_TemporizadorAnimacion == 0) {
			var_devildrey33_ComboBox_TemporizadorAnimacion = setInterval(function() { 
				var Animando = false;
				for (var Combo in var_devildrey33_ComboBox) {
					if (var_devildrey33_ComboBox[Combo]._Animando != "") {
						var_devildrey33_ComboBox[Combo]._Animacion(); 
						Animando = true;
					}
				}				
				// Si no quedan mas animaciones terminamos el temporizador
				if (Animando == false) {
					clearInterval(var_devildrey33_ComboBox_TemporizadorAnimacion);
					var_devildrey33_ComboBox_TemporizadorAnimacion = 0;
				}
			}, 15);
		}
	}


	/* Función PRIVADA que realiza la animación.
			function _Animacion();
			Retorno : No devuelve nada.
	*/
	this._Animacion = function() {
		var Altura = parseInt(this.ObjetoComboBox.style.height);
		switch (this._Animando) {
			case "MostrarAbajo" :
				if (Altura < ((parseInt(this.ObjetoListaItems.offsetHeight) + parseInt(this.ObjetoItemSeleccionado.offsetHeight)) - this._AnimacionParte)) {
					this._AnimacionAltura += this._AnimacionParte;
					this.ObjetoComboBox.style.height = Math.round(this._AnimacionAltura) + "px";
				}
				else {
					this.ObjetoComboBox.style.height = (parseInt(this.ObjetoListaItems.offsetHeight) + parseInt(this.ObjetoItemSeleccionado.offsetHeight)) + "px";
					this._Animando = "";
				}
				break;
			case "OcultarAbajo" :
				if (Altura > (parseInt(this.ObjetoItemSeleccionado.offsetHeight) + this._AnimacionParte)) {
					this._AnimacionAltura -= this._AnimacionParte;
					this.ObjetoComboBox.style.height = Math.round(this._AnimacionAltura) + "px";
				}
				else {
					this.ObjetoComboBox.style.height = parseInt(this.ObjetoItemSeleccionado.offsetHeight) + "px";
					this._Animando = "";
				}
				break;
			case "MostrarArriba" :
				if (Altura < ((parseInt(this.ObjetoListaItems.offsetHeight) + parseInt(this.ObjetoItemSeleccionado.offsetHeight)) - this._AnimacionParte)) {
					this._AnimacionAltura += this._AnimacionParte;
					this._AnimacionTop -= this._AnimacionParte;
					this._AnimacionMargen += this._AnimacionParte;
					this.ObjetoComboBox.style.height = Math.round(this._AnimacionAltura) + "px";
					this.ObjetoComboBox.style.top = Math.round(this._AnimacionTop) + "px"; // parse int elimina decimales sin redondear
					this.ObjetoListaItems.style.marginTop = Math.round(this._AnimacionMargen) + "px";
				}
				else {
					this.ObjetoComboBox.style.height = (parseInt(this.ObjetoListaItems.offsetHeight) + parseInt(this.ObjetoItemSeleccionado.offsetHeight)) + "px";
					this.ObjetoComboBox.style.top = (this._Top - parseInt(this.ObjetoListaItems.offsetHeight)) + "px";
					this.ObjetoListaItems.style.marginTop = "0px";
					this._Animando = "";
				}
				break;
			case "OcultarArriba" :
				if (Altura > (parseInt(this.ObjetoItemSeleccionado.offsetHeight) + this._AnimacionParte)) {
					this._AnimacionAltura -= this._AnimacionParte;
					this._AnimacionTop += this._AnimacionParte;
					this._AnimacionMargen -= this._AnimacionParte;
					this.ObjetoComboBox.style.height = Math.round(this._AnimacionAltura) + "px";
					this.ObjetoComboBox.style.top = Math.round(this._AnimacionTop) + "px";
					this.ObjetoListaItems.style.marginTop = Math.round(this._AnimacionMargen) + "px";
				}
				else {
					this.ObjetoComboBox.style.height = parseInt(this.ObjetoItemSeleccionado.offsetHeight) + "px";
					this.ObjetoComboBox.style.top = this._Top + "px";
					this.ObjetoListaItems.style.marginTop = "-" + parseInt(this.ObjetoListaItems.offsetHeight) + "px";
					this._Animando = "";
				}
				break;
		}
	}

	

	/* 
		NOTA : 	En los eventos On.... se pierde el puntero this, y este se convierte en el objeto que manda el evento, 
		  		por ello se obtiene la ID del ComboBox y se accede a él desde "var_devildrey33_ComboBox[ID]"
	 */
	 
	/* Función PRIVADA para obtener el evento MouseOver y determinar si hay que mostrar la lista
			function _OnMouseOver();
			Retorno : No devuelve nada.
			NOTA	: Mucho cuidado, el puntero this de esta funcion no se refiere a esta clase.
	 */
	this._OnMouseOver = function() {
		// Obtenemos la ID numerica partiendo de la ID del div "devildrey33_ComboBox_??"
		var ID = "";
		if (this.id) 	ID = this.id.substr(String("devildrey33_ComboBox_").length);
		else			ID = window.event.srcElement.id.substr(String("devildrey33_ComboBox_").length); // Solucion IE 8 e inferiores..
//		var ID = this.id.substr(String("devildrey33_ComboBox_").length);
//		devildrey33_Animacion(this, { "height" : (parseInt(this.getElementsByTagName("ul")[0].offsetHeight) + parseInt(document.getElementById("ComboItem_Seleccionado_" + ID).offsetHeight)) + "px" }, 200, "");
		var_devildrey33_ComboBox[ID].MostrarLista();
	}
	
	/* Función PRIVADA para obtener el evento MouseOut y determinar si hay que ocultar la lista
			function _OnMouseOut();
			Retorno : No devuelve nada.
			NOTA	: Mucho cuidado, el puntero this de esta funcion no se refiere a esta clase.
	 */
	this._OnMouseOut = function() {
		// Obtenemos la ID numerica partiendo de la ID del DIV "devildrey33_ComboBox_??"
		var ID = "";
		if (this.id) 	ID = this.id.substr(String("devildrey33_ComboBox_").length);
		else			ID = window.event.srcElement.id.substr(String("devildrey33_ComboBox_").length); // Solucion IE 8 e inferiores..
//		var ID = this.id.substr(String("devildrey33_ComboBox_").length);
		var_devildrey33_ComboBox[ID].OcultarLista();
	}
	
	/* Función PRIVADA para obtener el evento Click y determinar si hay que cambiar la seleccion actual
			function _OnClick();
			Retorno : No devuelve nada.
			NOTA	: Mucho cuidado, el puntero this de esta funcion no se refiere a esta clase.
	 */
	this._OnClick = function() {
		// Obtenemos la ID numerica partiendo de la ID del UL "devildrey33_ComboBox_ListaItems_??"
		var ID = "";
		if (this.parentNode.id) 	ID = this.parentNode.id.substr(String("devildrey33_ComboBox_ListaItems_").length);
		else						ID = window.event.srcElement.parentNode.id.substr(String("devildrey33_ComboBox_ListaItems_").length); // Solucion IE 8 e inferiores..
//		var ID = this.parentNode.id.substr(String("devildrey33_ComboBox_ListaItems_").length);

		// Buscamos la posicion del item en el que se ha hecho click
		var PosItem = 0;
		while (this.parentNode.childNodes[PosItem] != this) PosItem ++;
		
		var_devildrey33_ComboBox[ID].Seleccion(PosItem);
		var_devildrey33_ComboBox[ID].FuncionOnChange(var_devildrey33_ComboBox[ID]);
		var_devildrey33_ComboBox[ID].OcultarLista();
	}
	

	// Temporizador que se ejecuta mientras no existan los tags <devildrey33_ComboBox>
	// NOTA : esto es un fix para no tener que poner el script debajo del tag
	// NOTA2 : Lo de los intentos puede ser malo para webs que tarden mucho en cargar :/, pero dejar el timer cada 20ms me parece tambien malo...	
	if (_TemporizadorCrear == 0) {
		_TemporizadorCrear = setInterval(function () { 
			var Creados = true;
			for (var Combo in var_devildrey33_ComboBox) {
				// Si no existe la variable TagComboBox es que aun no se ha creado la combo
				if (!var_devildrey33_ComboBox[Combo].TagComboBox) {
					if (var_devildrey33_ComboBox[Combo]._Crear() != true) Creados = false;
				}
			}
			// Cuando se han creado todos los objetos, o se han superado los 1000 intentos desactivamos el temporizador
			if (Creados == true || _Intentos > 1000) { 
				clearInterval(_TemporizadorCrear); 
				_TemporizadorCrear = 0; 
			}
			if (_Intentos > 1000) alert("devildrey33_ComboBox : ERROR! uno o más ComboBox no han sido creados despues de 1000 intentos (20 segundos).");
		}, 20);
	}
	
//	this._Crear();
}


