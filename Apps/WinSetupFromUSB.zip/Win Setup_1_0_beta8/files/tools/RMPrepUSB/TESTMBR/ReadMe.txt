
For details on how to use please visit 

http://sites.google.com/site/rmprepusb/tutorials/diagnose-bios

To assemble the code under XP/Vista/Win7:

First obtain MASM 6.11c
Next install DOSBOX (used by gamers for DOS compatibility)
Copy the source files and masm binary executable files to a folder (say C:\TESTMBR)

Run DOSBOX and mount a drive in using the DOSBOX command prompt e.g. - mount D C:\TESTMBR

Now change to D:

Now type makeall  to compile the code into the 5 test files.





	







