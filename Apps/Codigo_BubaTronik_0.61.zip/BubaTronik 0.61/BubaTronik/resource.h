//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BubaTronik.rc
//
#define IDD_DAP_DIALOG                  102
#define IDM_ABOUT                       104
#define IDI_DAP                         107
#define IDI_SMALL                       108
#define IDR_MAINFRAME                   128
#define IDI_INICIO                      129
#define IDI_MP3                         130
#define IDI_DISCO                       132
#define IDI_GENERO                      133
#define IDI_GRUPO                       134
#define IDI_TIPO                        135
#define IDI_C0                          137
#define IDI_C1                          138
#define IDI_C2                          140
#define IDI_C3                          142
#define IDI_ATRAS_N                     143
#define IDI_ATRAS_R                     144
#define IDI_ATRAS_P                     145
#define IDI_PLAY_N                      148
#define IDI_PLAY_P                      149
#define IDI_PLAY_R                      150
#define IDI_PAUSA_N                     151
#define IDI_PAUSA_P                     152
#define IDI_PAUSA_R                     153
#define IDI_ADELANTE_N                  154
#define IDI_ADELANTE_P                  155
#define IDI_ADELANTE_R                  156
#define IDI_STOP_N                      157
#define IDI_STOP_P                      158
#define IDI_STOP_R                      159
#define IDI_CANCION_ADELANTE            161
#define IDI_CANCION_ATRAS               162
#define IDI_CANCION_STOP                163
#define IDI_CANCION_PLAY                165
#define IDI_CANCION_PAUSA               166
#define IDI_CANCION_REPEAT              167
#define IDI_CANCION_SHUFLE              168
#define IDI_MARCA_MENU                  169
#define IDI_BD                          170
#define IDI_BD_REVISAR                  175
#define IDI_BD_SELECCIONAR              176
#define IDI_AYUDA                       177
#define IDI_ESTRELLA2                   178
#define IDI_ESTRELLA                    179
#define IDI_LISTA                       180
#define IDI_LISTA_MODIFICARNOMBRE       181
#define IDI_LISTA_BUSCAR                182
#define IDI_COPIAR                      184
#define IDI_ORDEN                       186
#define IDI_LISTA_LLENA                 187
#define IDI_LISTA_VACIA                 188
#define IDI_GUARDAR                     189
#define IDI_BD_BUSCAR                   190
#define IDI_PAUSA                       192
#define IDI_PLAY                        193
#define IDI_VIDEO                       196
#define IDI_AUDIO                       197
#define IDI_OPCIONES                    198
#define IDI_INICIO2                     199
#define IDI_BDA                         200
#define IDI_EQ                          201
#define IDI_PANTALLA                    202
#define IDI_OPCIONESV                   203
#define IDI_BDV                         204
#define IDI_ELIMINAR                    205
#define IDI_ICON1                       206
#define IDI_LISTA_MODIFICARPISTA        206
#define IDI_CERRAR2                     209
#define IDI_ELIMINAR2                   209
#define IDI_UP                          210
#define IDI_DOWN                        211
#define IDI_BANDERA1                    214
#define IDI_BANDERA2                    215
#define IDI_CERRAR_N                    216
#define IDI_CERRAR_R                    217
#define IDI_MINIMIZAR_N                 218
#define IDI_MINIMIZAR_R                 219
#define IDI_RESTAURAR_R                 220
#define IDI_RESTAURAR_N                 221
#define IDI_ICON2                       222
#define IDI_VLC                         222
#define IDI_M3U                         223
#define IDI_CDAUDIO                     225
#define IDI_ICON3                       226
#define IDI_PISTAAUDIO                  226
#define IDI_ERRORFATAL                  227
#define IDI_ICON4                       228
#define IDI_FMOD                        228
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        229
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
