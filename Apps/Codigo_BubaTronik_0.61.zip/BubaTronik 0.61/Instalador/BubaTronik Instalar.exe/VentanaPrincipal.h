// VentanaPrincipal.h: interface for the VentanaPrincipal class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VENTANAPRINCIPAL_H__D2C951CC_147B_43CD_A462_E868BDCB583B__INCLUDED_)
#define AFX_VENTANAPRINCIPAL_H__D2C951CC_147B_43CD_A462_E868BDCB583B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <DWLVentana.h>
#include "..\Instalador_Creacion\Extractor.h"
//#include <DWLEdicionEx.h>
#include <DWLBotonEx.h>
#include <DWLBarraEx.h>
#include "Resource.h"
#include <DWLEdicionDesplegableEx.h>
#include "MarcaGradient.h"

using namespace DWL;
using namespace ControlesEx;
//using namespace ColoresEx;

class VentanaPrincipal : public DWL::Ventanas::DWLVentana {
public:
										VentanaPrincipal();
									   ~VentanaPrincipal();
 void									Crear(void);
 void									Instalar(void);
 void                                   EliminarDirectorio(const TCHAR *Path);
 LRESULT								Evento_Mouse_Movimiento(const int cX, const int cY, const UINT Param);
 LRESULT								Evento_BotonEx_Mouse_Click(const UINT Boton, const int cX, const int cY, const UINT IDBotonEx, const UINT Param);
 LRESULT								Evento_EdicionDesplegableEx_CambioSeleccion(const TCHAR *NuevoTexto, const UINT IDEdicionTexto);
 LRESULT								Evento_MarcaEx_Mouse_Click(const UINT Boton, const int cX, const int cY, const UINT cID);
 LRESULT								Evento_Cerrar(void);																// Funcion para cerrar el dialogo
 LRESULT								Evento_Pintar(HDC hDC, PAINTSTRUCT &PS);
 DWL::ControlesEx::DWLEdicionDesplegableEx	Edit;
 DWL::ControlesEx::DWLBotonEx			Boton_Salir;
 DWL::ControlesEx::DWLBotonEx			Boton_Instalar;
 DWL::ControlesEx::DWLBarraEx			Barra_Progreso;
 MarcaGradient							Marca_CrearAccesoDirecto;
 MarcaGradient							Marca_MostrarNotas;
 MarcaGradient							Marca_EjecutarBubaTronik;
 Extractor								Ex;
 DWLBotonEx_Colores						ColoresBoton;
 DWLBarraEx_Colores						ColoresBarra;
// LRESULT CALLBACK						GestorMensajes(UINT uMsg, WPARAM wParam, LPARAM lParam);							// Esqueleto del dialogo
 bool									ActualizacionDesdeElPlayer;
};

#endif // !defined(AFX_VENTANAPRINCIPAL_H__D2C951CC_147B_43CD_A462_E868BDCB583B__INCLUDED_)
