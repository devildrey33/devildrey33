
#include <DWLMarcaEx.h>
#include <DWLGraficos.h>
#include <DWLListaIconos.h>
#include "resource.h"

class MarcaGradient : public DWL::ControlesEx::DWLMarcaEx {
 public:
				MarcaGradient(void) { };
			   ~MarcaGradient(void) { };
 void			MarcaEx_Evento_PintarMarca(HDC hDC, RECT *Espacio, const int nEstado) {
					DWL::SO::DWLListaIconos::PintarIcono(hDC, 4, -1, 16, 16, IDI_MARCA_MENU);
				};
 void			MarcaEx_Evento_PintarFondo(HDC hDC, RECT *Espacio) {
					RECT R;
					GetClientRect(GetParent(_hWnd), &R);
					WINDOWPLACEMENT WP;
					WP.length = sizeof(WINDOWPLACEMENT);
					GetWindowPlacement(_hWnd, &WP);
					
					int y = WP.rcNormalPosition.top - (R.bottom / 2); // 110 es la definicion ALTO_INSTALADOR / 2
//					int y = 0 - (R.bottom / 2); // 110 es la definicion ALTO_INSTALADOR / 2
					DWL::GDI::PintarGradient(hDC, 0, 0 - y, Espacio->right, (R.bottom / 2) -y, RGB(150,150,150), RGB(200,200,200));
				};
};
