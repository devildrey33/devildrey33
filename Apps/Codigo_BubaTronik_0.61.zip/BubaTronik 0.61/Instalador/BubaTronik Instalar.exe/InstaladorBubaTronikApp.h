// Instalador BubaTronik.cpp : Defines the entry point for the application.
//

#include "stdafx.h"

#include "VentanaPrincipal.h"
#include <DWLAplicacion.h>
#include <Shellapi.h>



class InstaladorBubaTronikApp : public DWL::DWLAplicacion { 
 public :
						InstaladorBubaTronikApp(void) { };
                       ~InstaladorBubaTronikApp(void) { };

	const BOOL			Inicio(void) { 
							int		TotalArgs	= 0;
							TCHAR **Args		= CommandLineToArgvW(GetCommandLine(), &TotalArgs);
							if (TotalArgs > 1) {
								if (DWLStrCmpi(Args[1], TEXT("Actualizar")) != 0) {
									Wnd.ActualizacionDesdeElPlayer = true;
								}
							}
							Wnd.Crear();
							LocalFree(Args);
							return TRUE;
						};

	VentanaPrincipal	Wnd;

};

DWL_Enlazar_Sistema(InstaladorBubaTronikApp);


