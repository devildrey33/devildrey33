// Instalador BubaTronik.cpp : Defines the entry point for the application.
//

#include "stdafx.h"

#include "InstaladorBubaTronikApp.h"


int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	DWL::DWL_Iniciar<InstaladorBubaTronikApp> Aplicacion;
	return Aplicacion.Ejecutar();
}



