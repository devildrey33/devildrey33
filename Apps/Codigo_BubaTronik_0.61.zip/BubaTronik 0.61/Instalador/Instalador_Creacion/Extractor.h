#pragma once

#include <DWLString.h>
#include <DWLArchivoBinario.h>

class Extractor {
public:		
										Extractor(void);
							           ~Extractor(void);
 const unsigned int						ExtraerDatos(const TCHAR *PathDestinoFinal);
 const int								Descomprimir(const char *ArchivoOrigen, const size_t TamArchivOrigen, DWL::Archivos::DWLArchivoBinario &Destino);
 const bool								ExtraerArchivo();
 const bool								EjecutarArchivo(void);
 inline const TCHAR				       *PathDestinoDefecto(void) {
											return DPath.Texto();
										};
 inline const TCHAR				       *PathDestinoFinal(void) {
											return PathDestino.Texto();
										};
 inline const int						TotalArchivos(void) {
											return _TotalArchivos;
										};
 inline const TCHAR					   *ArchivoActual(void) {
											return Archivo_Actual.Texto();
										};
private:
 void									MirarTXTClave(HKEY Root, TCHAR *Key, TCHAR *Nombre, TCHAR *Resultado, DWORD ResTam);
 unsigned int						   _TotalArchivos;
 bool								   _EjecutarExe;
 DWL::Archivos::DWLArchivoBinario    	Exe;
 DWL::DWLString							Archivo_Actual;
 DWL::DWLString							DPath;
 DWL::DWLString							Ejecutable;
 DWL::DWLString							PathDestino;
};
