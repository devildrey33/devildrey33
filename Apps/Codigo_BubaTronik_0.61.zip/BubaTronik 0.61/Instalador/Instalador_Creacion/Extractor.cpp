#include "stdafx.h"
#include <shellapi.h>      // Para usar Shell execute
#include ".\extractor.h"
#include "..\zlib\zlib.h"


Extractor::Extractor(void) {
//	DWL::Archivos::DWLArchivoBinarioWin Destino;
//	Descomprimir("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 100, Destino);


	_TotalArchivos = 0;
	_EjecutarExe = false;
	
	TCHAR         Tmp[256];                                                                                          // String temporal
	int           Confirmacion = 0;
	unsigned long TamExe;
	DWL::DWLString  TmpStr;
	// Obtengo el path actual
	TCHAR PathApp[1024];
	DWORD Size = GetModuleFileName(NULL, PathApp, 1024);
	for (Size; Size > 0; Size --) {
		if (PathApp[Size] == TCHAR('\\')) {
			break;
		}
	}
	PathApp[Size + 1] = 0;

	TCHAR Buffer[MAX_PATH] = TEXT("");
	GetModuleFileName(NULL, Buffer, MAX_PATH);
	DPath = Buffer;
//	if (DPath[DPath.Tam() -1] != TEXT('\\')) DPath += TEXT("\\");
/*	DPath = PathApp; 

	// Abro este archivo para lectura
	DPath += TEXT("Instalar.exe");*/
	if (Exe.AbrirArchivoLectura(DPath.Texto()) == false) {
		#ifndef _DEBUG
			MessageBox(NULL, TEXT("Error grave"), TEXT("Error!"), MB_OK);
			MessageBox(NULL, DPath(), TEXT("Error!"), MB_OK);
			PostQuitMessage(0);
		#endif
		return;
	}

	Exe.Posicion(-4, true);
	Exe.LeerInt(Confirmacion);

	if (Confirmacion != 3333) { 
		#ifndef UNICODE
			#if _MSC_VER == 1200
				sprintf(Tmp, TEXT("Error (%d)"), Confirmacion);
			#else
				sprintf_s(Tmp, 256, TEXT("Error (%d)"), Confirmacion);
			#endif
		#else
			#if _MSC_VER == 1200
				swprintf(Tmp, TEXT("Error (%d)"), Confirmacion);
			#else
				swprintf_s(Tmp, 256, TEXT("Error (%d)"), Confirmacion);
			#endif
		#endif
		#ifndef _DEBUG
			MessageBox(NULL, TEXT("Instalador vacio o defectuoso!!"), Tmp, MB_OK);
			PostQuitMessage(0);
		#endif
		return;					// Aborto la ejecucion
	}

	// Obtengo el tama�o real de Instalar.exe
	// Y preparo la siguiente posicion de lectura
	Exe.Posicion(-8, true);
	Exe.LeerUnsignedLong(TamExe);
	Exe.Posicion(TamExe, false);

	// Miro el directorio predefinido de la instalacion
	int DirDef = 1;
	Exe.LeerInt(DirDef);
	switch (DirDef) {                                                                                                     // Miro el directorio predeterminado
		case 0 :                                                                                                        // C: 
			DPath = TEXT("C:");                                                                                                  // Asigno "C:" al path
			break;                                                                                                         // Salgo del cae
		case 1 :                                                                                                        // ?:\Archivos de programa
			MirarTXTClave(HKEY_LOCAL_MACHINE, TEXT("SOFTWARE\\Microsoft\\Windows\\CurrentVersion"), TEXT("ProgramFilesDir"), Tmp, 256); // Obtengo la clave del registro
			DPath = Tmp;                                                                                                   // Asigno el directorio a la var DPath
			break;                                                                                                         // Salgo del case
		case 2 :                                                                                                        // ?:\Windows
			GetWindowsDirectory(Tmp, 256);                                                                                 // Obtngo el directorio de windows
			DPath = Tmp;                                                                                                   // Asigno el path a la varn DPath
			break;                                                                                                         // Salgo del case
	}                                                                                                                //   
	
	// Leo el trozo que falta del path
	Exe.LeerString(TmpStr);
	DPath += TmpStr;

//	DWL::DWLString TmpStr2(TmpStr(), DirDef, TEXT(" "), TamExe);
//	MessageBox(NULL, TmpStr2(), TEXT("PathDestino"), MB_OK);
}


Extractor::~Extractor(void) {
}


const unsigned int Extractor::ExtraerDatos(const TCHAR *PathDestinoFinal) {
    unsigned int	TotalDirs = 0;
	DWL::DWLString	Tmp;
	DWL::DWLString	TmpFinal;
	size_t TamPFinal = DWLStrLen(PathDestinoFinal);
	if (PathDestinoFinal[TamPFinal -1] == TEXT('"'))	PathDestino.AgregarTexto(PathDestinoFinal, TamPFinal - 1);
	else												PathDestino = PathDestinoFinal;
	//if (PathDestino[PathDestino.Tam() -1] == TEXT('\\')) PathDestino.resize(PathDestino.Tam() -1);
//		MessageBox(NULL, PathDestino(), PathDestino(), MB_OK);
	
	// Leo el total de directorios a crear y los creo
	CreateDirectory(PathDestino.Texto(), NULL);
	Exe.LeerUnsignedInt(TotalDirs);
	for (; TotalDirs > 0; TotalDirs --) {
		Exe.LeerString(Tmp);
		TmpFinal = PathDestino; TmpFinal += Tmp;
		CreateDirectory(TmpFinal.Texto(), NULL);
	}
	
	// Miro si hay que ejecutar algo al final de la instalacion
	Exe.LeerBool(_EjecutarExe);
	if (_EjecutarExe == true) {
		Exe.LeerString(Ejecutable);
	}



	// Obtengo el total de archivos a extraer
//	unsigned int TotalArchivos = 0;
	Exe.LeerUnsignedInt(_TotalArchivos);
	return _TotalArchivos;
}

const bool Extractor::EjecutarArchivo(void) {
	DWL::DWLString PathExe = PathDestino;
	if (_EjecutarExe == true) {
		unsigned int i;
		PathExe += Ejecutable;
//		MessageBox(NULL, PathExe.Texto(), TEXT("Ejecutando"), MB_OK);
		for (i = PathExe.Tam() -1; i > 0; i--) if (PathExe[i] == TEXT('\\')) break;
		ShellExecute(NULL, TEXT("open"), PathExe.Texto(), NULL, PathExe.SubStr(0, i).Texto(), SW_SHOW); // Ejecuto el ejecutable
	}
//	else {
//		MessageBox(NULL, TEXT("Instalacion terminada"), TEXT("Fin"), MB_OK);
//	}
	return _EjecutarExe;
}



const bool Extractor::ExtraerArchivo(void) {
	if (_TotalArchivos > 0) {
		DWL::Archivos::DWLArchivoBinario	Destino;
		char		   *Archivo;
		size_t		    TamArchivo = 0;
		//DWLStdString		Tmp;
		DWL::DWLString		TmpFinal;
		Exe.LeerString(Archivo_Actual);
		TmpFinal = PathDestino; 
		TmpFinal += Archivo_Actual;
//		if (PathDestino[PathDestino.Tam() - 1] == TEXT('"'))	TmpFinal = PathDestino; 
//		else													TmpFinal = PathDestino.SubStr(0, PathDestino.Tam() - 1); 
//		if (Archivo_Actual[0] == TEXT('"')) TmpFinal += Archivo_Actual.SubStr(1, -1);
//		else								TmpFinal += Archivo_Actual;

//		TmpFinal += Archivo_Actual;

//		MessageBox(NULL, Archivo_Actual(), PathDestino(), MB_OK);
//		MessageBox(NULL, TmpFinal(), TmpFinal(), MB_OK);

		Destino.AbrirArchivo(TmpFinal.Texto(), true);
		Exe.LeerSizeT(TamArchivo);
		Archivo = new char[TamArchivo];
		Exe.Leer(Archivo, TamArchivo);

		if (Destino.EstaAbierto() == true) {
			//Destino.Guardar(Archivo, TamArchivo);
			Descomprimir(Archivo, TamArchivo, Destino);
		}
		else {
			TCHAR Tmp[512];
			#ifndef UNICODE
				#if _MSC_VER == 1200
					sprintf(Tmp, TEXT("Error escribiendo el archivo '%s'\nEste archivo esta siendo usado por otro proceso."), TmpFinal.Texto());
				#else
					sprintf_s(Tmp, 512, TEXT("Error escribiendo el archivo '%s'\nEste archivo esta siendo usado por otro proceso."), TmpFinal.Texto());
				#endif
			#else
				#if _MSC_VER == 1200
					swprintf(Tmp, TEXT("Error escribiendo el archivo '%s'\nEste archivo esta siendo usado por otro proceso."), TmpFinal.Texto());
				#else
					swprintf_s(Tmp, 512, TEXT("Error escribiendo el archivo '%s'\nEste archivo esta siendo usado por otro proceso."), TmpFinal.Texto());
				#endif
			#endif
			MessageBox(NULL, Tmp, TEXT("Error"), MB_ICONEXCLAMATION);
		}
		Destino.CerrarArchivo();
		delete Archivo;

		_TotalArchivos --;
		return true;
	}
	else {
		return false;
	}
}


void Extractor::MirarTXTClave(HKEY Root, TCHAR *Key, TCHAR *Nombre, TCHAR *Resultado, DWORD ResTam) { // Funcion para mirar una clave del registro
	HKEY                hParentKey;                                                                     // Clave a abrir
	RegOpenKeyEx(Root, Key, 0, KEY_READ, &hParentKey);                                                  // Abro la clave
	RegQueryValueEx(hParentKey, Nombre, 0, NULL, (BYTE *)Resultado , &ResTam);                          // Obtengo el valor de la clave
	RegCloseKey(hParentKey);                                                                            // Cierro la clave
}                                                                                                    //  

#define CHUNK 16384
//#define CHUNK 32

const int Extractor::Descomprimir(const char *ArchivoOrigen, const size_t TamArchivoOrigen, DWL::Archivos::DWLArchivoBinario &Destino) {
    int ret;
    unsigned have;
    z_stream strm;
    char in[CHUNK] = "";
    char out[CHUNK] = "";

	unsigned int Posicion = 0;

    /* allocate inflate state */
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    strm.avail_in = 0;
    strm.next_in = Z_NULL;
    ret = inflateInit(&strm);
    if (ret != Z_OK) return ret;

    /* decompress until deflate stream ends or end of file */
    do {
		if (Posicion + CHUNK < TamArchivoOrigen)	{
			memcpy(in, &ArchivoOrigen[Posicion], CHUNK);
			strm.avail_in = CHUNK;
		}
		else {
			memcpy(in, &ArchivoOrigen[Posicion], TamArchivoOrigen - Posicion);
			strm.avail_in = TamArchivoOrigen - Posicion;
		}
		Posicion += CHUNK;
//		strcpy(In, ArchivoOrigen);

/*        strm.avail_in = fread(in, 1, CHUNK, source);
        if (ferror(source)) {
            (void)inflateEnd(&strm);
            return Z_ERRNO;
        }*/
        if (strm.avail_in == 0)
            break;
        strm.next_in = reinterpret_cast<Bytef *>(&in[0]);

        /* run inflate() on input until output buffer not full */
        do {
            strm.avail_out = CHUNK;
            strm.next_out = reinterpret_cast<Bytef *>(&out[0]);
            ret = inflate(&strm, Z_NO_FLUSH);
//            assert(ret != Z_STREAM_ERROR);  /* state not clobbered */
            switch (ret) {
            case Z_NEED_DICT:
                ret = Z_DATA_ERROR;     /* and fall through */
            case Z_DATA_ERROR:
            case Z_MEM_ERROR:
                (void)inflateEnd(&strm);
                return ret;
            }
            have = CHUNK - strm.avail_out;
			Destino.Guardar(out, have);
//            if (fwrite(out, 1, have, dest) != have || ferror(dest)) {
  //              (void)inflateEnd(&strm);
    //            return Z_ERRNO;
      //      }
        } while (strm.avail_out == 0);

        /* done when inflate() says it's done */
    } while (ret != Z_STREAM_END);

    /* clean up and return */
    (void)inflateEnd(&strm);
    return ret == Z_STREAM_END ? Z_OK : Z_DATA_ERROR;
}