#pragma once

#include "..\Instalador_Creacion\Extractor.h"
#include <DWLDialogo.h>
#include <DWLEditBox.h>

class VentanaMain2 : public DWL::Ventanas::DWLDialogo {															//
public:																											// Funciones y variables publicas
							VentanaMain2(void);																	// Constructor
				           ~VentanaMain2(void);																	// Destructor
 void						Crear(void);																		// Funcion para crear el dialogo
 void						Evento_Comando(const int ID, const int NotifyCode, HWND hWndControl);				// Funcion para obtener las notificaciones de los botones
 BOOL						Evento_Cerrar(void);																// Funcion para cerrar el dialogo
 void						EditBox_Evento_Teclado_Intro(const int IDEditBox);
private :																										// Funciones y variables privadas
 void						MirarTXTClave(HKEY Root, char *Key, char *Nombre, char *Resultado, DWORD ResTam);	// Funcion para obtener un valor del registro
 DWL::Controles::DWLEditBox Edit;
 Extractor					Ex;
 BOOL CALLBACK				GestorMensajes(UINT uMsg, WPARAM wParam, LPARAM lParam);							// Esqueleto del dialogo
};																												//
