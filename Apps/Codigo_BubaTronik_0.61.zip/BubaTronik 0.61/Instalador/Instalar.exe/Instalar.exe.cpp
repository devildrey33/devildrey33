// Instalar.exe.cpp: define el punto de entrada de la aplicaci�n.
//

#include "stdafx.h"
#include "VentanaMain2.h"

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	VentanaMain2 FM;
	MSG                  Message;                                                                      // Mensaje
	FM.Crear();                                                                                        // Creo el Dialogo
	while(TRUE == GetMessage(&Message, 0, 0, 0)) {                                                     //  Mientras la aplicacion retorne mensajes
		TranslateMessage(&Message);                                                                    //  Traduzco mensaje virtual
		DispatchMessage(&Message);                                                                     //  Paso el mensaje a su WindowProcedure
	}                                                                                                  //  
	return 0;                                                                                          // Retorno 0
}

