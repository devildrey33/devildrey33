#include "stdafx.h"        // Encabezado precompilado
#include "VentanaMain2.h"  // Esta clase
#include "resource.h"      // Recursos


BOOL CALLBACK VentanaMain2::GestorMensajes(UINT uMsg, WPARAM wParam, LPARAM lParam) {
	switch (uMsg) {
		ENLACE_Evento_Comando();
		ENLACE_Evento_Cerrar();
	}
	return DWL::Ventanas::DWLDialogo::GestorMensajes(uMsg, wParam, lParam);
};


VentanaMain2::VentanaMain2(void) {	// Constructor
}									//


VentanaMain2::~VentanaMain2(void) { // Destructor
}									// 


void VentanaMain2::Crear(void) {

	// Creo el dialogo
	CrearDialogo(IDD_DIALOG1, 100, 100);                                                                             // Creo este dialogo
	Edit.Asignar(_hWnd, IDC_EDIT1);
	
	Edit.AsignarTexto(Ex.PathDestinoDefecto());
	Edit.PosicionCursor(DWLStrLen(Ex.PathDestinoDefecto()));
	Visible(true);
}

void VentanaMain2::EditBox_Evento_Teclado_Intro(const int IDEditBox) {
	Evento_Comando(IDC_BUTTON1, NULL, NULL);
}


void VentanaMain2::Evento_Comando(const int ID, const int NotifyCode, HWND hWndControl) {	//
	switch (ID) {																			// 
		case IDC_BUTTON1 : /////////////////////////////////////////////////////////////////// Instalar
			TCHAR Txt[512];
			Edit.ObtenerTexto(Txt, 512);
			Ex.ExtraerDatos(Txt);													// Obtengo los datos necesarios para empezar a extraer los archivos
			while(Ex.ExtraerArchivo() == true) { 
				SetWindowText(_hWnd, Ex.ArchivoActual());
			};											// Extraigo todos los archivos
			MessageBox(_hWnd, TEXT("Instalacion terminada con exito!!"), TEXT("Instalacion terminada"), MB_OK);
			Ex.EjecutarArchivo();
			Evento_Cerrar();																// Termino la aplicacion
			break;                                                                          // Salgo del case
		case IDC_BUTTON2 : /////////////////////////////////////////////////////////////////// Salir
			Evento_Cerrar();																// Termino la aplicacion
			break;                                                                          // Salgo del case
	}																						//
}																							//



BOOL VentanaMain2::Evento_Cerrar(void) { //
	PostQuitMessage(0);					// Termino la aplicacion
	return 0;							// Retorno 0
}										//




