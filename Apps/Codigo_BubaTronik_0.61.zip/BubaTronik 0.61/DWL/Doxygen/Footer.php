

<address style="text-align: right;"><small>Generado el $date para www.devildrey33.es por&nbsp;
<a href="http://www.doxygen.org/index.html">
<img class="footer" src="doxygen.png" alt="doxygen"/></a> 1.6.1 </small></address>

<?php 
// Genero la parte inferior de la tabla que hace de pagina
Generar_TablaPagina_Fin(); 
// Genero la cabecera inferior con los datos de contacto
Generar_ContraCabecera();
?>
