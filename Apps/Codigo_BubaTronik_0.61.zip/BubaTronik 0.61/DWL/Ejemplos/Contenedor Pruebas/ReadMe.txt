﻿========================================================================
    APLICACIÓN DE WIN32: Contenedor Pruebas Información general del 
    proyecto
========================================================================

AppWizard ha creado esta aplicación Contenedor Pruebas.

Este archivo contiene un resumen de lo que encontrará en todos los 
archivos que componen la Contenedor Pruebas aplicación.


Contenedor Pruebas.vcproj
    Éste es el archivo de proyecto principal para los proyectos de VC++ 
    generados mediante un Asistente para aplicaciones.
    Contiene información acerca de la versión de Visual C++ que generó 
    el archivo e información acerca de las plataformas, configuraciones 
    y características del proyecto seleccionadas con el Asistente para 
    aplicaciones.

Contenedor Pruebas.cpp
    Ésta es la aplicación principal del archivo de código fuente.

/////////////////////////////////////////////////////////////////////////////
AppWizard ha creado los siguientes recursos:

Contenedor Pruebas.rc
    Ésta es una lista de todos los recursos de Microsoft Windows que
    utiliza el programa.  Incluye los iconos, mapas de bits y cursores 
    almacenados en el subdirectorio RES.  Este archivo puede editarse 
    directamente en Microsoft Visual C++.

Resource.h
    Éste es el archivo de encabezado estándar, que define nuevos 
    identificadores de recurso.
    Microsoft Visual C++ lee y actualiza este archivo.

Contenedor Pruebas.ico
    Éste es un archivo de icono, que se utiliza como el icono de la 
    aplicación (32x32).
    Este icono está incluido en el archivo principal de recursos 
    Contenedor Pruebas.rc.

small.ico
    Este es un archivo de icono, que contiene una versión menor (16x16)
    del icono de la aplicación. Este icono está incluido en el archivo 
    de recursos principal Contenedor Pruebas.rc.

/////////////////////////////////////////////////////////////////////////////
Otros archivos estándar:

StdAfx.h, StdAfx.cpp
    Estos archivos se utilizan para generar un archivo de encabezado 
    precompilado (PCH) denominado Contenedor Pruebas.pch y un archivo de 
    tipos precompilados denominado StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Otras notas:

AppWizard usa comentarios "TODO:" para indicar las partes del código fuente 
que debería agregar o personalizar.

/////////////////////////////////////////////////////////////////////////////
