#include "StdAfx.h"
#include "Ventana.h"
#include "AntivirusApp.h"
#include <tlhelp32.h>	// Tool Help Functions
#include <DWLDebug.h>
#include <vector>

#define CLAVE_REGISTRO_VIRUS      TEXT("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run")
#define CLAVE_REGISTRO_VIRUS64    TEXT("SOFTWARE\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Run")

#define ID_BOTON_ELIMINAR 100
#define ID_EVENTOS_LISTA  101

Ventana::Ventana(void) {
}

Ventana::~Ventana(void) {
}


const bool Ventana::BuscarArchivo(DWL::DWLString &Path, const TCHAR *NombreDefecto) {
    TCHAR WinDir[MAX_PATH];
    GetWindowsDirectory(WinDir, MAX_PATH);

    HANDLE Archivo;
    // Miro por el WINROOT
    Path.sprintf(TEXT("%c:\\CMOS\\%s"), WinDir[0], NombreDefecto);
    Archivo = CreateFile(Path(), FILE_READ_DATA, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (Archivo != INVALID_HANDLE_VALUE) {
        CloseHandle(Archivo);
        return true;
    }
    // Miro por la C:
    Path.sprintf(TEXT("C:\\CMOS\\%s"), NombreDefecto);
    Archivo = CreateFile(Path(), FILE_READ_DATA, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (Archivo != INVALID_HANDLE_VALUE) {
        CloseHandle(Archivo);
        return true;
    }
    return false;
}

//   HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Run o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run
//   claves : xlb, xln, xlr, xlr2
const bool Ventana::BuscarVirus(void) {
    DWL::DWLString TmpTxt;
    bool Ret = false;

    // Busco en el registro entradas del virus
    Sistema.Registro.ObtenerValor_String(HKEY_LOCAL_MACHINE, CLAVE_REGISTRO_VIRUS, TEXT("xlb"), Path_xlb);
    if (Path_xlb.Tam() > 0) {
        VirusEventos_Lista.AgregarItem(NULL, 0, DWL_LISTAEX_FIN, TEXT("Encontrado 'xlb.cpl' en el registro : (HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run)"));
        VirusEventos_Lista.Item(VirusEventos_Lista.TotalItems() -1)->SubItem(0)->Colores()->TextoNormal = RGB(255,0,0);
        VirusEventos_Lista.Item(VirusEventos_Lista.TotalItems() -1)->SubItem(0)->Colores()->TextoResaltado = RGB(255,50,50);
        Ret = true;
    }
    Sistema.Registro.ObtenerValor_String(HKEY_LOCAL_MACHINE, CLAVE_REGISTRO_VIRUS, TEXT("xln"), Path_xln);
    if (Path_xln.Tam() > 0) {
        VirusEventos_Lista.AgregarItem(NULL, 0, DWL_LISTAEX_FIN, TEXT("Encontrado 'xlb.cpl' en el registro : (HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run)"));
        VirusEventos_Lista.Item(VirusEventos_Lista.TotalItems() -1)->SubItem(0)->Colores()->TextoNormal = RGB(255,0,0);
        VirusEventos_Lista.Item(VirusEventos_Lista.TotalItems() -1)->SubItem(0)->Colores()->TextoResaltado = RGB(255,50,50);
        Ret = true;
    }
    Sistema.Registro.ObtenerValor_String(HKEY_LOCAL_MACHINE, CLAVE_REGISTRO_VIRUS, TEXT("xlr"), Path_xlr);
    if (Path_xlr.Tam() > 0) {
        VirusEventos_Lista.AgregarItem(NULL, 0, DWL_LISTAEX_FIN, TEXT("Encontrado 'xlr.exe' en el registro : (HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run)"));
        VirusEventos_Lista.Item(VirusEventos_Lista.TotalItems() -1)->SubItem(0)->Colores()->TextoNormal = RGB(255,0,0);
        VirusEventos_Lista.Item(VirusEventos_Lista.TotalItems() -1)->SubItem(0)->Colores()->TextoResaltado = RGB(255,50,50);
        Ret = true;
    }
    Sistema.Registro.ObtenerValor_String(HKEY_LOCAL_MACHINE, CLAVE_REGISTRO_VIRUS, TEXT("xlr2"), Path_xlr2);
    if (Path_xlr2.Tam() > 0) {
        VirusEventos_Lista.AgregarItem(NULL, 0, DWL_LISTAEX_FIN, TEXT("Encontrado 'xlr2.exe' en el registro : (HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run)"));
        VirusEventos_Lista.Item(VirusEventos_Lista.TotalItems() -1)->SubItem(0)->Colores()->TextoNormal = RGB(255,0,0);
        VirusEventos_Lista.Item(VirusEventos_Lista.TotalItems() -1)->SubItem(0)->Colores()->TextoResaltado = RGB(255,50,50);
        Ret = true;
    }

    // Buscar archivos en C:\ y en el disco que tenga el windows instalado
    if (BuscarArchivo(Path_xlb, TEXT("xlb.cpl")) == true)  {
        TmpTxt.sprintf(TEXT("Encontrado archivo : (%s)"), Path_xlb());
        AgregarTextoRojo(TmpTxt());
        Ret = true;
    }
    if (BuscarArchivo(Path_xln, TEXT("xln.cpl")) == true) {
        TmpTxt.sprintf(TEXT("Encontrado archivo : (%s)"), Path_xln());
        AgregarTextoRojo(TmpTxt());
        Ret = true;
    }
    if (BuscarArchivo(Path_xlr, TEXT("xlr.exe")) == true) {
        TmpTxt.sprintf(TEXT("Encontrado archivo : (%s)"), Path_xlr());
        AgregarTextoRojo(TmpTxt());
        Ret = true;
    }
    if (BuscarArchivo(Path_xlr2, TEXT("xlr2.exe")) == true) {
        TmpTxt.sprintf(TEXT("Encontrado archivo : (%s)"), Path_xlr2());
        AgregarTextoRojo(TmpTxt());
        Ret = true;
    }
    if (BuscarArchivo(Path_id, TEXT("id")) == true) {
        TmpTxt.sprintf(TEXT("Encontrado archivo : (%s)"), Path_id());
        AgregarTextoRojo(TmpTxt());
        Ret = true;
    }

    return Ret;
}


void Ventana::AgregarTextoRojo(const TCHAR *nTxt) {
    VirusEventos_Lista.AgregarItem(NULL, 0, DWL_LISTAEX_FIN, nTxt);
    VirusEventos_Lista.Item(VirusEventos_Lista.TotalItems() -1)->SubItem(0)->Colores()->TextoNormal = RGB(255,0,0);
    VirusEventos_Lista.Item(VirusEventos_Lista.TotalItems() -1)->SubItem(0)->Colores()->TextoResaltado = RGB(255,50,50);
	VirusEventos_Lista.ActualizarTodo();
};


void Ventana::AgregarTextoVerde(const TCHAR *nTxt) { 
    VirusEventos_Lista.AgregarItem(NULL, 0, DWL_LISTAEX_FIN, nTxt);
    VirusEventos_Lista.Item(VirusEventos_Lista.TotalItems() -1)->SubItem(0)->Colores()->TextoNormal = RGB(0,160,0);
    VirusEventos_Lista.Item(VirusEventos_Lista.TotalItems() -1)->SubItem(0)->Colores()->TextoResaltado = RGB(50,160,50);
    VirusEventos_Lista.ActualizarTodo();
};


void Ventana::AgregarTextoNegro(const TCHAR *nTxt) { 
    VirusEventos_Lista.AgregarItem(NULL, 0, DWL_LISTAEX_FIN, nTxt);
    VirusEventos_Lista.ActualizarTodo();
};


void Ventana::Crear(void) {
    bool VirusEncontrado = BuscarVirus();
    CrearVentana(NULL, TEXT("Antivirus_Fotos-05-06"), WS_OVERLAPPEDWINDOW | WS_VISIBLE, TEXT("Antivirus Fotos (05/06)    [www.devildrey33.es]"), 100, 100, 700, 400, NULL);
    Maximizable(false);

    VirusEventos_Lista.CrearListaEx(WS_CHILD | WS_VISIBLE, _hWnd, 10, 10, 660, 300, ID_EVENTOS_LISTA);
    VirusEventos_Lista.AgregarColumna(635);
    VirusEventos_Lista.MostrarIconos(false);
    VirusEliminar_Boton.CrearBotonEx(WS_CHILD | WS_VISIBLE, _hWnd, TEXT("Eliminar virus"), 280, 320, 100, 18, ID_BOTON_ELIMINAR);

    if (VirusEncontrado == false) {
        VirusEliminar_Boton.Activado(false);
        MessageBox(_hWnd, TEXT("No se ha encontrado el virus Fotos (05/06)..."), TEXT("No se ha encontrado el virus."), MB_OK);
    }

}


LRESULT Ventana::Evento_Cerrar(void) {
    PostQuitMessage(0);
    return 0;
}


LRESULT Ventana::Evento_BotonEx_Mouse_Click(const UINT Boton, const int cX, const int cY, const UINT IDBotonEx, const UINT Param) {
    bool Borrado = true;
    if (IDBotonEx == ID_BOTON_ELIMINAR) {
        UINT Veces       = 0;
        UINT Encontrados = 0;
        // Intento eliminar los procesos 10 veces
        do {
            Encontrados = VirusEliminar_Procesos();
            Sleep(100);
            Veces ++;
            if (Veces == 10) {
                Borrado = false;
                MessageBox(_hWnd, TEXT("No se ha podidio eliminar los procesos, pero se han eliminado las entradas del registro. Debes reiniciar y volver a ejecutar este antivirus para quitar completamente el virus."), TEXT("Error"), MB_OK);
                break;
            }
        } while (Encontrados > 0);
        VirusEliminar_EntradasRegistro();
        VirusEliminar_Archivos();
        
        if (Borrado == false) {
            AgregarTextoRojo(TEXT("El virus no se ha borrado completamente"));
            AgregarTextoNegro(TEXT("Debes reiniciar el sistema y volver a pasar este parche."));
        }
        else {
            AgregarTextoVerde(TEXT("Virus eliminado correctamente."));
        }
        VirusEventos_Lista.Item(VirusEventos_Lista.TotalItems() -1)->HacerVisible();
        VirusEliminar_Boton.Activado(false);
    }
    return 0;
}


const UINT Ventana::VirusEliminar_Procesos(void) {
	HANDLE         hSnapShot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    HANDLE         Proceso;
	BOOL           bResult   = FALSE;
    BOOL           bResultM  = FALSE;
    UINT           Contador  = 0;

    DWL::DWLString TmpTxt;

    HANDLE hModuleSnap = INVALID_HANDLE_VALUE;
    MODULEENTRY32 me32;
    me32.dwSize = sizeof( MODULEENTRY32 );

//    TerminateProcess(

	PROCESSENTRY32 pe;
	pe.dwSize = sizeof(pe);
	bResult = Process32First(hSnapShot, &pe);
	while (bResult != NULL) {
        if (DWLStrCmpi(pe.szExeFile, TEXT("rundll32.exe")) == 0) {
            hModuleSnap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, pe.th32ProcessID);
            bResultM = Module32First(hModuleSnap, &me32);
            while (bResultM != NULL) {
                if (DWLStrCmpi(me32.szModule, TEXT("xlb.cpl")) == 0 || DWLStrCmpi(me32.szModule, TEXT("xln.cpl")) == 0) {
                    Proceso = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pe.th32ProcessID);
                    TerminateProcess(Proceso, 0);
                    CloseHandle(Proceso);
                    Contador ++;
                    TmpTxt.sprintf(TEXT("Terminando proceso %s %s...."), pe.szExeFile, me32.szExePath);
                    VirusEventos_Lista.AgregarItem(NULL, 0, DWL_LISTAEX_FIN, TmpTxt());

                }
                bResultM = Module32Next(hModuleSnap, &me32);
            }
            CloseHandle(hModuleSnap);
        }

        if (DWLStrCmpi(pe.szExeFile, TEXT("xlr.exe")) == 0 || DWLStrCmpi(pe.szExeFile, TEXT("xlr2.exe")) == 0) {
            Proceso = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pe.th32ProcessID);
            TerminateProcess(Proceso, 0);
            CloseHandle(Proceso);
            Contador ++;
            TmpTxt.sprintf(TEXT("Terminando proceso %s...."), pe.szExeFile);
            AgregarTextoNegro(TmpTxt());
        }


		bResult = Process32Next(hSnapShot, &pe);
	}
    VirusEventos_Lista.ActualizarTodo();
	CloseHandle(hSnapShot);		// Destruir snapshot
    return Contador;
}


void Ventana::VirusEliminar_EntradasRegistro(void) {
    LONG R = Sistema.Registro.EliminarValor(HKEY_LOCAL_MACHINE, CLAVE_REGISTRO_VIRUS, TEXT("xlb"));
    AgregarTextoNegro(TEXT("Eliminando 'xlb.cpl' del registro : HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run"));

    R = Sistema.Registro.EliminarValor(HKEY_LOCAL_MACHINE, CLAVE_REGISTRO_VIRUS, TEXT("xln"));
    AgregarTextoNegro(TEXT("Eliminando 'xln.cpl' del registro : HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run"));

    R = Sistema.Registro.EliminarValor(HKEY_LOCAL_MACHINE, CLAVE_REGISTRO_VIRUS, TEXT("xlr"));
    AgregarTextoNegro(TEXT("Eliminando 'xlr.cpl' del registro : HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run"));

    R = Sistema.Registro.EliminarValor(HKEY_LOCAL_MACHINE, CLAVE_REGISTRO_VIRUS, TEXT("xlr2"));
    AgregarTextoNegro(TEXT("Eliminando 'xlr2.cpl' del registro : HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run"));

    VirusEventos_Lista.ActualizarTodo();
}


void Ventana::VirusEliminar_Archivos(void) {
    VirusEliminar_Archivo(Path_id);
    VirusEliminar_Archivo(Path_xlb);
    VirusEliminar_Archivo(Path_xln);
    VirusEliminar_Archivo(Path_xlr);
    VirusEliminar_Archivo(Path_xlr2);


    EliminarDirectorio(TEXT("cmos"));
    EliminarDirectorio(TEXT("datagyn"));
}


void Ventana::EliminarDirectorio(const TCHAR *PathDefecto) {
	LPVOID          lpMsgBuf;
    TCHAR           WinDir[MAX_PATH];
    DWL::DWLString  TmpTxt;
    DWL::DWLString  PDir;
    GetWindowsDirectory(WinDir, MAX_PATH);

    PDir.sprintf(TEXT("%c:\\%s\\"), WinDir[0], PathDefecto);
    if (GetShortPathName(PDir(), WinDir, MAX_PATH) != 0) { // El directorio WINROOT\PathDefecto existe
        if (RemoveDirectory(PDir()) == TRUE) {
            TmpTxt.sprintf(TEXT("Eliminado el directorio : %s"), PDir());
            AgregarTextoNegro(TmpTxt());
        }
        else {
    	    FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR) &lpMsgBuf, 0, NULL);
            TmpTxt.sprintf(TEXT("Error eliminando el directorio : %s -> %s"), PDir(), lpMsgBuf);
		    LocalFree(lpMsgBuf);
            AgregarTextoRojo(TmpTxt());
        }
    }
    
    PDir.sprintf(TEXT("C:\\%s"), PathDefecto);
    if (GetShortPathName(PDir(), WinDir, MAX_PATH) != 0) { // El directorio C:\PathDefecto existe
        if (RemoveDirectory(PDir()) == TRUE) {
            TmpTxt.sprintf(TEXT("Eliminado el directorio : %s"), PDir());
            AgregarTextoNegro(TmpTxt());
        }
        else {
    	    FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR) &lpMsgBuf, 0, NULL);
            TmpTxt.sprintf(TEXT("Error eliminando el directorio : %s -> %s"), PDir(), lpMsgBuf);
		    LocalFree(lpMsgBuf);
            AgregarTextoRojo(TmpTxt());
        }
    }
}


void Ventana::VirusEliminar_Archivo(DWL::DWLString &Archi) {
    LPVOID lpMsgBuf;
    DWL::DWLString TmpTxt;
    if (Archi.Tam() > 0) {
        if (DeleteFile(Archi()) == TRUE) {
            TmpTxt.sprintf(TEXT("Eliminado el archivo : %s"), Archi());
            VirusEventos_Lista.AgregarItem(NULL, 0, DWL_LISTAEX_FIN, TmpTxt());
        }
        else {
	    	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR) &lpMsgBuf, 0, NULL);
            TmpTxt.sprintf(TEXT("Error eliminando el archivo : %s -> %s"), Archi(), lpMsgBuf);
    		LocalFree(lpMsgBuf);
            AgregarTextoRojo(TmpTxt());
        }
    }
}
