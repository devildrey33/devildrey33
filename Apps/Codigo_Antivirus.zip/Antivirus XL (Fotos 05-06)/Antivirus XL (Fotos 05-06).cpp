// Antivirus XL (Fotos 05-06).cpp: define el punto de entrada de la aplicaci�n.
//


//  -Buscar claves del registro del virus para saber su ubicacion
//  -Eliminar datos del registro :
//   HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Run o HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run
//   claves : xlb, xln, xlr, xlr2
//  -Eliminar programas de la memoria
//  -Eliminar carpeta cmos

#include "stdafx.h"
#include "AntivirusApp.h"
#include <Shellapi.h>

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {

	DWL::DWLString AppPath;
	// Obtengo el directorio actual de la aplicacion
	TCHAR PathApp[1024];
	DWORD Size = GetModuleFileName(NULL, PathApp, 1024);
	for (Size; Size > 0; Size --) {
		if (PathApp[Size] == TCHAR('\\')) {
			break;
		}
	}
	PathApp[Size + 1] = 0;
	AppPath = PathApp;

	int		TotalArgs	= 0;
	TCHAR **Args		= CommandLineToArgvW(GetCommandLine(), &TotalArgs);

	if (IsUserAnAdmin() == FALSE) { // si es admin
		ShellExecute(NULL, TEXT("RunAs"), Args[0], TEXT(""), AppPath(), SW_SHOWNORMAL);
		return 0;
	}
	
	DWL::DWL_Iniciar<AntivirusApp> Aplicacion;
    return Aplicacion.Ejecutar();
}




