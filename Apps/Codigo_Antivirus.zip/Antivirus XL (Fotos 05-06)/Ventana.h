#pragma once

#include <DWLVentana.h>
#include <DWLBotonEx.h>
#include <DWLListaEx.h>


class Ventana : public DWL::Ventanas::DWLVentana {
  public:
                                Ventana(void);
                               ~Ventana(void);
 void                           Crear(void);
 const bool                     BuscarVirus(void);
 const bool                     BuscarArchivo(DWL::DWLString &Path, const TCHAR *NombreDefecto);
// const bool                     ObtenerPathVirus(DWL::DWLString &Path);                           
 LRESULT                        Evento_Cerrar(void);
 LRESULT                        Evento_BotonEx_Mouse_Click(const UINT Boton, const int cX, const int cY, const UINT IDBotonEx, const UINT Param);
 
 void                           AgregarTextoRojo(const TCHAR *nTxt);
 void                           AgregarTextoVerde(const TCHAR *nTxt);
 void                           AgregarTextoNegro(const TCHAR *nTxt);

 const UINT                     VirusEliminar_Procesos(void);
 void                           VirusEliminar_EntradasRegistro(void);
 void                           VirusEliminar_Archivos(void);
 void                           VirusEliminar_Archivo(DWL::DWLString &Archi);
 void                           EliminarDirectorio(const TCHAR *PathDefecto);
 DWL::DWLString                 Path_xlb;
 DWL::DWLString                 Path_xln;
 DWL::DWLString                 Path_xlr;
 DWL::DWLString                 Path_xlr2;
 DWL::DWLString                 Path_id;

 DWL::ControlesEx::DWLBotonEx   VirusEliminar_Boton;
 DWL::ControlesEx::DWLListaEx   VirusEventos_Lista;
};
