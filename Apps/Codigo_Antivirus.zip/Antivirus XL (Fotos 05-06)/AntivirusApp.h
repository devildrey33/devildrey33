#pragma once

#include <DWLAplicacion.h>
#include "Ventana.h"

class AntivirusApp : public DWL::DWLAplicacion {
  public:
                AntivirusApp(void) { };
               ~AntivirusApp(void) { };
  const BOOL	Inicio(void) {
                    V.Crear();
                    return TRUE; 
                };
  void			Fin(void) { };
  Ventana       V;
};

DWL_Enlazar_Sistema(AntivirusApp);
