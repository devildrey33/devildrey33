// Cabecera que permite cargar el DirectX2D dinamicamente siempre que exista en el sistema, y que en caso de no existir no provocara un error critico.
// NOTA : no tengo muy claro como identificar si hay instalado el Windows7 SDK (que trae las librerias para DX11)
#ifndef DWL_D2D1_H
#define DWL_D2D1_H
 
#include "DWL.h"
#include <d2d1.h>
#include <d2d1helper.h>

#define D2DERR_LOADLIBRARY                  MAKE_D2DHR_ERR(0x0FE)
#define D2DERR_GETPROCADRESS                MAKE_D2DHR_ERR(0x0FF)


typedef HRESULT (__stdcall DWL_Tp_CreateFactory)(__in D2D1_FACTORY_TYPE factoryType, __in REFIID riid, __in_opt CONST D2D1_FACTORY_OPTIONS *pFactoryOptions, __out void **ppIFactory);

namespace D2D1 {
	template<class Interface> inline void SafeRelease(Interface **ppInterfaceToRelease) {
		if (*ppInterfaceToRelease != NULL) {
			(*ppInterfaceToRelease)->Release();
			(*ppInterfaceToRelease) = NULL;
		}
	};
};

namespace DWL {
	namespace DX {
		class DWL_D2D1 {
		  public:
												DWL_D2D1(void) : _LibD2D1(NULL), _CreateFactory(NULL) { };

											   ~DWL_D2D1(void) { 
												   if (_LibD2D1 != NULL) FreeLibrary(_LibD2D1); 
											    };

												// Esta funcion inicia la libreria D2D1 si es posible, y luego llama a D2D1CreateFactory
												// En caso de no poder cargar la libreria D2D1 devuelve D2DERR_LOADLIBRARY o D2DERR_GETPROCADRESS
											    // Si D2D1CreateFactory falla devuelve un D2DERR dependiendo del error.
			HRESULT								CreateFactory(__in D2D1_FACTORY_TYPE factoryType, __in REFIID riid, __in_opt CONST D2D1_FACTORY_OPTIONS *pFactoryOptions, __out void **ppIFactory) {
													OSVERSIONINFOEX osvi;
													ZeroMemory(&osvi, sizeof(OSVERSIONINFOEX));
													osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
													GetVersionEx((OSVERSIONINFO *)&osvi);
													// No es Windows vista o superior
													if (osvi.dwMajorVersion < 5) return D2DERR_LOADLIBRARY;
													// Es windows vista sin el SP2
													if (osvi.dwMinorVersion == 0 && osvi.wServicePackMajor < 2) return D2DERR_LOADLIBRARY;
													// No se ha cargado la Libreria dinamica
													if (_LibD2D1 == NULL) {
														_LibD2D1 = LoadLibrary(TEXT("D2D1.dll")); // HAY QUE PASARLO A RUTA COMPLETA
														if (_LibD2D1 == NULL) return D2DERR_WIN32_ERROR;
														_CreateFactory = (DWL_Tp_CreateFactory *)GetProcAddress((HMODULE)_LibD2D1, "D2D1CreateFactory");
													}
													if (_CreateFactory == NULL) return D2DERR_GETPROCADRESS;
													return (_CreateFactory)(factoryType, riid, pFactoryOptions, ppIFactory);
												}

												// Funciones resumidas de CreateFactory
			inline HRESULT						CreateFactory(__in D2D1_FACTORY_TYPE factoryType, __in REFIID riid, __out void **ppIFactory) { 
													return CreateFactory(factoryType, riid, NULL, ppIFactory); 
												};

			template <class Factory> HRESULT	CreateFactory(__in D2D1_FACTORY_TYPE factoryType, __out Factory **factory) {
													return CreateFactory(factoryType, __uuidof(Factory), reinterpret_cast<void **>(factory)); 
												};

			template <class Factory> HRESULT	CreateFactory(__in D2D1_FACTORY_TYPE factoryType, __in CONST D2D1_FACTORY_OPTIONS &factoryOptions, __out Factory **ppFactory) {
													return CreateFactory(factoryType, __uuidof(Factory), &factoryOptions, reinterpret_cast<void **>(ppFactory)); 
												};
		  private:
			DWL_Tp_CreateFactory              *_CreateFactory;
			HINSTANCE			               _LibD2D1;
		};
	};
};

#endif




