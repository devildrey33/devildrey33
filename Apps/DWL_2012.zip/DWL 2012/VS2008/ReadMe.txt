﻿========================================================================
    BIBLIOTECA ESTÁTICA: DWL 2012 Información general del 
    proyecto
========================================================================

AppWizard ha creado este proyecto de biblioteca DWL 2012.

No se crearon archivos de código fuente como parte del proyecto.


DWL 2012.vcproj
    Éste es el archivo de proyecto principal para los proyectos de VC++ 
    generados mediante un Asistente para aplicaciones.
    Contiene información acerca de la versión de Visual C++ que generó 
    el archivo e información acerca de las plataformas, configuraciones 
    y características del proyecto seleccionadas con el Asistente para 
    aplicaciones.

/////////////////////////////////////////////////////////////////////////////
Otras notas:

AppWizard usa comentarios "TODO:" para indicar las partes del código fuente 
que debería agregar o personalizar.

/////////////////////////////////////////////////////////////////////////////
