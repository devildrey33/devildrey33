#ifndef CONFIGURACIONPORDEFECTO_H
    #define CONFIGURACIONPORDEFECTO_H

    
    #include <SDKDDKVer.h> // Cabecera que indica que se utilizara la ultima plataforma disponible bajo VisualStudio 2010
/*        #ifndef WINVER                      // Especifica que la plataforma m�nima requerida es Windows XP.
            #define WINVER 0x0501           // Cambiar al valor apropiado correspondiente a otras versiones de Windows.
        #endif
        #ifndef _WIN32_WINNT                // Especifica que la plataforma m�nima requerida es Windows XP.
            #define _WIN32_WINNT 0x0501     // Cambiar al valor apropiado correspondiente a otras versiones de Windows.
        #endif
        #ifndef _WIN32_WINDOWS              // Especifica que la plataforma m�nima requerida es Windows XP.
            #define _WIN32_WINDOWS 0x0500   // Cambiar al valor apropiado correspondiente a Windows Me o posterior.
        #endif
        #ifndef _WIN32_IE                   // Especifica que la plataforma m�nima requerida es Internet Explorer 6.0.
            #define _WIN32_IE 0x0600        // Cambiar al valor apropiado correspondiente a otras versiones de IE.
        #endif*/

    // Estilo visual XP+
    #pragma comment(linker, "/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")

#endif