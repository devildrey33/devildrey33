#include "DDialogoDirectorios.h"
#include <shlobj.h>             // Libreria para los objetos Shell

//! Espacio de nombres DWL
namespace DWL {

	// DEPRECATED!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	//! Funci�n que muestra el dialogo del sistema para seleccionar un directorio.
	/*!	Esta funci�n muestra el dialogo del sistema para seleccionar un directorio.
			\fn			const TCHAR *MostrarDirectorios(const TCHAR *Titulo);
			\param[in]	Titulo : Cadena de caracteres con el titulo del dialogo
			\return		Devuelve la ruta del directorio seleccionado.
			\todo       Esta funci�n usa API DEPRECATED, hay que re-emplazarla y mantener esta funcion para VC6
	*/
	const TCHAR *DDialogoDirectorios::MostrarDirectorios(const TCHAR *Titulo) { 
		BROWSEINFO   BuskaDir = { NULL, NULL, NULL, NULL, NULL, NULL, 0L, 0 }; 
		LPITEMIDLIST ID; 
		LPITEMIDLIST IDRoot;
		LPMALLOC     lpMalloc;
		TCHAR        Directori[512] = TEXT("");
		BuskaDir.hwndOwner = NULL; 
		BuskaDir.pidlRoot = NULL;
		BuskaDir.ulFlags = NULL; 
		BuskaDir.lpszTitle = Titulo; 
		BuskaDir.lpfn = NULL;
		HRESULT Res = SHGetSpecialFolderLocation(HWND_DESKTOP, CSIDL_DRIVES, &IDRoot);
		BuskaDir.pidlRoot = IDRoot;
		ID = SHBrowseForFolder(&BuskaDir);
		if (ID != NULL) {  SHGetPathFromIDList(ID, Directori);   _Directorio = Directori; }
		else			{  _Directorio = TEXT(""); return _Directorio(); }
		if (NOERROR == SHGetMalloc(&lpMalloc) && (NULL != lpMalloc)) {
			if (NULL != IDRoot) lpMalloc->Free(IDRoot);  
			if (NULL != ID)     lpMalloc->Free(ID); 
			lpMalloc->Release();  
		}
		if (_Directorio.Tam() > 0) {
			if (_Directorio[_Directorio.Tam() -1] != '\\') _Directorio += '\\';
		}
		return _Directorio();
	};

}