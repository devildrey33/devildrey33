#ifndef DBUTTON_ESTILOS_H
    #define DBUTTON_ESTILOS_H

    #include "DBaseWnd_Estilos.h"

    namespace DWL {

        class DButton_Estilos : public DBaseWnd_Estilos {
          public:
                                DButton_Estilos(DWORD nEstilos = NULL) : DBaseWnd_Estilos(nEstilos) { 
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_3STATE"),              BS_3STATE));            // 0x00000005L     
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_AUTO3STATE"),          BS_AUTO3STATE));        // 0x00000006L 
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_AUTOCHECKBOX"),        BS_AUTOCHECKBOX));      // 0x00000003L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_AUTORADIOBUTTON"),     BS_AUTORADIOBUTTON));   // 0x00000009L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_CHECKBOX"),            BS_CHECKBOX));          // 0x00000002L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_DEFPUSHBUTTON"),       BS_DEFPUSHBUTTON));     // 0x00000001L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_GROUPBOX"),            BS_GROUPBOX));          // 0x00000007L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_LEFTTEXT"),            BS_LEFTTEXT));          // 0x00000020L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_OWNERDRAW"),           BS_OWNERDRAW));         // 0x0000000BL
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_PUSHBUTTON"),          BS_PUSHBUTTON));        // 0x00000000L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_RADIOBUTTON"),         BS_RADIOBUTTON));       // 0x00000004L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_USERBUTTON"),          BS_USERBUTTON));        // 0x00000008L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_BITMAP"),              BS_BITMAP));            // 0x00000080L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_BOTTOM"),              BS_BOTTOM));            // 0x00000800L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_CENTER"),              BS_CENTER));            // 0x00000300L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_ICON"),                BS_ICON));              // 0x00000040L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_FLAT"),                BS_FLAT));              // 0x00008000L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_LEFT"),                BS_LEFT));              // 0x00000100L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_MULTILINE"),           BS_MULTILINE));         // 0x00002000L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_NOTIFY"),              BS_NOTIFY));            // 0x00004000L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_PUSHLIKE"),            BS_PUSHLIKE));          // 0x00001000L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_RIGHT"),               BS_RIGHT));             // 0x00000200L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_RIGHTBUTTON"),         BS_RIGHTBUTTON));       // 0x00000020L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_TEXT"),                BS_TEXT));              // 0x00000000L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_TOP"),                 BS_TOP));               // 0x00000400L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_TYPEMASK"),            BS_TYPEMASK));          // 0x0000000FL
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_VCENTER"),             BS_VCENTER));           // 0x00000C00L
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_SPLITBUTTON"),         BS_SPLITBUTTON));       // 0x0000000CL
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_DEFSPLITBUTTON"),      BS_DEFSPLITBUTTON));    // 0x0000000DL
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_COMMANDLINK"),         BS_COMMANDLINK));       // 0x0000000EL
                                    _DatosEstilos.push_back(DEstilo(TEXT("BS_DEFCOMMANDLINK"),      BS_DEFCOMMANDLINK));    // 0x0000000FL
                                };
                                DWL_DEFINIR_ESTILO(BS_3State,           27);
                                DWL_DEFINIR_ESTILO(BS_Auto3State,       28);
                                DWL_DEFINIR_ESTILO(BS_AutoCheckbox,     29);
                                DWL_DEFINIR_ESTILO(BS_AutoRadioButton,  30);
                                DWL_DEFINIR_ESTILO(BS_CheckBox,         31);
                                DWL_DEFINIR_ESTILO(BS_DefPushButton,    32);
                                DWL_DEFINIR_ESTILO(BS_GroupBox,         33);
                                DWL_DEFINIR_ESTILO(BS_LrftText,         34);
                                DWL_DEFINIR_ESTILO(BS_OwnerDraw,        35);
                                DWL_DEFINIR_ESTILO(BS_PushButton,       36);
                                DWL_DEFINIR_ESTILO(BS_RadioButton,      37);
                                DWL_DEFINIR_ESTILO(BS_UserButton,       38);
                                DWL_DEFINIR_ESTILO(BS_Bitmap,           39);
                                DWL_DEFINIR_ESTILO(BS_Bottom,           40);
                                DWL_DEFINIR_ESTILO(BS_Center,           41);
                                DWL_DEFINIR_ESTILO(BS_Icon,             42);
                                DWL_DEFINIR_ESTILO(BS_Flat,             43);
                                DWL_DEFINIR_ESTILO(BS_Left,             44);
                                DWL_DEFINIR_ESTILO(BS_MultiLine,        45);
                                DWL_DEFINIR_ESTILO(BS_Notify,           46);
                                DWL_DEFINIR_ESTILO(BS_PushLike,         47);
                                DWL_DEFINIR_ESTILO(BS_Right,            48);
                                DWL_DEFINIR_ESTILO(BS_RightButton,      49);
                                DWL_DEFINIR_ESTILO(BS_Text,             50);
                                DWL_DEFINIR_ESTILO(BS_Top,              51);
                                DWL_DEFINIR_ESTILO(BS_TypeMask,         52);
                                DWL_DEFINIR_ESTILO(BS_VCenter,          53);
                                DWL_DEFINIR_ESTILO(BS_SplitButton,      54);
                                DWL_DEFINIR_ESTILO(BS_DefSplitButton,   55);
                                DWL_DEFINIR_ESTILO(BS_CommandLink,      56);
                                DWL_DEFINIR_ESTILO(BS_DefCommandLink,   57);

            inline DWORD        operator() (void)                { return _Estilos; };
            DButton_Estilos    &operator = (DWORD nEstilos)     { _Estilos = nEstilos; return *this; };
        };
    };

#endif