
// POR ELIMINAR
#ifndef DWL_H
    #define DWL_H
    // esta libreria se incluye en DAplicacion.cpp
    #pragma comment(lib, "comctl32.lib")		// Libreria para los common controls de windows

#endif

/*! \mainpage                   Devildrey33 Windows Library 2012
    \section intro_sec          Introducci�n :
                                <ul>
                                    <li>La DWL es una libreria creada por Jose Antonio Bover (devildrey33) dise�ada en un principio para facilitar la vida programando aplicaciones con interface grafico para windows.</li>
                                    <li>Su primera versi�n fue por el a�o 2002 en plena transici�n de windows 98 a windows xp, por lo que basaba su potencial en controles propios que simulaban los controles de windows. Estos controles eran altamente configurables en su aspecto y ofrecian una alternativa bastante mas amigable que los controles grises y rectangulares de windows 98.</li>
                                    <li>En la actualidad la necesidad de tener los controles extendidos de la DWL ha desaparecido gracias al avance del look de windows (sobretodo en windows 7), y por ello estos controles han sido retirados de la libreria.</li>
                                    <li>Por ahora se enfocara el desarrollo de esta libreria a ofrecer un soporte lo mas amplio posible sobre los controles estandar de windows.</li>
                                </ul>

    \section controles_sec      Lista de controles soportados :

                                <ul>
                                    <li>
                                        DButton.h Control que permite crear botones para que el usuario pueda realizar acciones.\n
                                        Hay varios tipos de button : Button normal, CheckBox, OptionButton, GroupBox, SplitButton, y LinkButton.
                                        <img src='BUTTONS.png' alt='Buttons' />\n
                                    </li>
                                    <li>
                                        DListView.h Control que permite crear listas de datos con relativa facilidad, y que puede ser adaptado a multiples situaciones. \n
                                        Dispone de 7 tipos de edici�n de items / subitems, y se pueden editar los colores y las fuentes de los textos para los items y subitems independientemente.\n
                                        <img src='LV_COMBO1.png' alt='ListView edici�n' />
                                        Puedes heredar la clase DListView y re-programar sus fases de pintado para hacer cosas como esta :\n
                                        <img src='LV_CUSTOMDRAW.png' alt='ListView custom draw' />\n
                                    </li>
                                </ul>
*/