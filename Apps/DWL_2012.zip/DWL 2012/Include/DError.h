#ifndef DERROR_H
    #define DERROR_H
    
    #include "DObjeto.h"
//    #include "DString.h"

    namespace DWL {
        
        enum DEnum_Error {
            DEnum_Error_SinError          = 0,
            DEnum_Error_IndiceInvalido,
            DEnum_Error_ReservandoMemoria,
            DEnum_Error_CreateWindowEx,
            DEnum_Error_GetDlgItem,
            DEnum_Error_BaseWndNULL
        };
/*        class DTipoError {
          public:
                            DTipoError(const unsigned int nNuDError, LPCWCH nMensajeError) : _NuDError(nNuDError), _MensajeError(nMensajeError) { };
          protected :
            unsigned int   _NuDError;
            LPCWCH         _MensajeError;
        };*/

        class DError : public DObjeto {
          public:
                                            DError(void)  : _Error_Objeto(NULL), _Error_Numero(DEnum_Error_SinError) { };
                                            DError(DObjeto *nObjeto, const char *nFuncion, const DEnum_Error nNumeroError) : _Error_Objeto(nObjeto), _Error_Numero(nNumeroError) { _AsignarFuncionError(nFuncion); };
            const TCHAR                    *MensajeError(void);
            const TCHAR                    *FuncionError(void)  { return _Error_Funcion; }
            DObjeto                        *Objeto(void)        { return _Error_Objeto; };
            virtual const TCHAR            *Objeto_Nombre(void) { return TEXT("DError"); };
            virtual const DEnum_Objeto      Objeto_ID(void)     { return DEnum_Objeto_Error; };
          protected:
            void                           _AsignarFuncionError(const char *nFuncion);
            DObjeto                       *_Error_Objeto;
            DEnum_Error                    _Error_Numero;
            TCHAR                          _Error_Funcion[2048];
        };


    };

#endif