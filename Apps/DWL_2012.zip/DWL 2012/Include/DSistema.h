#ifndef DSISTEMA_H
    #define DSISTEMA_H

    #include "DObjeto.h"
    #include "DDirectoriosPorDefecto.h"
    #include "DMouse.h"

    namespace DWL {

        class DAplicacion;

        class DSistema : public DObjeto {
          public:
                                            DSistema(void) { };

            DDirectoriosPorDefecto          DirectoriosPorDefecto;
            DMouse                          Mouse;

            virtual const TCHAR            *Objeto_Nombre(void) { return TEXT("DError"); };
            virtual const DEnum_Objeto      Objeto_ID(void)     { return DEnum_Objeto_Sistema; };

//              DEstilos      Estilos;
          protected :
            void                           _Iniciar(void);
            OSVERSIONINFOEX                _VersionWindows;

            friend class DAplicacion;
        };

//        extern DSistema Sistema;
    };


    
#endif