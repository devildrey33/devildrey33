// NOTAS para las funciones Crear de ventanas y controles

// En primer lugar las funciones para crear ventanas y controles utilizando CreateWindowEx se llamaran Crear, y pasaran a tener una estructura como esta :

// HWND Crear(DBaseWnd *nPadre, 
//            const TCHAR *nNombre, 
//            const TCHAR *nTexto, 
//            const int cX, const int cY, 
//            const int cAncho, const int cAlto, 
//            HMENU nMenu, 
//            DVentana_Estilos &nEstilos, DVentana_EstilosEx &nEstiloExtendido = DVentana_EstilosEx(NULL),
//            HBRUSH nColorFondo = NULL, const int nIconoRecursos = 32512);

// HWND Crear(DBaseWnd *nPadre,
//            const TCHAR *nNombre, 
//            const TCHAR *nTexto, 
//            const int cX, const int cY, 
//            const int cAncho, const int cAlto, 
//            HMENU nMenu, 
//            DWORD nEstilos, DWORD nEstilosExtendidos = NULL, 
//            HBRUSH nColorFondo = NULL, const int nIconoRecursos = 32512);

// Existiran 2 funciones como minimo, una a la que se le podran pasar las clases que deriven de DEstilo que estan destinadas a depurar, y otra con DWORD's para asignar sus estilos.
// El primer parametro siempre sera la clase DBaseWnd que contiene la ventana padre, o NULL si es el padre
// Los siguientes parametros seran de tipo TCHAR como el nombre de la ventana, el texto que mostrara, etc...
// Detras de los parametros de tipo TCHAR se ubicaran los parametros referentes a coordenadas X, Y, Ancho, Alto, etc...
// En cuarto lugar se ubicaran los parametros referentes a los estilos de la ventana, ya sean en formato DWORD o DEstilo.
// - Los parametros referentes a clases DEstilo deberan ser punteros para no hacer mas pesada la fase de creaci�n.
// Y por ultimo se ubicaran parametros opcionales (en el caso de la ventana el HMENU, el color del fondo, y el icono de la ventana.

// PARA LOS CONTROLES
// Las funciones Crear de los controles para windows internamente hacen una llamada a ConnectarControl() para enlazar el WindowProcedure con la clase.




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// NOTAS para las funciones Asignar de los controles
// Las funciones Asignar cumplen el rol de enlazar una clase de la DWL a un control previamente creado en un Dialogo. Al no utilizar CreateWindowEx en ese control no se redirige su WindowProcedure hasta que no se utiliza Asignar
// En esencia las funciones Asignar solo deberian tener dos parametros, aunque si se requiere de mas parametros se pueden agregar al final, preferiblemente de forma opcional.

// HWND Asignar(DBaseWnd *nPadre, const int cID);




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// NOTAS sobre las ID's para controles y dialogos :
// No es aconsejable repetir ids en controles, ya que si por ejemplo tenemos creado un boton y un listview con la misma ID uno de los dos controles no recibira correctamente sus eventos.
// Lo que si se puede hacer es crear dos ventanas iguales que tengan un boton salir con la misma ID, ya que esa ID pertenecera siempre a un boton, sus eventos seran mandados correctamente.
