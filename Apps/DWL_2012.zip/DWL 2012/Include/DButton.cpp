#include "DButton.h"
#include <Windowsx.h>

namespace DWL {
    //! Funci�n para crear el Button (CreateWindowEx).
    /*! Esta funci�n se usa para crear un Button dinamicamente.
            \fn         HWND Crear(DBaseWnd *nPadre, const TCHAR *nTexto, const int cX, const int cY, const int cAncho, const int cAlto, const UINT cID, DWORD nEstilos);
            \param[in]  nPadre               Clase DBaseWnd que contendra el button.
            \param[in]  nTexto               Texto para el Button.
            \param[in]  cX                   Coordenada X relativa a la ventana padre.
            \param[in]  cY                   Coordenada Y relativa a la ventana padre.
            \param[in]  cAncho               Ancho del Button en pixeles.
            \param[in]  cAlto                Altura del Button en pixeles
            \param[in]  cID                  ID para poder identificar el Button en sus eventos.
            \param[in]  nEstilos             Estilos estandar para el Button.
            \return     Devuelve el HWND del Button o NULL en caso de error.
    */
    HWND DButton::Crear(DBaseWnd *nPadre, const TCHAR *nTexto, const int cX, const int cY, const int cAncho, const int cAlto, const UINT cID, DWORD nEstilos) {            
        if (nPadre == NULL) throw (DError(this, __PROTOTIPO_FUNCION__, DEnum_Error_BaseWndNULL)); 
        _hWnd = CreateWindowEx(NULL, TEXT("BUTTON"), nTexto, nEstilos, cX, cY, cAncho, cAlto, nPadre->hWnd(), reinterpret_cast<HMENU>(IntToPtr(cID)), GetModuleHandle(NULL), NULL); 
		_ConectarControl(cID, nPadre);
        return _hWnd;
    }

    //! Funci�n para crear el Button (CreateWindowEx).
    /*! Esta funci�n se usa para crear un Button dinamicamente.
            \fn         HWND Crear(DBaseWnd *nPadre, const TCHAR *nTexto, const int cX, const int cY, const int cAncho, const int cAlto, const UINT cID, DButton_Estilos *nEstilos);
            \param[in]  nPadre               Clase DBaseWnd que contendra el button.
            \param[in]  nTexto               Texto para el Button.
            \param[in]  cX                   Coordenada X relativa a la ventana padre.
            \param[in]  cY                   Coordenada Y relativa a la ventana padre.
            \param[in]  cAncho               Ancho del Button en pixeles.
            \param[in]  cAlto                Altura del Button en pixeles
            \param[in]  cID                  ID para poder identificar el Button en sus eventos.
            \param[in]  nEstilos             Puntero a la clase DButton_Estilos que contiene los estilos para el Button.
            \return     Devuelve el HWND del Button o NULL en caso de error.
            \remarks    Esta funci�n es mas para depuraci�n de estilos que para uso cootidiano, ya que las clase DButton_Estilos permite revisar los estilos del button con mucha m�s facilidad, pero tambien consumen m�s memoria.
    */
    HWND DButton::Crear(DBaseWnd *nPadre, const TCHAR *nTexto, const int cX, const int cY, const int cAncho, const int cAlto, const UINT cID, DButton_Estilos *nEstilos) {
        if (nPadre == NULL) throw (DError(this, __PROTOTIPO_FUNCION__, DEnum_Error_BaseWndNULL)); 
        _hWnd = CreateWindowEx(NULL, TEXT("BUTTON"), nTexto, nEstilos->Estilos(), cX, cY, cAncho, cAlto, nPadre->hWnd(), reinterpret_cast<HMENU>(IntToPtr(cID)), GetModuleHandle(NULL), NULL); 
		_ConectarControl(cID, nPadre);
        return _hWnd;
    }

    //! Funci�n para asignar esta clase a un Button de un dialogo.
    /*! Esta funci�n se usa para asignar esta clase a un Button de un dialogo.
            \fn         HWND Asignar(DBaseWnd *nPadre, const UINT cID);
            \param[in]  nPadre      Clase DBaseWnd que contendra el button.
            \param[in]  cID         ID para poder identificar el Button en sus eventos.
            \return     Devuelve el HWND del Button o NULL en caso de error.
            \remarks    Esta funci�n solo debe utilizarse si tenemos un Button en un dialogo de los recursos.
    */
	HWND DButton::Asignar(DBaseWnd *nPadre, const UINT cID) { 
        if (nPadre == NULL) throw (DError(this, __PROTOTIPO_FUNCION__, DEnum_Error_BaseWndNULL)); 
		_hWnd = GetDlgItem(nPadre->hWnd(), cID);
		_ConectarControl(cID, nPadre); 
		return _hWnd;
	};

    //! Funci�n para asignar el texto del button.
    /*! Esta funci�n se usa para asignar el texto del button.
            \fn         void AsignarTexto(const TCHAR *nTexto);
            \param[in]  nTexto   Nuevo texto para el button.
            \return     No devuelve nada.
            \sa         ObtenerTexto().
    */
    void DButton::AsignarTexto(const TCHAR *nTexto) {
        SetDlgItemText(GetParent(_hWnd), static_cast<int>(GetWindowLongPtr(_hWnd, GWL_ID)), nTexto); 
    }

    //! Funci�n para obtener el texto del button.
    /*! Esta funci�n se usa para obtener el texto del button.
            \fn         void ObtenerTexto(DString &nTexto);
            \param[out] nTexto   Clase DString donde se almacenara el texto del button.
            \return     No devuelve nada.
            \sa         AsignarTexto().
    */
    void DButton::ObtenerTexto(DString &nTexto) {
        TCHAR Buffer[256];
        GetDlgItemText(GetParent(_hWnd), static_cast<int>(GetWindowLongPtr(_hWnd, GWL_ID)), Buffer, 256);
        nTexto = Buffer;
    }


    //! Funci�n que retorna los estilos del Button.
    /*  Esta funci�n introduce en el parametro nEstilos los estilos que contiene el Button.
            \fn         void ObtenerEstilos(DListView_Estilos &nEstilos);
            \param[out] nEstilos : Clase DButton_Estilos en la que se depositaran los estilos del Button.
            \return     Esta funci�n no devuelve nada.
    */
    void DButton::ObtenerEstilos(DButton_Estilos &nEstilos) { 
        nEstilos = static_cast<DWORD>(GetWindowLongPtr(_hWnd, GWL_STYLE)); 
    };

    //! Funci�n que retorna los estilos del Button.
    /*  Esta funci�n retorna todos los estilos del Button.
            \fn         DWORD ObtenerEstilos(void);
            \return     Devuelve los estilos del Button.
    */
    DWORD DButton::ObtenerEstilos(void) {
        return static_cast<DWORD>(GetWindowLongPtr(_hWnd, GWL_STYLE));
    }

    //! Funci�n para asignar los estilos del Button.
    /*  Esta funci�n permite asignar uno o mas estilos mediante el parametro nEstilos previamente preparado
            \fn         void AsignarEstilos(DButton_Estilos &nEstilos)
            \param[in]  nEstilos : Clase DButton_Estilos que contiene los nuevos estilos a asignar.
            \return     No devuelve nada.
            \remarks    Esta funci�n esta pensada para modificar todos los estilos de golpe, por lo que si quieres modificar un solo estilo conservando los valores de los demas,
                        primero deberas obtener los estilos mediante la funci�n ObtenerEstilos(), para luego modificar lo que te interese, y finalmente pasar la
                        clase DButton_Estilos a esta funci�n.
    */
    void DButton::AsignarEstilos(DButton_Estilos &nEstilos) { 
        SetWindowLongPtr(_hWnd, GWL_STYLE, nEstilos());
    };

    //! Funci�n para asignar los estilos del Button.
    /*  Esta funci�n permite asignar uno o mas estilos mediante el parametro nEstilos previamente preparado
            \fn         void AsignarEstilos(DWORD nEstilos)
            \param[in]  nEstilos : DWORD que contiene los nuevos estilos a asignar.
            \return     No devuelve nada.
            \remarks    Esta funci�n esta pensada para modificar todos los estilos de golpe, por lo que si quieres modificar un solo estilo conservando los valores de los demas,
                        primero deberas obtener los estilos mediante la funci�n ObtenerEstilos(), para luego modificar lo que te interese, y finalmente pasar los estilos a esta funci�n
    */
    void DButton::AsignarEstilos(DWORD nEstilos) { 
        SetWindowLongPtr(_hWnd, GWL_STYLE, nEstilos);
    };
};