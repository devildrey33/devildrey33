#ifndef DObjeto_H
    #define DObjeto_H

    #include "DDebug.h"

    namespace DWL {
        enum DEnum_Objeto {
            DEnum_Objeto_Objeto = 0,
            DEnum_Objeto_Error,
            DEnum_Objeto_Aplicacion,
            DEnum_Objeto_Sistema,
            DEnum_Objeto_StringMB,
            DEnum_Objeto_StringWC,
            DEnum_Objeto_Color,
            DEnum_Objeto_BaseWnd,
            DEnum_Objeto_EventosBase,
            DEnum_Objeto_EventosPadre,
            DEnum_Objeto_Ventana,
            DEnum_Objeto_Dialogo,
            DEnum_Objeto_DialogoModal,
            
            DEnum_Objeto_Button,
            DEnum_Objeto_ComboBox,
            DEnum_Objeto_EditBox,
            DEnum_Objeto_ImageList,
            DEnum_Objeto_ListView,
            DEnum_Objeto_ListView_Item,
            DEnum_Objeto_ListView_SubItem,
            DEnum_Objeto_ListView_Columna,
            DEnum_Objeto_ListView_DatosClick,
            DEnum_Objeto_ListView_DatosEdicion,

            DEnum_Objeto_TreeView,
            DEnum_Objeto_TreeView_Nodo,
            DEnum_Objeto_TreeView_TerminarLabelEdit,

            DEnum_Objeto_Estilos_Borde,
            DEnum_Objeto_Estilos_Fondo,
            DEnum_Objeto_Boton,
            DEnum_Objeto_Boton_Estilos,
            DEnum_Objeto_Boton_ParametrosClick,
            DEnum_Objeto_Menu
        };


        #define DWL_DECLARAR_DOBJETO(Nombre_Objeto, ID_Objeto)                                 \
            virtual const TCHAR            *Objeto_Nombre(void) { return Nombre_Objeto; };     \
            virtual const DEnum_Objeto      Objeto_ID(void)     { return ID_Objeto; };

/*        class DObjeto {
          public:
                                DObjeto(const DEnum_Objeto nObjeto) : _Objeto_ID(nObjeto) { };
            const TCHAR        *Objeto_Nombre(void);
            const TCHAR        *Objeto_Nombre(const DEnum_Objeto nObjeto);
            const DEnum_Objeto  Objeto_ID(void) { return _Objeto_ID; };
          protected :
                                DObjeto(void) : _Objeto_ID(DEnum_Objeto_Vacio) { };
            DEnum_Objeto       _Objeto_ID;
        };*/

        class DObjeto {
          public:
                                        DObjeto(void)       { };
            DWL_DECLARAR_DOBJETO(TEXT("DObjeto"), DEnum_Objeto_Objeto);
//            virtual const TCHAR        *Objeto_Nombre(void) { return TEXT("DObjeto"); };
//            virtual const DEnum_Objeto  Objeto_ID(void)     { return DEnum_Objeto_Objeto; };
        };
    };

#endif