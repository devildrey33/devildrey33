/*#include "DObjeto.h"

namespace DWL {

    const TCHAR *DObjeto::Objeto_Nombre(void) {
        return Objeto_Nombre(_Objeto_ID);
    }

    const TCHAR *DObjeto::Objeto_Nombre(const DEnum_Objeto nObjeto) {
        switch (nObjeto) {
            case DEnum_Objeto_Error :           return TEXT("DError");
            case DEnum_Objeto_Aplicacion :      return TEXT("DAplicaicon");
            case DEnum_Objeto_Sistema :         return TEXT("DSistema");
            case DEnum_Objeto_StringMB :        return TEXT("DStringMB");
            case DEnum_Objeto_StringWC :        return TEXT("DStringWC");
            case DEnum_Objeto_Canvas :          return TEXT("DCanvas");
            case DEnum_Objeto_Canvas_WM_PAINT : return TEXT("DCanvas_WM_PAINT");
            case DEnum_Objeto_BaseWnd :         return TEXT("DBaseWnd");
            case DEnum_Objeto_EventosBase :     return TEXT("DEventosBase");
            case DEnum_Objeto_EventosPadre :    return TEXT("DEventosPadre");
            case DEnum_Objeto_Ventana :         return TEXT("DVentana");
            case DEnum_Objeto_Menu :            return TEXT("DMenu");
            case DEnum_Objeto_Menu_Estilos :    return TEXT("DMenu_Estilos");
            default :                           return TEXT("Vacio");
        }
    }

};*/