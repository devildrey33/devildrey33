#include "DSistema.h"


namespace DWL {
//    DSistema Sistema;

    void DSistema::_Iniciar(void) {
	    ZeroMemory(&_VersionWindows, sizeof(OSVERSIONINFOEX));
	    _VersionWindows.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
	    GetVersionEx((OSVERSIONINFO *)&_VersionWindows);

        DirectoriosPorDefecto._Iniciar(_VersionWindows);
    }

}