#pragma once

#include <DAplicacion.h>
#include "DialogoLV.h"
#include "VentanaLV.h"

using namespace DWL;

class AppListView : public DAplicacion {
  public:
                            AppListView(void);
                           ~AppListView(void);
    const int               Evento_Empezar(void);

    DialogoLV               Dialogo;
    VentanaLV               Ventana;
};

// Creo la macro App que sera una referencia publica a la clase AppListView
#define App DWL_APP(AppListView)