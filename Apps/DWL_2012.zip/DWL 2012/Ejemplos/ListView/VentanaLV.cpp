#include "StdAfx.h"
#include "VentanaLV.h"
#include "resource.h"

#define IDV_VENTANA 1333

VentanaLV::VentanaLV(void) {
}

VentanaLV::~VentanaLV(void) {
}

// Funci�n que crea el dialogo, enlaza sus controles y rellena los datos del ListView
HWND VentanaLV::Crear(void) {
    DVentana::Crear(NULL, TEXT("VentanaLV"), TEXT("Ejemplo de pintado personalizado"), 200, 200, 340, 280, &DVentana_Estilos(WS_OVERLAPPEDWINDOW));

    // Creo el ListView con las estrellas
    ListView.Crear(this, 10, 10, 300, 220, IDC_LISTVIEW1);
    ListView.AgregarItem(0, TEXT("Item1"), 2);
    ListView.AgregarItem(0, TEXT("Item2"), 1);
    ListView.AgregarItem(0, TEXT("Item3"), 1);
    ListView.AgregarItem(0, TEXT("Item4"), 1);

    Visible(true);
    ListView.AsignarFoco();

    return _hWnd;
}


