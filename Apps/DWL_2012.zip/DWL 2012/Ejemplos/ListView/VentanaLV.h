#pragma once

#include <DVentana.h>
#include <DButton.h>
#include "ListViewEstrellas.h"

using namespace DWL;

class VentanaLV : public DVentana {
  public:
                        VentanaLV(void);
                       ~VentanaLV(void);

    HWND                Crear(void);

    ListViewEstrellas   ListView;
};
