#pragma once

#include <DDialogo.h>
#include <DListView.h>
#include <DButton.h>
#include <DComboBox.h>
#include <DImageList.h>

using namespace DWL;

class DialogoLV : public DDialogo {
  public:
                DialogoLV(void);
               ~DialogoLV(void);
    void        Crear(void);

    INT_PTR     Evento_Button_Mouse_Click(const UINT cID);

    INT_PTR     Evento_ListView_Edicion_Empezar(DListView_DatosEdicion *DatosEdicion, const UINT IDListView);
    INT_PTR     Evento_ListView_Edicion_Terminar(DListView_DatosEdicion *DatosEdicion, const UINT IDListView);
    INT_PTR     Evento_ListView_Item_Cambiado(const int nItem, const UINT IDListView);

    INT_PTR     Evento_ComboBox_CambioSeleccion(const UINT IDComboBox);


    // TEST EVENTOS LISTVIEW
    // Las funciones comentadas se han testeado con exito
//    INT_PTR     Evento_ListView_ArrastrarSoltar_Empezar(const int nBoton, const int nItem, const UINT IDListView)                                                                                                                                   { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_ArrastrarSoltar_Empezar(Boton %d, Item %d, IDListView %d)\n"), nBoton, nItem, IDListView); return 0; };
//    INT_PTR     Evento_ListView_Scroll_Empezar(const int dX, const int dY, const UINT IDListView)                                                                                                                                                   { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_Scroll_Empezar(X %d, Y %d, IDListView %d)\n"), dX, dY, IDListView); return 0; };
//    INT_PTR     Evento_ListView_Scroll_Terminar(const int dX, const int dY, const UINT IDListView)                                                                                                                                                  { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_Scroll_Terminar(X %d, Y %d, IDListView %d)\n"), dX, dY, IDListView); return 0; };
//    INT_PTR     Evento_ListView_Columna_Click(const int nColumna, const UINT IDListView)                                                                                                                                                            { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_Columna_Click(Columna %d, IDListView %d)\n"), nColumna, IDListView); return 0; };
//    INT_PTR     Evento_ListView_Item_BorrarTodos(const UINT IDListView)                                                                                                                                                                             { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_Item_BorrarTodos(IDListView %d)\n"), IDListView); return 0; };
//    INT_PTR     Evento_ListView_Item_Borrar(const int nItem, const UINT IDListView)                                                                                                                                                                 { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_Item_Borrar(IDListView %d)\n"), IDListView); return 0; };
//    INT_PTR     Evento_ListView_Mouse_Movimiento(const int nItem, const int nSubItem, const int nX, const int nY, const UINT IDListView)                                                                                                            { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_Mouse_Movimiento(Item %d, SubItem %d, X %d, Y %d, IDListView %d)\n"), nItem, nSubItem, nX, nY, IDListView); return 0; };
//    INT_PTR     Evento_ListView_Item_Agregar(const int nItem, const UINT IDListView)                                                                                                                                                                { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_Item_Agregar(Item %d, IDListView %d)\n"), nItem, IDListView); return 0; };
//    INT_PTR     Evento_ListView_Item_Activado(const int nItem, const int nSubItem, const UINT nNuevoEstado, const UINT nUltimoEstado, const UINT nMascara, const int nX, const int nY, LPARAM nParams, const UINT nTeclado, const UINT IDListView)  { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_Item_Activado(Item %d, SubItem %d, NuevoEstado %d, UltimoEstado %d, Mascara %d, X %d, Y %d, Params %d, Teclado %d, IDListView %d)\n"), nItem, nSubItem, nNuevoEstado, nUltimoEstado, nMascara, nX, nY, nParams, nTeclado, IDListView); return 0; };
//    INT_PTR     Evento_ListView_Item_Cambiado(const int nItem, const UINT IDListView)                                                                                                                                                               { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_Item_Cambiado(Item %d, IDListView %d)\n"), nItem, IDListView); return 0; };
//    INT_PTR     Evento_ListView_Item_Cambiando(const int nItem, const int nSubItem, const UINT nNuevoEstado, const UINT nUltimoEstado, const UINT nMascara, const int nX, const int nY, LPARAM nParams, const UINT IDListView)                      { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_Item_Cambiando(Item %d, SubItem %d, NuevoEstado %d, UltimoEstado %d, Mascara %d, X %d, Y %d, Params %d, IDListView %d)\n"), nItem, nSubItem, nNuevoEstado, nUltimoEstado, nMascara, nX, nY, nParams, IDListView); return 0; };
//    INT_PTR     Evento_ListView_TeclaPresionada(const WORD TeclaVirtual, const UINT IDListView)                                                                                                                                                     { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_TeclaPresionada(TeclaVirtual %d, IDListView %d)\n"), TeclaVirtual, IDListView); return 0; };
//    INT_PTR     Evento_ListView_Edicion_Cancelar(DListView_DatosEdicion *DatosEdicion, const UINT IDListView)                                                                                                                                       { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_Edicion_Cancelar(DatosEdicion...., IDListView %d)\n"), IDListView); return 0; };
//    INT_PTR     Evento_ListView_Mouse_Click(DListView_DatosClick *DatosClick, const UINT IDListView)                                                                                                                                                { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_Mouse_Click(PosItem %d, PosSubItem %d, X %d, Y %d, Boton %d, IDListView %d)\n"), DatosClick->PosItem, DatosClick->PosSubItem, DatosClick->X, DatosClick->Y, DatosClick->Boton, IDListView); return 0; };
//    INT_PTR     Evento_ListView_Mouse_DobleClick(DListView_DatosClick *DatosClick, const UINT IDListView)                                                                                                                                           { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_Mouse_DobleClick(PosItem %d, PosSubItem %d, X %d, Y %d, Boton %d, IDListView %d)\n"), DatosClick->PosItem, DatosClick->PosSubItem, DatosClick->X, DatosClick->Y, DatosClick->Boton, IDListView); return 0; };
//    INT_PTR     Evento_ListView_Foco_Obtenido(const UINT IDListView)                                                                                                                                                                                { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_Foco_Obtenido(IDListView %d)\n"), IDListView); return 0; };
//    INT_PTR     Evento_ListView_Foco_Perdido(const UINT IDListView)                                                                                                                                                                                 { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_Foco_Perdido(IDListView %d)\n"), IDListView); return 0; };
//    INT_PTR     Evento_ListView_TerminarCaptura(const UINT IDListView)                                                                                                                                                                              { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_TerminarCaptura(IDListView %d)\n"), IDListView); return 0; };
//    INT_PTR     Evento_ListView_Teclado_Intro(const UINT IDListView)                                                                                                                                                                                { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ListView_Teclado_Intro(IDListView %d)\n"), IDListView); return 0; };

    void        DetectarEstilosListView(void);
    void        AplicarEstilosListView(void);

    DListView   ListaEstilos;
    DListView   ListView;
    DButton     ButtonSalir;
    DComboBox   ComboVista;

    DImageList  ListaImagenes16;
    DImageList  ListaImagenes32;

    bool        Creando;
};
