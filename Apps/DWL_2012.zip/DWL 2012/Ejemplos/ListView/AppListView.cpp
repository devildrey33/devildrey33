#include "StdAfx.h"
#include "AppListView.h"

AppListView::AppListView(void) {
}

AppListView::~AppListView(void) {
}

const int AppListView::Evento_Empezar(void) {
    Dialogo.Crear();
    Ventana.Crear();
    return 0;
}

// Funci�n WINMAIN y enlaces a App y Sistema
DWL_INICIAR(AppListView);
