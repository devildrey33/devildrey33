#include "AppButton.h"

AppButton::AppButton(void) {
}

AppButton::~AppButton(void) {
}

const int AppButton::Evento_Empezar(void) {
    Ventana.Crear();
    return 0;
}


// Funci�n WINMAIN
DWL_INICIAR(AppButton);

