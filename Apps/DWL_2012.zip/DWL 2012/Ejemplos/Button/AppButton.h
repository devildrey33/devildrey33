#pragma once

#include <DAplicacion.h>
#include "VentanaButton.h"

using namespace DWL;

class AppButton : public DAplicacion {
  public:
                        AppButton(void);
                       ~AppButton(void);
    const int           Evento_Empezar(void);
    VentanaButton       Ventana;
};

#define App DWL_APP(AppButton);

