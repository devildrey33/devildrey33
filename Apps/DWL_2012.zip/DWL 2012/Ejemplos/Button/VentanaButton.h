#include <DVentana.h>
#include <DButton.h>

using namespace DWL;

class VentanaButton : public DVentana {
  public:
                VentanaButton(void) : DVentana() { };
    HWND        Crear(void);

    DButton     ButtonNormal;
    DButton     Grupo;
    DButton     CheckBox2;
    DButton     CheckBox3;
    DButton     Option1;
    DButton     Option2;
    DButton     DefaultButton;
    DButton     SplitButton;
    DButton     LinkButton;

    DButton     BotonPrivilegios;

    LRESULT     Evento_Button_Desplegar(const RECT RectaBoton, const UINT cID)  { DWL_IMPRIMIR_DEBUG(TEXT("Evento_Button_Desplegar(left %d, top %d, right %d, bottom %d, ID %d)\n"), RectaBoton.left, RectaBoton.top, RectaBoton.right, RectaBoton.bottom, cID); return 0; };
    LRESULT     Evento_Button_Mouse_Entrando(const UINT cID)                    { DWL_IMPRIMIR_DEBUG(TEXT("Evento_Button_Mouse_Entrando(ID %d)\n"), cID); return 0; };     //BCN_HOTITEMCHANGE
    LRESULT     Evento_Button_Mouse_Saliendo(const UINT cID)                    { DWL_IMPRIMIR_DEBUG(TEXT("Evento_Button_Mouse_Saliendo(ID %d)\n"), cID); return 0; };     //BCN_HOTITEMCHANGE
    LRESULT     Evento_Button_Mouse_Click(const UINT cID)                       { DWL_IMPRIMIR_DEBUG(TEXT("Evento_Button_Mouse_Click(ID %d)\n"), cID); return 0; };        //BN_CLICKED
    LRESULT     Evento_Button_Mouse_DobleClick(const UINT cID)                  { DWL_IMPRIMIR_DEBUG(TEXT("Evento_Button_Mouse_DobleClick(ID %d)\n"), cID); return 0; };    //BN_DBLCLK
    LRESULT     Evento_Button_Foco_Obtenido(const UINT cID)                     { DWL_IMPRIMIR_DEBUG(TEXT("Evento_Button_Foco_Obtenido(ID %d)\n"), cID); return 0; };
    LRESULT     Evento_Button_Foco_Perdido(const UINT cID)                      { DWL_IMPRIMIR_DEBUG(TEXT("Evento_Button_Foco_Perdido(ID %d)\n"), cID); return 0; };

};