#include "AppComboBox.h"

AppComboBox::AppComboBox(void) {
}

AppComboBox::~AppComboBox(void) {
}

const int AppComboBox::Evento_Empezar(void) {
    Dialogo.Crear();
    return 0;
}


// Funci�n WINMAIN
DWL_INICIAR(AppComboBox);

