#pragma once

#include <DAplicacion.h>
#include "DialogoComboBox.h"

using namespace DWL;

class AppComboBox : public DAplicacion {
  public:
                        AppComboBox(void);
                       ~AppComboBox(void);
    const int           Evento_Empezar(void);
    DialogoComboBox     Dialogo;
};

#define App DWL_APP(AppComboBox);

