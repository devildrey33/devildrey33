#include "DialogoComboBox.h"
#include "resource.h"

DialogoComboBox::DialogoComboBox(void) {
}

HWND DialogoComboBox::Crear(void) {
    DDialogo::Crear(IDD_DIALOG1, 100, 100);

    ComboEdit.Asignar(this, IDC_COMBO1, TEXT("hola"));
    ComboEstatico.Asignar(this, IDC_COMBO2, TEXT("hola"));

    BotonSalir.Asignar(this, IDC_BUTTON1);

    Visible(true);
    return _hWnd;
}


INT_PTR DialogoComboBox::Evento_Button_Mouse_Click(const UINT cID) {
    if (cID == IDC_BUTTON1) Destruir();
    return 0;
}