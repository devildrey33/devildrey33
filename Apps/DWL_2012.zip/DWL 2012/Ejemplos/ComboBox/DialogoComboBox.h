#include <DDialogo.h>
#include <DComboBox.h>
#include <DButton.h>

using namespace DWL;

class DialogoComboBox : public DDialogo {
  public:
                DialogoComboBox(void);
    HWND        Crear(void);

    INT_PTR     Evento_Button_Mouse_Click(const UINT cID);

    INT_PTR     Evento_ComboBox_CambioSeleccion(const UINT IDComboBox)  { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ComboBox_CambioSeleccion(ID : %d)\n"), IDComboBox); return 0; };
    INT_PTR     Evento_ComboBox_Lista_Ocultar(const UINT IDComboBox)    { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ComboBox_Lista_Ocultar(ID : %d)\n"), IDComboBox); return 0; };
    INT_PTR     Evento_ComboBox_Lista_DobleClick(const UINT IDComboBox) { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ComboBox_Lista_DobleClick(ID : %d)\n"), IDComboBox); return 0; };
    INT_PTR     Evento_ComboBox_Lista_Mostrar(const UINT IDComboBox)    { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ComboBox_Lista_Mostrar(ID : %d)\n"), IDComboBox); return 0; };
    INT_PTR     Evento_ComboBox_Edit_Cambiado(const UINT IDComboBox)    { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ComboBox_Edit_Cambiado(ID : %d)\n"), IDComboBox); return 0; };
    INT_PTR     Evento_ComboBox_Edit_Cambiando(const UINT IDComboBox)   { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ComboBox_Edit_Cambiando(ID : %d)\n"), IDComboBox); return 0; };
    INT_PTR     Evento_ComboBox_Foco_Perdido(const UINT IDComboBox)     { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ComboBox_Foco_Perdido(ID : %d)\n"), IDComboBox); return 0; };
    INT_PTR     Evento_ComboBox_Foco_Obtenido(const UINT IDComboBox)    { DWL_IMPRIMIR_DEBUG(TEXT("Evento_ComboBox_Foco_Obtenido(ID : %d)\n"), IDComboBox); return 0; };

    DComboBox   ComboEdit;
    DComboBox   ComboEstatico;
    DButton     BotonSalir;
};